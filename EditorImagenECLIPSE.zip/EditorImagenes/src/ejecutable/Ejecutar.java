package ejecutable;

import interfaz_principal.VentanaPrincipal;

public class Ejecutar {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		VentanaPrincipal vp = new VentanaPrincipal();
	}

}
