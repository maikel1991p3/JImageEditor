/**
 * Clase encargada de gestionar el redimensiado y mostrado de los
 * componente gr�ficos de la ventana prncipal de la aplicaci�n.
 */

package gestores;

import interfaz_principal.VentanaPrincipal;

import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

public class GestorDimensionarVent implements ComponentListener {

	private VentanaPrincipal refvp;
	
	public VentanaPrincipal getRefvp() { return refvp; }
	public void setRefvp(VentanaPrincipal refvp) { this.refvp = refvp; }
	
	public GestorDimensionarVent (VentanaPrincipal vp) {
		setRefvp(vp);
	}

	@Override
	public void componentResized(ComponentEvent tam) {
		getRefvp().getEscritorio().setBounds (20, 20, tam.getComponent().getWidth() - 60, tam.getComponent().getHeight() - 150);
		getRefvp().getPanelInfo().setDim (tam.getComponent().getWidth(), tam.getComponent().getHeight());
	}

	@Override
	public void componentShown(ComponentEvent visto) {}
	@Override
	public void componentHidden(ComponentEvent arg0) {}
	@Override
	public void componentMoved(ComponentEvent arg0) {}

	
}
