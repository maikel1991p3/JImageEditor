package gestores;

import java.awt.Color;
import java.awt.image.BufferedImage;

public class GestorEscGrises {

	public BufferedImage pasarAEscalaGrises (BufferedImage temp) {
		int pixelGris;
		int red, green, blue, argb;

		BufferedImage imgGris = new BufferedImage(temp.getWidth(), temp.getHeight(), temp.getType());
		
		//Recorremos la imagen p�xel a p�xel
		for (int i = 0; i < temp.getWidth(); i++){
			for (int j = 0; j < temp.getHeight(); j++){
				argb = temp.getRGB(i, j);
				red = (argb >> 16) & 0xff;
                green = (argb >>  8) & 0xff;
                blue = (argb) & 0xff;
				
				pixelGris = (int) Math.round((0.299 * red + 0.587 * green + 0.114 * blue));
				imgGris.setRGB(i, j, new Color (pixelGris, pixelGris, pixelGris).getRGB ());
			}
		}
		return imgGris;
	}
}
