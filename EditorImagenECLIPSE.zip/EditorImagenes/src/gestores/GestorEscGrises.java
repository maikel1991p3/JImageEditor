package gestores;

import java.awt.Color;
import java.awt.image.BufferedImage;

public class GestorEscGrises {

	public BufferedImage pasarAEscalaGrises (BufferedImage temp) {
		int pixelGris;
		int red, green, blue;

		BufferedImage imgGris = new BufferedImage(temp.getWidth(), temp.getHeight(), temp.getType());
		//Recorremos la imagen p�xel a p�xel
		for( int i = 0; i < temp.getHeight(); i++ ){
			for( int j = 0; j < temp.getWidth(); j++ ){
				red = new Color(temp.getRGB(i, j)).getRed();
				green = new Color(temp.getRGB(i, j)).getGreen();
				blue = new Color(temp.getRGB(i, j)).getBlue();

				pixelGris = (int) Math.round((0.299 * red + 0.587 * green + 0.114 * blue));
				imgGris.setRGB(i, j, new Color (pixelGris, pixelGris, pixelGris).getRGB ());
			}
		}
		return imgGris;
	}
}
