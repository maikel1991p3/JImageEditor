package gestores;

import herramientas.HDirectas;
import interfaz_principal.VentanaPrincipal;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;

import componentes.SubVentana;
import componentes.VentanaInfoImagen;

public class GestorSubVentanas {

	// Atributos internos
	private ArrayList<SubVentana> subVentanas;
	private int numVentActual;
	private GestorEscGrises gestor; // Objeto que pasa a escala de grises las im. en color
	private VentanaInfoImagen ventanInfo;

	// Referencia a la ventana de trabajo
	private VentanaPrincipal vp;

	// Manejadores de atributos
	public ArrayList<SubVentana> getSubVentanas() {	return subVentanas;	}
	public void setSubVentanas(ArrayList<SubVentana> subVentanas) {	this.subVentanas = subVentanas;	}

	public int getNumVentActual() { return numVentActual; }
	public void setNumVentActual(int numVentActual) { this.numVentActual = numVentActual; }

	public GestorEscGrises getGestor() { return gestor; }
	public void setGestor(GestorEscGrises gestor) { this.gestor = gestor; }

	public VentanaPrincipal getRefVp() { return vp;	}
	public void setRefVp(VentanaPrincipal vp) {	this.vp = vp;	}

	public VentanaInfoImagen getVentanInfo() { return ventanInfo; }
	public void setVentanInfo(VentanaInfoImagen ventanInfo) { this.ventanInfo = ventanInfo; }

	public GestorSubVentanas (VentanaPrincipal vp) {
		setRefVp(vp);
		setSubVentanas(new ArrayList<SubVentana>());
		setNumVentActual(-1);
		setGestor(new GestorEscGrises());
		setVentanInfo(new VentanaInfoImagen(getRefVp()));
	}

	public void crearSubVentana (BufferedImage RefBufImImagen, final int id, String nombre, Boolean original) {

		// 1� crea la subventana 
		SubVentana escGris = new SubVentana(getRefVp(), RefBufImImagen, id, nombre);

		// 2� A�adimos a la subventana un listener para que cuando se active, este hecho se refleje en el escritorio
		escGris.addInternalFrameListener(new InternalFrameAdapter() {
			@Override
			public void internalFrameActivated(InternalFrameEvent subV) {
				// Asigna como ventana actual aquella del escritorio que est� activa en ese momento (1 sola)
				setNumVentActual(id);
			}
		});

		escGris.setImgOriginal(original); // Para conservar si la imagen es original o no.

		// 4� A�adimos a la subventana un listener para activar la ventana de informaci�n para la imagen
		escGris.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent subV) {
				// SI CLICAMOS + CNTRL -> VENTANA CON INFORMACI�N DE LA IMAG�N
				if (subV.isControlDown()) {
					getVentanInfo().setVisible(!getVentanInfo().isVisible());
					getVentanInfo().setRefImg(((SubVentana)subV.getComponent()).getRefBufImg());
					getVentanInfo().actualizar();
				}
				// Obtener id de la ventana que ocasiona el evento (tocar dentro de ella)
				setNumVentActual(((SubVentana)getRefVp().getEscritorio().getSelectedFrame()).getId ());
			}
		});

		// 5� Actualizamos el n�mero de la ventana actual y la a�adimos
		setNumVentActual(escGris.getId());
		escGris.setTitle(nombre);
		getSubVentanas().add(escGris);

		int tam = getSubVentanas().size();
		if (tam == 1) {
			getRefVp ().getEscritorio().add (getSubVentanas().get(0));
		} else {
			getRefVp().getEscritorio().add (getSubVentanas().get(tam - 1));
		}

		((HDirectas) getRefVp().getGestorHerramientas().getHerramientas().get(4)).getVentanaMapaCambios().actualizarCombos();
	}
}
