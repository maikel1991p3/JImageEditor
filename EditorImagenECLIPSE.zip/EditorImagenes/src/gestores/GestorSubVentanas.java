package gestores;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;

import componentes.SubVentana;
import componentes.VentanaInfoImagen;

public class GestorSubVentanas {

	// Atributos internos
	private ArrayList<SubVentana> subVentanas;
	private int numVentActual;
	private GestorEscGrises gestor; // Objeto que pasa a escala de grises las im. en color
	private VentanaInfoImagen ventanInfo;

	// Referencia a la ventana de trabajo
	private VentanaPrincipal vp;

	// Manejadores de atributos
	public ArrayList<SubVentana> getSubVentanas() {	return subVentanas;	}
	public void setSubVentanas(ArrayList<SubVentana> subVentanas) {	this.subVentanas = subVentanas;	}

	public int getNumVentActual() { return numVentActual; }
	public void setNumVentActual(int numVentActual) { this.numVentActual = numVentActual; }

	public GestorEscGrises getGestor() { return gestor; }
	public void setGestor(GestorEscGrises gestor) { this.gestor = gestor; }

	public VentanaPrincipal getRefVp() { return vp;	}
	public void setRefVp(VentanaPrincipal vp) {	this.vp = vp;	}

	public VentanaInfoImagen getVentanInfo() { return ventanInfo; }
	public void setVentanInfo(VentanaInfoImagen ventanInfo) { this.ventanInfo = ventanInfo; }

	public GestorSubVentanas (VentanaPrincipal vp) {
		setRefVp(vp);
		setSubVentanas(new ArrayList<SubVentana>());
		setNumVentActual(-1);
		setGestor(new GestorEscGrises());
		setVentanInfo(new VentanaInfoImagen(getRefVp()));
	}

	public void crearSubVentana (BufferedImage RefBufImImagen, String nombre) {

		SubVentana escGris = new SubVentana(getGestor().pasarAEscalaGrises(RefBufImImagen), nombre);
		escGris.setTitle(nombre);
		escGris.addInternalFrameListener(new InternalFrameAdapter() {
			@Override
			public void internalFrameActivated(InternalFrameEvent subV) {
				// Asigna como ventana actual aquella del escritorio que est� activa en ese momento (1 sola)
				setNumVentActual(Integer.parseInt(getRefVp().getEscritorio().getSelectedFrame().getName()));
			}
		});
		escGris.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent subV) {
				// SI CLICAMOS + CNTRL -> VENTANA CON INFORMACI�N DE LA IMAG�N
				if (subV.isControlDown()) {
					getVentanInfo().setVisible(!getVentanInfo().isVisible());
					getVentanInfo().setRefImg(((SubVentana)subV.getComponent()).getRefBufImg());
					getVentanInfo().actualizar();
				}
				// Obtener id de la ventana que ocasiona el evento (tocar dentro de ella)
				setNumVentActual(Integer.parseInt(((SubVentana) subV.getSource()).getName()));
			}
		});
		getSubVentanas().add(escGris);

		int tam = getSubVentanas().size();
		if (tam == 1) {
			getSubVentanas().get (0).setName(String.valueOf(0));
			getRefVp ().getEscritorio().add (getSubVentanas().get(0));
		} else {
			getSubVentanas().get (tam - 1).setName(String.valueOf(tam - 1));
			getRefVp().getEscritorio().add (getSubVentanas().get(tam - 1));
		}

	}

}
