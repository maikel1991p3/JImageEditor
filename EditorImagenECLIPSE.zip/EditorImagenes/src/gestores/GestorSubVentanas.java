package gestores;

import interfaz_principal.VentanaPrincipal;
import interfaz_secundaria.PanelInformativo;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;

import componentesGraficosHerramientas.PanelSubVentana;
import componentesGraficosHerramientas.SubVentana;
import componentesGraficosHerramientas.VentanaInfoImagen;

public class GestorSubVentanas {

	// Atributos internos
	private ArrayList<SubVentana> subVentanas;
	private SubVentana refSubVentActual;
	private GestorEscGrises gestor; // Objeto que pasa a escala de grises las im. en color
	private VentanaInfoImagen ventanInfo;

	// Referencias necesarias
	private VentanaPrincipal vp;
	private PanelInformativo refPi;

	// Manejadores de atributos
	public ArrayList<SubVentana> getSubVentanas() {	return subVentanas;	}
	public void setSubVentanas(ArrayList<SubVentana> subVentanas) {	this.subVentanas = subVentanas;	}
	
	public SubVentana getRefSubVentActual() { return refSubVentActual; }
	public void setRefSubVentActual(SubVentana refSubVentActual) { this.refSubVentActual = refSubVentActual; }
	
	public GestorEscGrises getGestor() { return gestor; }
	public void setGestor(GestorEscGrises gestor) { this.gestor = gestor; }

	public VentanaPrincipal getRefVp() { return vp;	}
	public void setRefVp(VentanaPrincipal vp) {	this.vp = vp;	}

	public PanelInformativo getRefPi() { return refPi; }
	public void setRefPi(PanelInformativo refPi) { this.refPi = refPi; }
	
	public VentanaInfoImagen getVentanInfo() { return ventanInfo; }
	public void setVentanInfo(VentanaInfoImagen ventanInfo) { this.ventanInfo = ventanInfo; }

	public GestorSubVentanas (VentanaPrincipal vp) {
		setRefVp(vp);
		setRefPi(getRefVp().getPanelInfo());
		setSubVentanas(new ArrayList<SubVentana>());
		setGestor(new GestorEscGrises());
		setVentanInfo(new VentanaInfoImagen(getRefVp()));
	}

	public void crearSubVentana (BufferedImage RefBufImImagen, String nombre, Boolean original) {

		// 1� crea la subventana 
		final SubVentana escGris = new SubVentana(getRefVp(), RefBufImImagen, nombre);

		// 2� A�adimos a la subventana un listener para que cuando se active, este hecho se refleje en el escritorio
		escGris.addInternalFrameListener(new InternalFrameAdapter() {
			@Override
			public void internalFrameActivated(InternalFrameEvent subV) {
				// Asigna como ventana actual aquella del escritorio que est� activa en ese momento (1 sola)
				setRefSubVentActual(escGris);
				escGris.repaint ();
			}
			
			@Override
			public void internalFrameClosed(InternalFrameEvent v) {
				getSubVentanas().remove(v.getSource());
				getRefVp ().getEscritorio().remove((SubVentana)v.getSource());
				
			}
			
		});

		escGris.setImgOriginal(original); // Para conservar si la imagen es original o no.

		// 4� A�adimos a la subventana un listener para activar la ventana de informaci�n para la imagen
		escGris.getPanel().addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent subV) {
				// SI CLICAMOS + CNTRL -> VENTANA CON INFORMACI�N DE LA IMAG�N
				if (subV.isControlDown()) {
					getVentanInfo().setVisible(!getVentanInfo().isVisible());
					getVentanInfo().setRefImg(((PanelSubVentana)subV.getComponent()).getRefBImg());
					getVentanInfo().actualizar();
				}
				setRefSubVentActual(escGris);
			}
			
			public void mouseExited (MouseEvent e) {
				getRefPi().setR(0);
				getRefPi().setG(0);
				getRefPi().setB(0);
				getRefPi().setPosX(0);
				getRefPi().setPosY(0);
				getRefPi().repaint();
			}
		});
		
		escGris.getPanel().addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent r) {
				if (escGris.getRefBufImg() != null && getRefVp() != null && getRefVp().getPanelInfo() != null) {
					getRefPi().setR(new Color(escGris.getRefBufImg().getRGB(r.getX(), r.getY())).getRed());
					getRefPi().setG(new Color(escGris.getRefBufImg().getRGB(r.getX(), r.getY())).getGreen());
					getRefPi().setB(new Color(escGris.getRefBufImg().getRGB(r.getX(), r.getY())).getBlue());

					getRefPi().setPosX(r.getX());
					getRefPi().setPosY(r.getY());
				}

				getRefVp().getPanelInfo().repaint();
			}
		});
		
		
		setRefSubVentActual(escGris);
		escGris.setTitle(nombre);
		getSubVentanas().add(escGris);

		int tam = getSubVentanas().size();
		if (tam == 1) {
			getRefVp ().getEscritorio().add (getSubVentanas().get(0));
		} else {
			getRefVp().getEscritorio().add (getSubVentanas().get(tam - 1));
		}

		//((HDirectas) getRefVp().getGestorHerramientas().getHerramientas().get(4)).getVentanaMapaCambios().actualizarCombos();
	}
}
