package gestores;

import herramientas.HEditar;
import herramientas.HRealce;
import herramientas.Herramienta;
import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JDesktopPane;
import javax.swing.JDialog;
import javax.swing.JFrame;

@SuppressWarnings("serial")
public class GestorHerramientas extends JDialog {

	// Referencia a la ventana principal
	private VentanaPrincipal refVp;
	
	// Atributos internos del gestor de herrmientas
	private ArrayList<Herramienta> herramientas;

	// Manejadores de referencias y atributos
	public VentanaPrincipal getRefVp() { return refVp;	}
	public void setRefVp(VentanaPrincipal ref) {	this.refVp = ref;	}
	
	public ArrayList<Herramienta> getHerramientas() { return herramientas; }
	public void setHerramientas(ArrayList<Herramienta> herramientas) { this.herramientas = herramientas; }
	
	public GestorHerramientas (VentanaPrincipal vp) {
		iniciarVentana();
		setRefVp(vp);
		iniciarHerramientas();
	}

	private void iniciarVentana () {
		setTitle("Herramientas");
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setLayout(null);
		setBounds(20, 50, 250, 300);
		setVisible(true);
		setBackground(Color.RED);
		setResizable(false);
		setAlwaysOnTop(true);
		
	}
	
	private void iniciarHerramientas () {
		setHerramientas(new ArrayList<Herramienta>());
		getHerramientas().add(new HRealce(this));  // 0 -> Herramie
		getHerramientas().add(new HEditar (this)); // 1 -> Herramientas editar
		
		getContentPane().add (getHerramientas().get(0));
		getContentPane().add (getHerramientas().get(1));
		
		for (int i = 0; i < getHerramientas().size(); ++i)
			getHerramientas().get(i).setVisible(true);
		
		getHerramientas().get(1).setVisible(true);
	}
}
