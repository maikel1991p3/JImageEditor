package gestores;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JDialog;
import javax.swing.JRootPane;

import componentesInternos.MiBoton;

@SuppressWarnings("serial")
public class InterfazInteligente extends JDialog {

	final int X = 700;
	final int Y = 100;
	final int ANCHO = 100;
	final int ALTO = 430;

	private ArrayList<MiBoton> botones;
	private VentanaPrincipal refVp;

	public ArrayList<MiBoton> getBotones() { return botones; }
	public void setBotones(ArrayList<MiBoton> botones) { this.botones = botones; }

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }

	public InterfazInteligente (VentanaPrincipal vp) {
		setRefVp(vp);
		setTitle("GUI. Int.");
		setBounds(X, Y, ANCHO, ALTO);
		setLocation(X, Y);
		getContentPane().setBackground(Color.WHITE);
		setAlwaysOnTop(true);
		setResizable(false);
		setUndecorated(true);
		getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
		setLayout(null);

		setBotones(new ArrayList<MiBoton>());

		iniciarContenido ();

		setVisible(true);
	}


	public void iniciarContenido () {
		if (!getBotones().isEmpty())
			getBotones().clear();

		for (int i = 0; i < getRefVp().getGestorHerramientas().getHerramientas().size(); ++i)
			for (int j = 0; j < getRefVp().getGestorHerramientas().getHerramientas().get(i).getBotones().size(); ++j) 
				getBotones().add (new MiBoton (getRefVp().getGestorHerramientas().getHerramientas().get(i).getBotones().get(j)));

	}

	public void swap (int i, int j) {
		System.out.println("Entro en swap!!");
		MiBoton temp = new MiBoton(getBotones().get(i));
		getBotones().remove(i);
		getBotones().add(i, getBotones().get(j));
		getBotones().remove(j);
		getBotones().add(j, temp);
	}

	public void ranking () {
		//try {
		iniciarContenido();

		for (int i = 0; i < getBotones().size() - 2; ++i) {
			if (getBotones().get(i).getFrecuencia() < getBotones().get(i + 1).getFrecuencia()) {
				swap (i, i + 1);
				System.out.println("i:  " + getBotones().get(i).getFrecuencia() + ",   j:  " + getBotones().get(i + 1).getFrecuencia());
			}
		}
		System.out.println();
		if (getContentPane().getComponents().length != 0)
			for (int i = 0; i < 5; ++i) {
				System.out.println(getContentPane().getComponents()[i]);
				getContentPane().remove(getBotones().get(i));
			}

		getContentPane().removeAll();

		// Actualizar Ranking de botones m�s usados 
		for (int i = 0; i < getBotones().size(); ++i) {
			if (i < 5) {
				getBotones().get(i).setVisible(true);
				getBotones().get(i).setBounds(1, i * 90, 40, 30);
				getContentPane().add(getBotones().get(i));
			} else {
				getBotones().get(i).setVisible(false);
				getContentPane().add(getBotones().get(i));
			}
		}
		repaint ();
		//} catch (Exception e) {}
	}

}
