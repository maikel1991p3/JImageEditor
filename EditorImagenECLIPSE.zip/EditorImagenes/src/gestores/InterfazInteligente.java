package gestores;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.FlowLayout;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;

@SuppressWarnings("serial")
public class InterfazInteligente extends JDialog {

	final int X = 700;
	final int Y = 100;
	final int ANCHO = 200;
	final int ALTO = 500;
	
	private ArrayList<JButton> botones;
	private VentanaPrincipal refVp;
	
	public ArrayList<JButton> getBotones() { return botones; }
	public void setBotones(ArrayList<JButton> botones) { this.botones = botones; }

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }
	
	public InterfazInteligente (VentanaPrincipal vp) {
		setRefVp(vp);
		setTitle("Interfaz Inteligente");
		setBounds(X, Y, ANCHO, ALTO);
		getContentPane().setBackground(Color.WHITE);
		
		setBotones(new ArrayList<JButton>());
		setLayout(new FlowLayout ());
		iniciarContenido ();
		setUndecorated(true);
		setVisible(true);
	}
	
	public void iniciarContenido () {
		for (int i = 0; i < getRefVp().getGestorHerramientas().getHerramientas().size(); ++i) {
			for (int j = 0; j < getRefVp().getGestorHerramientas().getHerramientas().get(i).getBotones().size(); ++j) {
				getBotones().add (getRefVp().getGestorHerramientas().getHerramientas().get(i).getBotones().get(j));
			}
		}
		
		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setSize (30, 30);
			add (getBotones().get(i)); //          ---------->>>>>  OJOOOOOOOOO!!!!! <<<<<-----------
		}
	}
	
	public void ranking () {
		for (int i = 0; i < getRefVp().getGestorHerramientas().getHerramientas().get(0).getBotones().size(); ++i) {
			
		}
	}
}
