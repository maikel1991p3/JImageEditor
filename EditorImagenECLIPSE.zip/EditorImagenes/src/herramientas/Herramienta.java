package herramientas;

import gestores.GestorHerramientas;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class Herramienta extends JPanel {

	// Referencia a la ventana que gestiona las herramientas
	private GestorHerramientas refGestorH;
	
	public GestorHerramientas getRefGestorH() {	return refGestorH; }
	public void setRefGestorH(GestorHerramientas refGestorH) { this.refGestorH = refGestorH; }

	public Herramienta (GestorHerramientas refGestorH) {
		setRefGestorH(refGestorH);
		iniciarDimensiones();
		setVisible(false);
	}
	
	public void iniciarDimensiones () {
		setBounds(0, 0, getRefGestorH().getWidth(), getRefGestorH().getHeight());
		setLayout(null);
	}
}
