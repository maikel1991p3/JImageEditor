package herramientas;

import gestores.GestorHerramientas;

import java.util.ArrayList;

import javax.swing.JPanel;

import componentes.MiBoton;

@SuppressWarnings("serial")
public abstract class Herramienta extends JPanel {

	// Referencia a la ventana que gestiona las herramientas
	private GestorHerramientas refGestorH;
	
	public abstract ArrayList<MiBoton> getBotones ();
	
	public GestorHerramientas getRefGestorH() {	return refGestorH; }
	public void setRefGestorH(GestorHerramientas refGestorH) { this.refGestorH = refGestorH; }

	public Herramienta (GestorHerramientas refGestorH) {
		setRefGestorH(refGestorH);
		iniciarDimensiones();
		setVisible(false);
	}
	
	public void iniciarDimensiones () {
		setBounds(0, 0, getRefGestorH().getWidth(), getRefGestorH().getHeight());
		setLayout(null);
	}
}
