package herramientas;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.border.LineBorder;

import componentes.SubVentana;
import componentes.VentanaBrilloContraste;
import componentes.VentanaCorrecGamma;
import gestores.GestorHerramientas;

@SuppressWarnings("serial")
public class HNoLineales extends Herramienta {

	private ArrayList<JButton> botones;
	private VentanaCorrecGamma vCorrecGamma;

	private VentanaPrincipal refVp;

	public ArrayList<JButton> getBotones() { return botones; }
	public void setBotones(ArrayList<JButton> botones) { this.botones = botones; }

	public VentanaCorrecGamma getvCorrecGamma() { return vCorrecGamma; }
	public void setvCorrecGamma(VentanaCorrecGamma vCorrecGamma) { this.vCorrecGamma = vCorrecGamma; }

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }

	public HNoLineales(GestorHerramientas refGestorH) {
		super(refGestorH);
		setRefVp(refGestorH.getRefVp());
		setvCorrecGamma(new VentanaCorrecGamma(getRefVp()));
		iniciarBotones();
		crearOyentesBotones();
		setBackground(Color.GRAY);
		setVisible(false);
	}

	private void iniciarBotones () {
		setBotones(new ArrayList<JButton>());

		// Reservar memoria para el objeto que realiza las operaciones indicadas
		JButton cGamma = new JButton("Correcci�n Gamma");
		cGamma.setBounds(20, 50, 200, 40);
		cGamma.setBackground(Color.WHITE);

		getBotones().add (cGamma);

		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setBorder(new LineBorder(Color.BLACK, 2));
			add (getBotones().get(i));
		}
	}

	private void crearOyentesBotones () {
		// Oyente para el bot�n de la correcci�n gamma
		getBotones().get(0).addActionListener(new ActionListener() {

			public BufferedImage copiar (SubVentana original) {
				BufferedImage temp = new BufferedImage(original.getRefBufImg().getWidth(), original.getRefBufImg().getHeight() ,original.getRefBufImg().getType());
				for (int i = 0; i < temp.getWidth(); ++i) {
					for (int j = 0; j < temp.getHeight(); ++j){
						temp.setRGB(i, j, original.getRefBufImg().getRGB(i, j));
					}
				}
				return temp;
			}

			@Override
			public void actionPerformed(ActionEvent arg0) {
				getvCorrecGamma ().setVisible(true);
				if (!getRefGestorH().getRefVp().getGestorSubVentanas().getSubVentanas().isEmpty()) {
					int nVAct = getRefGestorH().getRefVp().getGestorSubVentanas().getNumVentActual();
					BufferedImage copia = copiar(getRefGestorH().getRefVp().getGestorSubVentanas().getSubVentanas().get(nVAct));
					getRefGestorH().getRefVp().getGestorSubVentanas().crearSubVentana(copia, getRefGestorH().getRefVp().getGestorSubVentanas().getSubVentanas().get(nVAct).getId() + 1, getRefGestorH().getRefVp().getGestorSubVentanas().getSubVentanas().get(nVAct).getTitle(), false);

					// Volvemos a cojer el id de la ventana actual porque a�adimos la nueva del brillo
					int nVen = getRefGestorH().getRefVp().getGestorSubVentanas().getNumVentActual();
					getvCorrecGamma().inicializarValoresAcotados(getRefGestorH().getRefVp().getGestorSubVentanas().getSubVentanas().get(nVen).getRefBufImg());


				} 
			}
		});
	}
}
