package herramientas;

import gestores.GestorHerramientas;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

import javax.swing.border.LineBorder;

import operaciones.OpEditar;

import componentesInternos.MiBoton;

@SuppressWarnings("serial")
public class HEditar extends Herramienta {

	private ArrayList<MiBoton> botones;
	private OpEditar opEditar;

	private Point ini = new Point(0, 0);
	private Point fin = new Point(0, 0);

	public Point getIni() { return ini;	}
	public void setIni(Point ini) { this.ini = ini; }

	public Point getFin() { return fin; }
	public void setFin(Point fin) { this.fin = fin; }

	public ArrayList<MiBoton> getBotones() { return botones; }
	public void setBotones(ArrayList<MiBoton> botones) { this.botones = botones; }

	public OpEditar getOpEditar() { return opEditar; }
	public void setOpEditar(OpEditar op) { this.opEditar = op; }

	public HEditar(GestorHerramientas refGestorH) {
		super(refGestorH);
		iniciarBotones();
		definirEstiloPanel();
		crearOyentesBotones();
		setVisible(false);
	}

	private void iniciarBotones () {
		setBotones(new ArrayList<MiBoton>());

		// Reservar memoria para el objeto que realiza las operaciones indicadas
		setOpEditar(new OpEditar (getRefGestorH().getRefVp()));

		MiBoton bsubImg = new MiBoton("Sub-imagen", 2);
		bsubImg.setToolTipText("Sub-imagen: permite seleccionar un �rea de inter�s (ROI) y crear una nueva subImagen");
		bsubImg.setBounds(20, 50, 200, 40);
		bsubImg.setBackground(Color.WHITE);

		MiBoton bDupImg = new MiBoton("Duplicar Imagen", 3);
		bDupImg.setToolTipText("Duplicar Imagen: duplica la imagen actual");
		bDupImg.setBounds(20, 110, 200, 40);
		bDupImg.setBackground(Color.WHITE);

		getBotones().add (bsubImg);
		getBotones().add (bDupImg);

		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setBorder(new LineBorder(Color.BLACK, 2));
			add (getBotones().get(i));
		}
	}

	private void definirEstiloPanel () {
		// Poner todo lo relacionado con dar estilo al panel
		setBackground(Color.GRAY);
	}

	private void crearOyentesBotones () {
		// Oyente para el bot�n de la subimagen
		getBotones().get(0).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
					
				try {
					getRefGestorH().getRefVp().getGestorSubVentanas().getRefSubVentActual().getPanel().addMouseListener(new MouseAdapter() {

						@Override
						public void mousePressed(MouseEvent click) {
							try {
								//getIni().setLocation(click.getX(), click.getY());
								setIni(new Point(click.getX(), click.getY()));
							} catch (Exception e) {}
						}

						@Override
						public void mouseReleased(MouseEvent click) {
							try {
								setFin(new Point(click.getX(), click.getY()));
								getOpEditar().crearSubImagen(getIni(), getFin());
							} catch (Exception e) { }
						}
					});

					getRefGestorH().getRefVp().getGestorSubVentanas().getRefSubVentActual().getPanel().addMouseMotionListener(new MouseMotionListener() {

						@Override
						public void mouseMoved(MouseEvent raton) {}

						@Override
						public void mouseDragged(MouseEvent ratonApretado) {
							getFin().setLocation(ratonApretado.getX(), ratonApretado.getY());
							pintarCuadradoSeguimiento ();
							getRefGestorH().getRefVp().getEscritorio().getSelectedFrame().repaint();
						}

						public void pintarCuadradoSeguimiento () {
							//getRefGestorH().getRefVp().getEscritorio().getSelectedFrame().getGraphics().setColor(Color.WHITE);
							getRefGestorH().getRefVp().getEscritorio().getSelectedFrame().getGraphics().drawRect((int) getIni().getX() + 5,
									(int) getIni().getY() + 25, (int) (getFin().getX() - getIni().getX()), (int) (getFin().getY() - getIni().getY()));

						}
					});

				} catch (Exception e) { }
			}
		});

		// Oyente para el bot�n de duplicar Imagen
		getBotones().get(1).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					getRefGestorH().getRefVp().getGestorSubVentanas().crearSubVentana(getRefGestorH().getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg(),
							"Copia de " + getRefGestorH().getRefVp().getGestorSubVentanas().getRefSubVentActual().getTitle(), false);
				} catch (Exception e) { }
			}
		});

	}

}
