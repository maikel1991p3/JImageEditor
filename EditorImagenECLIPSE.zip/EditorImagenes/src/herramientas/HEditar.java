package herramientas;

import gestores.GestorHerramientas;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JButton;

import operaciones.OpEditar;

@SuppressWarnings("serial")
public class HEditar extends Herramienta {

	private ArrayList<JButton> botones;
	private OpEditar opEditar;

	public ArrayList<JButton> getBotones() { return botones; }
	public void setBotones(ArrayList<JButton> botones) { this.botones = botones; }

	public OpEditar getOpEditar() { return opEditar; }
	public void setOpEditar(OpEditar op) { this.opEditar = op; }
	
	public HEditar(GestorHerramientas refGestorH) {
		super(refGestorH);
		iniciarBotones();
		definirEstiloPanel();
		crearOyentesBotones();
	}
	
	private void iniciarBotones () {
		setBotones(new ArrayList<JButton>());

		// Reservar memoria para el objeto que realiza las operaciones indicadas
		setOpEditar(new OpEditar (getRefGestorH().getRefVp()));

		JButton bsubImg = new JButton("SubImagen");
		bsubImg.setBounds(20, 50, 200, 40);
		bsubImg.setBackground(Color.WHITE);

		JButton bDupImg = new JButton("Duplicar Imagen");
		bDupImg.setBounds(20, 110, 200, 40);
		bDupImg.setBackground(Color.WHITE);
		
		getBotones().add (bsubImg);
		getBotones().add (bDupImg);
		
		for (int i = 0; i < getBotones().size(); ++i)
			add (getBotones().get(i));
	}

	private void definirEstiloPanel () {
		// Poner todo lo relacionado con dar estilo al panel
		setBackground(Color.GRAY);
	}

	private void crearOyentesBotones () {
		// Oyente para el bot�n de la subimagen
		getBotones().get(0).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getRefGestorH().getRefVp().getEscritorio().getSelectedFrame().addMouseListener(new MouseAdapter() {
					private Point ini = new Point();
					private Point fin = new Point();
					
					public Point getIni() { return ini;	}
					public void setIni(Point ini) { this.ini = ini; }

					public Point getFin() { return fin; }
					public void setFin(Point fin) { this.fin = fin; }

					@Override
					public void mouseReleased(MouseEvent click) {
						System.out.println("fin =  " + click.getX());
						setFin(new Point(click.getX(), click.getY()));
						getOpEditar().crearSubImagen(getIni(), getFin());
					}
										
					@Override
					public void mouseClicked(MouseEvent click) {
						System.out.println("ini =  " + click.getX());
						setIni(new Point(click.getX(), click.getY()));
					}
				});
			}
		});
		
		// Oyente para el bot�n de duplicar Imagen
		getBotones().get(1).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				int vAct = getRefGestorH().getRefVp().getGestorSubVentanas().getNumVentActual();
				getOpEditar().crearSubImagen(new Point(0, 0), 
						new Point (getRefGestorH().getRefVp().getGestorSubVentanas().getSubVentanas().get(vAct).getWidth(), 
								getRefGestorH().getRefVp().getGestorSubVentanas().getSubVentanas().get(vAct).getHeight()));
			}
		});
		
	}

}
