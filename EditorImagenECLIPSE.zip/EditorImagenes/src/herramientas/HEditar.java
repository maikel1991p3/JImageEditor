package herramientas;

import gestores.GestorHerramientas;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

import javax.swing.border.LineBorder;

import operaciones.OpEditar;

import componentes.MiBoton;

@SuppressWarnings("serial")
public class HEditar extends Herramienta {

	private ArrayList<MiBoton> botones;
	private OpEditar opEditar;

	private Point ini = new Point(0, 0);
	private Point fin = new Point(0, 0);

	public Point getIni() { return ini;	}
	public void setIni(Point ini) { this.ini = ini; }

	public Point getFin() { return fin; }
	public void setFin(Point fin) { this.fin = fin; }

	public ArrayList<MiBoton> getBotones() { return botones; }
	public void setBotones(ArrayList<MiBoton> botones) { this.botones = botones; }

	public OpEditar getOpEditar() { return opEditar; }
	public void setOpEditar(OpEditar op) { this.opEditar = op; }

	public HEditar(GestorHerramientas refGestorH) {
		super(refGestorH);
		iniciarBotones();
		definirEstiloPanel();
		crearOyentesBotones();
		setVisible(false);
	}

	private void iniciarBotones () {
		setBotones(new ArrayList<MiBoton>());

		// Reservar memoria para el objeto que realiza las operaciones indicadas
		setOpEditar(new OpEditar (getRefGestorH().getRefVp()));

		MiBoton bsubImg = new MiBoton("Sub-imagen");
		bsubImg.setToolTipText("Sub-imagen: permite seleccionar un �rea de inter�s (ROI) y crear una nueva subImagen");
		bsubImg.setBounds(20, 50, 200, 40);
		bsubImg.setBackground(Color.WHITE);

		MiBoton bDupImg = new MiBoton("Duplicar Imagen");
		bDupImg.setToolTipText("Duplicar Imagen: duplica la imagen actual");
		bDupImg.setBounds(20, 110, 200, 40);
		bDupImg.setBackground(Color.WHITE);


		MiBoton bAmplImg = new MiBoton("Ampliar zona imagen");
		bsubImg.setToolTipText("Ampliar zona imagen: permite seleccionar un �rea de inter�s (ROI) y crear una nueva subImagen ampliada!");
		bAmplImg.setBounds(20, 170, 200, 40);
		bAmplImg.setBackground(Color.WHITE);

		getBotones().add (bsubImg);
		getBotones().add (bDupImg);
		getBotones().add (bAmplImg);

		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setBorder(new LineBorder(Color.BLACK, 2));
			add (getBotones().get(i));
		}
	}

	private void definirEstiloPanel () {
		// Poner todo lo relacionado con dar estilo al panel
		setBackground(Color.GRAY);
	}

	private void crearOyentesBotones () {
		// Oyente para el bot�n de la subimagen
		getBotones().get(0).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getBotones().get(0).aumentaFrecuenciaUso ();
				try {
					getRefGestorH().getRefVp().getEscritorio().getSelectedFrame().addMouseListener(new MouseAdapter() {

						@Override
						public void mousePressed(MouseEvent click) {
							try {
								getIni().setLocation(click.getX(), click.getY());
							} catch (Exception e) {}
						}

						@Override
						public void mouseReleased(MouseEvent click) {
							try {
								setFin(new Point(click.getX(), click.getY()));
								getOpEditar().crearSubImagen(getIni(), getFin());
							} catch (Exception e) { }
						}
					});

					getRefGestorH().getRefVp().getEscritorio().getSelectedFrame().addMouseMotionListener(new MouseMotionListener() {

						@Override
						public void mouseMoved(MouseEvent raton) {}

						@Override
						public void mouseDragged(MouseEvent ratonApretado) {
							getFin().setLocation(ratonApretado.getX() - getIni().getX(), ratonApretado.getY() - getIni().getY());
							pintarCuadradoSeguimiento ();
							getRefGestorH().getRefVp().getEscritorio().getSelectedFrame().repaint();
						}

						public void pintarCuadradoSeguimiento () {
							getRefGestorH().getRefVp().getEscritorio().getSelectedFrame().getGraphics().setColor(Color.WHITE);
							getRefGestorH().getRefVp().getEscritorio().getSelectedFrame().getGraphics().drawRect((int) getIni().getX(), (int) getIni().getY(), (int) getFin().getX(), (int) getFin().getY());

						}
					});

				} catch (Exception e) { }
			}
		});

		// Oyente para el bot�n de duplicar Imagen
		getBotones().get(1).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getBotones().get(1).aumentaFrecuenciaUso ();
				try {
					int vAct = getRefGestorH().getRefVp().getGestorSubVentanas().getNumVentActual();
					getOpEditar().crearSubImagen(new Point(), 
							new Point (getRefGestorH().getRefVp().getGestorSubVentanas().getSubVentanas().get(vAct).getWidth(), 
									getRefGestorH().getRefVp().getGestorSubVentanas().getSubVentanas().get(vAct).getHeight()));
				} catch (Exception e) { }
			}
		});

		/*getBotones().get(2).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
			getBotones().get(2).aumentaFrecuenciaUso ();
				try {
					getRefGestorH().getRefVp().getEscritorio().getSelectedFrame().addMouseListener(new MouseAdapter() {

						private Point ini = new Point(0, 0);
						private Point fin = new Point(100, 100);

						public Point getIni() { return ini;	}
						public void setIni(Point ini) { this.ini = ini; }

						public Point getFin() { return fin; }
						public void setFin(Point fin) { this.fin = fin; }

						@Override
						public void mousePressed(MouseEvent click) {
							try {
								setIni(new Point(click.getX(), click.getY()));
							} catch (Exception e) {}
						}

						@Override
						public void mouseReleased(MouseEvent click) {
							try {
								setFin(new Point(click.getX(), click.getY()));
								getOpEditar().ampliarSubImagen (getIni(), getFin());
							} catch (Exception e) { }
						}
					});

				} catch (Exception e) {}
			}
		});*/

	}

}
