package herramientas;

import gestores.GestorHerramientas;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.border.LineBorder;

import componentesGraficosHerramientas.VentanaEspecificacionH;
import componentesGraficosHerramientas.VentanaTransfTramos;
import componentesInternos.MiBoton;

@SuppressWarnings("serial")
public class HLineales extends Herramienta {

	private VentanaTransfTramos vTramos;
	private VentanaEspecificacionH vEspecificacion;
	private ArrayList<MiBoton> Botones;

	public VentanaTransfTramos getvTramos() { return vTramos; }
	public void setvTramos(VentanaTransfTramos vTramos) { this.vTramos = vTramos; }

	public VentanaEspecificacionH getvEspecificacion() { return vEspecificacion; }
	public void setvEspecificacion(VentanaEspecificacionH vEsp) { this.vEspecificacion = vEsp; }
	
	public ArrayList<MiBoton> getBotones() { return Botones; }
	public void setBotones(ArrayList<MiBoton> botones) { Botones = botones; }
	
	public HLineales(GestorHerramientas refGestorH) {
		super(refGestorH);
		setBackground(Color.GRAY);
		iniciarBotones();
		setVisible(false);
	}

	private void iniciarBotones () {

		MiBoton tramos = new MiBoton("Especif. de la imagen por tramos", 11);
		tramos.setToolTipText("Permite definir la forma en la que los valores se eligir�n");
		tramos.setBounds(20, 50, 200, 40);
		tramos.setBackground(Color.WHITE);

		setBotones(new ArrayList<MiBoton>());
		getBotones().add (tramos);

		getBotones().get(0).addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent b) {
				if (getRefGestorH().getRefVp().getGestorSubVentanas().getRefSubVentActual() != null)
					setvTramos(new VentanaTransfTramos(getRefGestorH().getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg(), getRefGestorH().getRefVp()));
			}
		});


		MiBoton especificacion = new MiBoton("Especif. del histograma", 8);
		especificacion.setToolTipText("Permite modificar una imagen dado un histograma acumulativo");
		especificacion.setBounds(20, 110, 200, 40);
		especificacion.setBackground(Color.WHITE);
		getBotones().add (especificacion);
		
		getBotones().get(1).addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent b) {
				setvEspecificacion(new VentanaEspecificacionH(getRefGestorH().getRefVp()));
			}
		});
		
		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setBorder(new LineBorder(Color.BLACK, 2));
			add (getBotones().get(i));
		}

	}
	
}
