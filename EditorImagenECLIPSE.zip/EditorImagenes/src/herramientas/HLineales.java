package herramientas;

import gestores.GestorHerramientas;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.border.LineBorder;

import componentes.MiBoton;
import componentes.VentanaTransfTramos;

@SuppressWarnings("serial")
public class HLineales extends Herramienta {

	private ArrayList<MiBoton> botones = new ArrayList<MiBoton>();
	private VentanaTransfTramos vTramos;
	
	public void setBotones(ArrayList<MiBoton> botones) { this.botones = botones; }
	public ArrayList<MiBoton> getBotones() { return null; }
	
	public VentanaTransfTramos getvTramos() { return vTramos; }
	public void setvTramos(VentanaTransfTramos vTramos) { this.vTramos = vTramos; }
	
	public HLineales(GestorHerramientas refGestorH) {
		super(refGestorH);
		setBackground(Color.GRAY);
		
		setLayout(null);
		iniciarBotones();
		setVisible(false);
	}

	private void iniciarBotones () {
		

		MiBoton tramos = new MiBoton("Especif. de la imagen por tramos", 7);
		tramos.setToolTipText("Permite definir la forma en la que los valores se eligir�n");
		tramos.setBounds(20, 50, 200, 40);
		tramos.setBackground(Color.WHITE);

		// ARREGLAR!! NO ME DIO TIEMPOO :)
		if (getBotones() != null) { 
			getBotones().add (tramos);

		getBotones().get(0).addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent b) {
				setvTramos(new VentanaTransfTramos());
			}
		});
		
		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setBorder(new LineBorder(Color.BLACK, 2));
			add (getBotones().get(i));
		}
	}
	}
}
