package herramientas;

import gestores.GestorHerramientas;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.border.LineBorder;

import componentesGraficosHerramientas.SubVentana;
import componentesGraficosHerramientas.VentanaBrilloContraste;
import componentesInternos.MiBoton;

@SuppressWarnings("serial")
public class HRealce extends Herramienta {

	private ArrayList<MiBoton> botones;
	private VentanaBrilloContraste vBrilloCont;

	public ArrayList<MiBoton> getBotones() { return botones; }
	public void setBotones(ArrayList<MiBoton> botones) { this.botones = botones; }

	public VentanaBrilloContraste getvBrilloCont() { return vBrilloCont; }
	public void setvBrilloCont(VentanaBrilloContraste vBrilloCont) { this.vBrilloCont = vBrilloCont; }
	
	public HRealce(GestorHerramientas refGestorH) {
		super(refGestorH);
		//setvBrilloCont(new VentanaBrilloContraste(getRefGestorH().getRefVp()));
		iniciarBotones();
		definirEstiloPanel();
		crearOyentesBotones();
		setVisible(false);
	}
	
	private void iniciarBotones () {
		setBotones(new ArrayList<MiBoton>());

		// Reservar memoria para el objeto que realiza las operaciones indicadas
		MiBoton bBrillo = new MiBoton("Brillo", 0);
		bBrillo.setToolTipText("Muestra una imagen para modificr los valores de BRILLO / CONTRASTE");
		bBrillo.setBounds(20, 50, 200, 40);
		bBrillo.setBackground(Color.WHITE);

		getBotones().add (bBrillo);
		
		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setBorder(new LineBorder(Color.BLACK, 2));
			add (getBotones().get(i));
		}
	}

	private void definirEstiloPanel () {
		// Poner todo lo relacionado con dar estilo al panel
		setBackground(Color.GRAY);
	}

	private void crearOyentesBotones () {
		// Oyente para el bot�n del brillo
		getBotones().get(0).addActionListener(new ActionListener() {
			
			public BufferedImage copiar (SubVentana original) {
				BufferedImage temp = new BufferedImage(original.getRefBufImg().getWidth(), original.getRefBufImg().getHeight(),
						original.getRefBufImg().getType());
				for (int i = 0; i < temp.getWidth(); ++i) {
					for (int j = 0; j < temp.getHeight(); ++j){
						temp.setRGB(i, j, original.getRefBufImg().getRGB(i, j));
					}
				}
				return temp;
			}
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (getRefGestorH().getRefVp().getGuiInteligente() != null) {
					getBotones().get(0).aumentaFrecuenciaUso ();
					getRefGestorH().getRefVp().getGuiInteligente().ranking();
				}
				if (!getRefGestorH().getRefVp().getGestorSubVentanas().getSubVentanas().isEmpty()) {
					if (getvBrilloCont() == null)
						setvBrilloCont(new VentanaBrilloContraste(getRefGestorH().getRefVp()));
					getvBrilloCont().setVisible(true);
					BufferedImage copia = copiar(getRefGestorH().getRefVp().getGestorSubVentanas().getRefSubVentActual());
					getRefGestorH().getRefVp().getGestorSubVentanas().crearSubVentana(copia, 
							"Brillo/Contraste - " + getRefGestorH().getRefVp().getGestorSubVentanas().getRefSubVentActual().getTitle(), 
							false);
					
					// Volvemos a cojer el id de la ventana actual porque a�adimos la nueva del brillo
					//getvBrilloCont().inicializarValoresSinBrillo(getRefGestorH().getRefVp().getGestorSubVentanas().getRefSubVentActual());		
				} 
			}
		});
	}

}
