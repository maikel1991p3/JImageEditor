package herramientas;

import gestores.GestorHerramientas;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;

import operaciones.OpRealce;

@SuppressWarnings("serial")
public class HRealce extends Herramienta {

	private ArrayList<JButton> botones;
	private OpRealce opRealce;

	public ArrayList<JButton> getBotones() { return botones; }
	public void setBotones(ArrayList<JButton> botones) { this.botones = botones; }

	public OpRealce getOpRealce() {	return opRealce; }
	public void setOpRealce(OpRealce opRealce) { this.opRealce = opRealce; }
	
	public HRealce(GestorHerramientas refGestorH) {
		super(refGestorH);
		iniciarBotones();
		definirEstiloPanel();
		crearOyentesBotones();
	}
	
	private void iniciarBotones () {
		setBotones(new ArrayList<JButton>());

		// Reservar memoria para el objeto que realiza las operaciones indicadas
		setOpRealce (new OpRealce(getRefGestorH().getRefVp()));

		JButton bBrillo = new JButton("Brillo");
		bBrillo.setBounds(20, 50, 200, 40);
		bBrillo.setBackground(Color.WHITE);

		JButton bContraste = new JButton("Contraste");
		bContraste.setBounds(20, 120, 200, 40);
		bContraste.setBackground(Color.WHITE);

		getBotones().add (bBrillo);
		getBotones().add (bContraste);

		for (int i = 0; i < getBotones().size(); ++i)
			add (getBotones().get(i));
	}

	private void definirEstiloPanel () {
		// Poner todo lo relacionado con dar estilo al panel
		setBackground(Color.GRAY);
	}

	private void crearOyentesBotones () {
		// Oyente para el bot�n del brillo
		getBotones().get(0).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// ordena a calcular brillo para la imagen actual
				boolean calculado = getOpRealce().calcularBrillo();
				if (calculado)
					getOpRealce().representarBillo();
				else
					getOpRealce().indicarError ();
			}
		});
		
		// Oyente para el bot�n del contraste
		getBotones().get(1).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// ordena a calcular contrate para la imagen actual
				boolean calculado = getOpRealce().calcularContraste();
				if (calculado)
					getOpRealce().representarContraste();
				else
					getOpRealce().indicarError ();
			}
		});
	}

}
