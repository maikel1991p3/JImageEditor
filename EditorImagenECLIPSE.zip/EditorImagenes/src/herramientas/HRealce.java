package herramientas;

import gestores.GestorHerramientas;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.border.LineBorder;

import componentes.MiBoton;
import componentes.SubVentana;
import componentes.VentanaBrilloContraste;

@SuppressWarnings("serial")
public class HRealce extends Herramienta {

	private ArrayList<MiBoton> botones;
	private VentanaBrilloContraste vBrilloCont;

	public ArrayList<MiBoton> getBotones() { return botones; }
	public void setBotones(ArrayList<MiBoton> botones) { this.botones = botones; }

	public VentanaBrilloContraste getvBrilloCont() { return vBrilloCont; }
	public void setvBrilloCont(VentanaBrilloContraste vBrilloCont) { this.vBrilloCont = vBrilloCont; }
	
	public HRealce(GestorHerramientas refGestorH) {
		super(refGestorH);
		setvBrilloCont(new VentanaBrilloContraste(getRefGestorH().getRefVp()));
		iniciarBotones();
		definirEstiloPanel();
		crearOyentesBotones();
		setVisible(false);
	}
	
	private void iniciarBotones () {
		setBotones(new ArrayList<MiBoton>());

		// Reservar memoria para el objeto que realiza las operaciones indicadas
		MiBoton bBrillo = new MiBoton("Brillo");
		bBrillo.setToolTipText("Muestra una imagen para modificr los valores de BRILLO / CONTRASTE");
		bBrillo.setBounds(20, 50, 200, 40);
		bBrillo.setBackground(Color.WHITE);

		MiBoton bContraste = new MiBoton("Contraste");
		bContraste.setBounds(20, 120, 200, 40);
		bContraste.setBackground(Color.WHITE);

		getBotones().add (bBrillo);
		getBotones().add (bContraste);

		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setBorder(new LineBorder(Color.BLACK, 2));
			add (getBotones().get(i));
		}
	}

	private void definirEstiloPanel () {
		// Poner todo lo relacionado con dar estilo al panel
		setBackground(Color.GRAY);
	}

	private void crearOyentesBotones () {
		// Oyente para el bot�n del brillo
		getBotones().get(0).addActionListener(new ActionListener() {
			
			public BufferedImage copiar (SubVentana original) {
				BufferedImage temp = new BufferedImage(original.getRefBufImg().getWidth(), original.getRefBufImg().getHeight() ,original.getRefBufImg().getType());
				for (int i = 0; i < temp.getWidth(); ++i) {
					for (int j = 0; j < temp.getHeight(); ++j){
						temp.setRGB(i, j, original.getRefBufImg().getRGB(i, j));
					}
				}
				return temp;
			}
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getBotones().get(0).aumentaFrecuenciaUso ();
				if (!getRefGestorH().getRefVp().getGestorSubVentanas().getSubVentanas().isEmpty()) {
					getvBrilloCont().setVisible(true);
					int nVAct = getRefGestorH().getRefVp().getGestorSubVentanas().getNumVentActual();
					BufferedImage copia = copiar(getRefGestorH().getRefVp().getGestorSubVentanas().getSubVentanas().get(nVAct));
					getRefGestorH().getRefVp().getGestorSubVentanas().crearSubVentana(copia, 
							getRefGestorH().getRefVp().getGestorSubVentanas().getSubVentanas().size(), 
							"Brillo/Contraste - " + getRefGestorH().getRefVp().getGestorSubVentanas().getSubVentanas().get(nVAct).getTitle(), false);
					
					// Volvemos a cojer el id de la ventana actual porque a�adimos la nueva del brillo
					int nVen = getRefGestorH().getRefVp().getGestorSubVentanas().getNumVentActual();
					getvBrilloCont().inicializarValoresSinBrillo(getRefGestorH().getRefVp().getGestorSubVentanas().getSubVentanas().get(nVen));
					
					
				} 
			}
			

		});
		
		// Oyente para el bot�n del contraste
		getBotones().get(1).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {

				getBotones().get(0).aumentaFrecuenciaUso ();
				// ordena a calcular contrate para la imagen actual
				//getvBrilloCont().setVisible(true);
			}
		});
	}

}
