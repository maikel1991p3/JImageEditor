package herramientas;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import operaciones.OpDirectas;
import componentes.SubVentana;
import componentes.VentanaBrilloContraste;
import componentes.VentanaCorrecGamma;
import gestores.GestorHerramientas;

@SuppressWarnings("serial")
public class HDirectas extends Herramienta {

	private ArrayList<JButton> botones;
	private VentanaCorrecGamma vCorrecGamma;
	private OpDirectas opDirectas;

	private VentanaPrincipal refVp;

	public ArrayList<JButton> getBotones() { return botones; }
	public void setBotones(ArrayList<JButton> botones) { this.botones = botones; }

	public VentanaCorrecGamma getvCorrecGamma() { return vCorrecGamma; }
	public void setvCorrecGamma(VentanaCorrecGamma vCorrecGamma) { this.vCorrecGamma = vCorrecGamma; }

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }

	public OpDirectas getOpDirectas() { return opDirectas; }
	public void setOpDirectas(OpDirectas opDirectas) { this.opDirectas = opDirectas; }

	public HDirectas(GestorHerramientas refGestorH) {
		super(refGestorH);
		setRefVp(refGestorH.getRefVp());
		setvCorrecGamma(new VentanaCorrecGamma(getRefVp()));
		setOpDirectas(new OpDirectas(getRefVp()));
		iniciarBotones();
		crearOyentesBotones();
		setBackground(Color.GRAY);
		setVisible(false);
	}

	private void iniciarBotones () {
		setBotones(new ArrayList<JButton>());

		// Reservar memoria para el objeto que realiza las operaciones indicadas
		JButton negat = new JButton("Negativizar");
		negat.setBounds(20, 50, 200, 40);
		negat.setBackground(Color.WHITE);

		getBotones().add (negat);

		JButton umbral = new JButton("Umbralizar");
		umbral.setBounds(20, 150, 200, 40);
		umbral.setBackground(Color.WHITE);

		getBotones().add (umbral);

		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setBorder(new LineBorder(Color.BLACK, 2));
			add (getBotones().get(i));
		}
	}

	private void crearOyentesBotones () {
		// Oyente para el bot�n de negativizar
		getBotones().get(0).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (!getRefVp().getGestorSubVentanas().getSubVentanas().isEmpty()) {
					int nVAct = getRefGestorH().getRefVp().getGestorSubVentanas().getNumVentActual();

					getRefGestorH().getRefVp().getGestorSubVentanas().crearSubVentana(getOpDirectas().negativizar(getRefVp().getGestorSubVentanas().getSubVentanas().get(nVAct).getRefBufImg()),
							nVAct + 1, getRefVp().getGestorSubVentanas().getSubVentanas().get(nVAct).getName(),false);


				} 
			}
		});

		getBotones().get(1).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!getRefVp().getGestorSubVentanas().getSubVentanas().isEmpty()) {
					final JDialog umbral = new JDialog();
					umbral.setTitle("UMBRAL");
					umbral.setBounds(200, 200, 200, 100);
					umbral.setLayout(null);
					umbral.setAlwaysOnTop(true);
					umbral.setResizable(false);

					JLabel etiq = new JLabel("Umbral:");
					etiq.setBounds(20, 20, 50, 30);
					umbral.add(etiq);

					final JTextField leer = new JTextField();
					leer.addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent arg0) {
							try {
								int nVen = getRefVp().getGestorSubVentanas().getNumVentActual();
								getRefVp().getGestorSubVentanas().crearSubVentana(getOpDirectas().umbralizar(getRefVp().getGestorSubVentanas().getSubVentanas().get(nVen).getRefBufImg(), Integer.parseInt(leer.getText())), nVen + 1, getRefVp().getGestorSubVentanas().getSubVentanas().get(nVen).getName(), false);
								umbral.dispose ();
							} catch (Exception e) {}
						}
					});

					leer.setBounds(90, 20, 30, 30);
					umbral.add(leer);
					umbral.setAlwaysOnTop(true);
					umbral.setVisible(true);
				}
			}
		});
	}
}
