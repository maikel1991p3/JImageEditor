package herramientas;

import gestores.GestorHerramientas;
import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import operaciones.OpDirectas;
import operaciones.OpMapaCambios;

import componentesGraficosHerramientas.VentanaCorrecGamma;
import componentesGraficosHerramientas.VentanaMapaCambios;
import componentesInternos.MiBoton;

@SuppressWarnings("serial")
public class HDirectas extends Herramienta {

	private ArrayList<MiBoton> botones;
	private VentanaCorrecGamma vCorrecGamma;
	private OpDirectas opDirectas;
	private VentanaPrincipal refVp;
	private OpMapaCambios opMapaCambios;
	private VentanaMapaCambios ventanaMapaCambios;

	public ArrayList<MiBoton> getBotones() { return botones; }
	public void setBotones(ArrayList<MiBoton> botones) { this.botones = botones; }

	public VentanaCorrecGamma getvCorrecGamma() { return vCorrecGamma; }
	public void setvCorrecGamma(VentanaCorrecGamma vCorrecGamma) { this.vCorrecGamma = vCorrecGamma; }

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }

	public OpDirectas getOpDirectas() { return opDirectas; }
	public void setOpDirectas(OpDirectas opDirectas) { this.opDirectas = opDirectas; }

	public OpMapaCambios getOpMapaCambios() { return opMapaCambios; }
	public void setOpMapaCambios(OpMapaCambios opMapaCambios) { this.opMapaCambios = opMapaCambios; }

	public VentanaMapaCambios getVentanaMapaCambios() { return ventanaMapaCambios; }
	public void setVentanaMapaCambios(VentanaMapaCambios ventanaMapaCambios) { this.ventanaMapaCambios = ventanaMapaCambios; }

	public HDirectas(GestorHerramientas refGestorH) {
		super(refGestorH);
		setRefVp(refGestorH.getRefVp());
		setvCorrecGamma(new VentanaCorrecGamma(getRefVp()));
		setOpDirectas(new OpDirectas(getRefVp()));
		setOpMapaCambios(new OpMapaCambios(getRefVp()));
		iniciarBotones();
		crearOyentesBotones();
		setBackground(Color.GRAY);
		setVisible(false);
	}

	private void iniciarBotones () {
		setBotones(new ArrayList<MiBoton>());

		// Reservar memoria para el objeto que realiza las operaciones indicadas
		MiBoton negat = new MiBoton("Negativizar", 8);
		negat.setToolTipText("Negativizar: invierte el valor de los coloes de cada p�xel");
		negat.setBounds(20, 20, 200, 40);
		negat.setBackground(Color.WHITE);

		getBotones().add (negat);

		MiBoton umbral = new MiBoton("Umbralizar", 9);
		umbral.setToolTipText("Umbralizar: binariza la imagen en torno a un umbral");
		umbral.setBounds(20, 120, 200, 40);
		umbral.setBackground(Color.WHITE);

		getBotones().add (umbral);

		/*Boton para la operacion mapa de cambios*/
		MiBoton mapa =  new MiBoton("M.Cambios", 10);
		mapa.setToolTipText("Diferencias / Cambios: Genera un mapa de cambios / diferencias entre dos im�genes");
		mapa.setBounds(20, 220, 200, 40);
		mapa.setBackground(Color.WHITE);

		getBotones().add (mapa);

		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setBorder(new LineBorder(Color.BLACK, 2));
			add (getBotones().get(i));
		}
	}

	private void crearOyentesBotones () {
		// Oyente para el bot�n de negativizar
		getBotones().get(0).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (getRefVp().getGuiInteligente() != null) {
					getBotones().get(0).aumentaFrecuenciaUso ();
					getRefVp().getGuiInteligente().ranking();
				}
				if (!getRefVp().getGestorSubVentanas().getSubVentanas().isEmpty()) {
					getRefGestorH().getRefVp().getGestorSubVentanas().crearSubVentana(getOpDirectas().negativizar(getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg()),
							"Negativizada - " + getRefVp().getGestorSubVentanas().getRefSubVentActual().getTitle(), false);


				} 
			}

		});

		getBotones().get(1).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (getRefVp().getGuiInteligente() != null) {
					getBotones().get(1).aumentaFrecuenciaUso ();
					getRefVp().getGuiInteligente().ranking();
				}
				if (!getRefVp().getGestorSubVentanas().getSubVentanas().isEmpty()) {
					final JDialog umbral = new JDialog();
					umbral.setTitle("UMBRAL");
					umbral.setBounds(200, 200, 200, 100);
					umbral.setLayout(null);
					umbral.setAlwaysOnTop(true);
					umbral.setResizable(false);

					JLabel etiq = new JLabel("Umbral:");
					etiq.setBounds(20, 20, 50, 30);
					umbral.add(etiq);

					final JTextField leer = new JTextField();
					leer.addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent arg0) {
							try {
								int valor = Integer.parseInt(leer.getText());
								if (valor > 0 && valor < 256) {
									getRefVp().getGestorSubVentanas().crearSubVentana(getOpDirectas().umbralizar(getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg(), valor),
											"Umbralizada - " + getRefVp().getGestorSubVentanas().getRefSubVentActual().getTitle(), false);
									umbral.dispose ();
								} else {
									JDialog error = new JDialog();
									JLabel mensaje = new JLabel("AVISO: Indique un umbral entre 0 y 255!!");
									error.setSize(400, 100);
									error.setLocation(200, 200);
									error.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
									error.setAlwaysOnTop(true);
									error.add(mensaje);
									error.setVisible(true);
								}
							} catch (Exception e) {}
						}
					});

					leer.setBounds(90, 20, 30, 30);
					umbral.add(leer);
					umbral.setAlwaysOnTop(true);
					umbral.setVisible(true);
				}
			}

		});

		getBotones().get(2).addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				setVentanaMapaCambios(new VentanaMapaCambios(getRefVp()));
				if (getRefVp().getGuiInteligente() != null) {
					getBotones().get(2).aumentaFrecuenciaUso ();
					getRefVp().getGuiInteligente().ranking();
				}
				if (!getRefVp().getGestorSubVentanas().getSubVentanas().isEmpty())
					getVentanaMapaCambios().setVisible(true);
			}

		});
	}

}
