package herramientas;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;

import operaciones.OpHistogramas;
import gestores.GestorHerramientas;

@SuppressWarnings("serial")
public class HHistogramas extends Herramienta {

	private ArrayList<JButton> botones;
	private OpHistogramas opHist;

	public ArrayList<JButton> getBotones() { return botones; }
	public void setBotones(ArrayList<JButton> botones) { this.botones = botones; }

	public OpHistogramas getOpHist() { return opHist; }
	public void setOpHist(OpHistogramas opHist) { this.opHist = opHist; }

	public HHistogramas(GestorHerramientas refGestorH) {
		super(refGestorH);
		iniciarBotones();
		definirEstiloPanel();
		crearOyentesBotones();
	}

	private void iniciarBotones () {
		setBotones(new ArrayList<JButton>());

		// Reservar memoria para el objeto que realia las operaciones indicadas
		setOpHist(new OpHistogramas(getRefGestorH().getRefVp().getEscritorio()));

		JButton bHistAbs = new JButton("Histograma Absoluto");
		bHistAbs.setBounds(20, 50, 200, 50);
		bHistAbs.setBackground(Color.WHITE);

		JButton bHistAcum = new JButton("Histograma Acumulativo");
		bHistAcum.setBounds(20, 150, 200, 50);
		bHistAcum.setBackground(Color.WHITE);

		getBotones().add (bHistAbs);
		getBotones().add (bHistAcum);

		for (int i = 0; i < getBotones().size(); ++i)
			add (getBotones().get(i));
	}

	private void definirEstiloPanel () {
		// Poner todo lo relacionado con dar estilo al panel
		setBackground(Color.GRAY);
	}

	private void crearOyentesBotones () {
		// Oyente para el bot�n del histograma Absoluto
		getBotones().get(0).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// ordena a calcular el histograma absoluto de la imagen actual
				//boolean calculado = getOpHist().calcularHistogramaAbs();
				//if (calculado)
				getOpHist().representarHistogramaAbs ();
				//else
					//getOpHist().indicarError ();
			}
		});
		
		// Oyente para el bot�n del histograma Acumulativo
		getBotones().get(1).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// ordena a calcular el histograma absoluto de la imagen actual
				boolean calculado = getOpHist().calcularHistogramaRel();
				if (calculado)
					getOpHist().representarHistogramaRel ();
				else
					getOpHist().indicarError ();
			}
		});
	}

}
