package herramientas;

import gestores.GestorHerramientas;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.border.LineBorder;

import operaciones.OpHistogramas;

import componentes.MiBoton;

@SuppressWarnings("serial")
public class HHistogramas extends Herramienta {

	private ArrayList<MiBoton> botones;
	private OpHistogramas opHist;

	public ArrayList<MiBoton> getBotones() { return botones; }
	public void setBotones(ArrayList<MiBoton> botones) { this.botones = botones; }

	public OpHistogramas getOpHist() { return opHist; }
	public void setOpHist(OpHistogramas opHist) { this.opHist = opHist; }

	public HHistogramas(GestorHerramientas refGestorH) {
		super(refGestorH);
		iniciarBotones();
		definirEstiloPanel();
		crearOyentesBotones();
		setVisible(false);
	}

	private void iniciarBotones () {
		setBotones(new ArrayList<MiBoton>());

		// Reservar memoria para el objeto que realia las operaciones indicadas
		setOpHist(new OpHistogramas(getRefGestorH().getRefVp()));

		MiBoton bHistAbs = new MiBoton("Histograma Absoluto");
		bHistAbs.setToolTipText("Permite viualizar el HISTOGRAMA ABSOLUTO de la imagen actual");
		bHistAbs.setBounds(20, 50, 200, 50);
		bHistAbs.setBackground(Color.WHITE);

		MiBoton bHistAcum = new MiBoton("Histograma Acumulativo");
		bHistAcum.setToolTipText("Permite viualizar el HISTOGRAMA ACUMULATIVO de la imagen actual");
		bHistAcum.setBounds(20, 150, 200, 50);
		bHistAcum.setBackground(Color.WHITE);

		getBotones().add (bHistAbs);
		getBotones().add (bHistAcum);

		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setBorder(new LineBorder(Color.BLACK, 2));
			add (getBotones().get(i));
		}
	}

	private void definirEstiloPanel () {
		// Poner todo lo relacionado con dar estilo al panel
		setBackground(Color.GRAY);
	}

	private void crearOyentesBotones () {
		// Oyente para el bot�n del histograma Absoluto
		getBotones().get(0).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getBotones().get(0).aumentaFrecuenciaUso ();
				try {
					getOpHist().representarHistogramaAbs ();
				} catch (Exception e) { }
			}
		});

		// Oyente para el bot�n del histograma Acumulativo
		getBotones().get(1).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getBotones().get(1).aumentaFrecuenciaUso ();
				try {
					getOpHist().representarHistogramaAc();
				} catch (Exception e) { }
			}
		});
	}

}
