package componentes;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.JInternalFrame;

@SuppressWarnings("serial")
public class SubVentana extends JInternalFrame {
	private final int TAM_HIST = 256;

	private BufferedImage refBufImg;
	private int [] Histograma = new int[TAM_HIST];
	double entropia = 0.0;

	public BufferedImage getRefBufImg() { return refBufImg; }
	public void setRefBufImg(BufferedImage refBufImg) { this.refBufImg = refBufImg; }

	public int[] getHistograma() { return Histograma; }
	public void setHistograma(int[] histograma) { Histograma = histograma; }
	
	public double getEntropia() { return entropia; }
	public void setEntropia(double entropia) { this.entropia = entropia; }
	
	public SubVentana(BufferedImage b, String nom) {
		super ("", true, true, false, true);
		setVisible(true);
		
		setRefBufImg(b);
		//obtenerHistograma(getRefBufImg());
		setLayout(null);
		setBounds(0, 0, getRefBufImg().getWidth(), getRefBufImg().getHeight());
		setResizable(false);
		setDefaultCloseOperation(JInternalFrame.HIDE_ON_CLOSE);

		setVisible(true);
		
		
		PanelSubVentana panel = new PanelSubVentana(getRefBufImg());
		panel.setBounds(0, 0, getRefBufImg().getWidth(), getRefBufImg().getHeight());

		add (panel);

	}
	
	public SubVentana(BufferedImage ventana, BufferedImage imag, String nom) {
		super ("", true, true, false, true);
		setVisible(true);
		
		setRefBufImg(imag);
		//obtenerHistograma(getRefBufImg());
		setLayout(null);
		setBounds(0, 0, ventana.getWidth(), ventana.getHeight());
		setResizable(false);
		setDefaultCloseOperation(JInternalFrame.HIDE_ON_CLOSE);
		
		setVisible(true);
		
		
		PanelSubVentana panel = new PanelSubVentana(getRefBufImg());
		panel.setBounds(0, 0, ventana.getWidth(), ventana.getHeight());

		add (panel);

	}
	
	public void obtenerHistograma (BufferedImage img) {
		if (img != null) {
			for (int k = 0; k < TAM_HIST; ++k)
				getHistograma()[k] = 0;
				
			int ancho = img.getWidth();
			int alto = img.getHeight();
			int colorTemp = 0;
			for (int i = 0; i < ancho; ++i) {
				for (int j = 0; j < alto; ++j) {
					colorTemp = new Color(img.getRGB(i, j)).getRed();
					getHistograma()[colorTemp] += 1;
					System.out.println("H["+colorTemp+"] = " + getHistograma()[colorTemp]);
				}
			}
		}
		obtenerEntropia();
	}
	
	public void obtenerEntropia () {
		double prob = 0.0;
		double entropia = 0.0;
		int size = getHistograma().length;
		for (int i = 0; i < size; ++i) {
			prob = getHistograma()[i] / 256;
			entropia += -(prob * (Math.log10(prob) / Math.log10(2)));
		}
		setEntropia(entropia);
	}
}
