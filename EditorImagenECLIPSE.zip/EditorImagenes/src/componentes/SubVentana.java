package componentes;

import java.awt.image.BufferedImage;

import javax.swing.JInternalFrame;

@SuppressWarnings("serial")
public class SubVentana extends JInternalFrame {

	private BufferedImage refBufImg;

	public BufferedImage getRefBufImg() { return refBufImg; }
	public void setRefBufImg(BufferedImage refBufImg) { this.refBufImg = refBufImg; }

	public SubVentana(BufferedImage b, String nom) {
		super ("", true, true, false, true);
		setVisible(true);
		
		setRefBufImg(b);
		setLayout(null);
		setBounds(0, 0, getRefBufImg().getWidth(), getRefBufImg().getHeight());
		setResizable(false);
		setDefaultCloseOperation(JInternalFrame.HIDE_ON_CLOSE);
		
		setVisible(true);
		
		
		PanelSubVentana panel = new PanelSubVentana(getRefBufImg());
		panel.setBounds(0, 0, getRefBufImg().getWidth(), getRefBufImg().getHeight());

		add (panel);

	}
	
}
