package componentes;

import java.awt.Color;
import java.awt.image.BufferedImage;

import javax.swing.JInternalFrame;

@SuppressWarnings("serial")
public class SubVentana extends JInternalFrame {
	private final int TAM_HIST = 256;

	private PanelSubVentana panel;
	private BufferedImage refBufImg;
	private int [] HistogramaAbs = new int[TAM_HIST];
	private int [] HistogramaAc = new int[TAM_HIST];
	double entropia = 0.0;
	double brillo = 0.0;
	double contraste = 0.0;
	int id = 0;
	Boolean imgOriginal = new Boolean(true);
	
	public PanelSubVentana getPanel() { return panel; }
	public void setPanel(PanelSubVentana panel) { this.panel = panel; }
	
	public int[] getHistogramaAc() { return HistogramaAc; }
	public void setHistogramaAc(int[] histogramaAc) { HistogramaAc = histogramaAc; }
	
	public BufferedImage getRefBufImg() { return refBufImg; }
	public void setRefBufImg(BufferedImage refBufImg) { this.refBufImg = refBufImg; }

	public int[] getHistogramaAbs() { return HistogramaAbs; }
	public void setHistogramaAbs(int[] histograma) { HistogramaAbs = histograma; }
	
	public double getEntropia() { return entropia; }
	public void setEntropia(double entropia) { this.entropia = entropia; }
	
	public double getBrillo() {	return brillo; }
	public void setBrillo(double brillo) { this.brillo = brillo; }
	
	public double getContraste() { return contraste; }
	public void setContraste(double contraste) { this.contraste = contraste; }
	
	public int getId() { return id;}
	public void setId(int id) { this.id = id; }
	
	public Boolean getImgOriginal() { return imgOriginal; }
	public void setImgOriginal(Boolean imgOriginal) { this.imgOriginal = imgOriginal; }
	
	public SubVentana(BufferedImage b, int id, String nombre) {
		super (nombre, true, true, false, true);
		setVisible(true);
		setId (id);
		setImgOriginal(false);
		setRefBufImg(b);
		obtenerHistograma(getRefBufImg());
		setLayout(null);
		setBounds(0, 0, getRefBufImg().getWidth(), getRefBufImg().getHeight());
		setResizable(false);
		setDefaultCloseOperation(JInternalFrame.HIDE_ON_CLOSE);

		setVisible(true);
		
		setPanel(new PanelSubVentana(getRefBufImg()));
		getPanel().setBounds(0, 0, getRefBufImg().getWidth(), getRefBufImg().getHeight());

		add (getPanel());

	}
	
	public SubVentana(BufferedImage ventana, BufferedImage imag, String nombre) {
		super (nombre, true, true, false, true);
		setVisible(true);
		
		setRefBufImg(imag);
		obtenerHistograma(getRefBufImg());
		setLayout(null);
		setBounds(0, 0, ventana.getWidth(), ventana.getHeight());
		setResizable(false);
		setDefaultCloseOperation(JInternalFrame.HIDE_ON_CLOSE);
		
		setVisible(true);
		
		
		PanelSubVentana panel = new PanelSubVentana(getRefBufImg());
		panel.setBounds(0, 0, ventana.getWidth(), ventana.getHeight());

		add (panel);

	}
	
	public void obtenerHistograma (BufferedImage img) {
		if (img != null) {
			for (int k = 0; k < TAM_HIST; ++k)
				getHistogramaAbs()[k] = 0;
				
			int ancho = img.getWidth();
			int alto = img.getHeight();
			int colorTemp = 0;
			for (int i = 0; i < ancho; ++i) {
				for (int j = 0; j < alto; ++j) {
					colorTemp = new Color(img.getRGB(i, j)).getRed();
					getHistogramaAbs()[colorTemp] += 1;
				}
			}
			obtenerHistogramaAc();
			obtenerEntropia();
			obtenerBrillo();
			obtenerContraste();
		}
		
	}
	
	public void obtenerHistogramaAc () {
		getHistogramaAc()[0] = getHistogramaAbs()[0];
		for (int i = 1; i < getHistogramaAbs().length; ++i) {
			getHistogramaAc()[i] = getHistogramaAc()[i - 1] + getHistogramaAbs()[i];
		}
	}
	
	public void obtenerEntropia () {
		double prob = 0.0;
		double ent = 0.0;
		double size = getRefBufImg().getWidth() * getRefBufImg().getHeight();
		for (int i = 0; i < getHistogramaAbs().length; ++i) {
			if (getHistogramaAbs()[i] != 0) {
				prob = getHistogramaAbs()[i] / size;
				ent += (-prob * (Math.log10(prob) / Math.log10(2)));
			}
		}
		setEntropia(ent);
	}
	
	public void obtenerBrillo () {
		// Media de las frecuencias de los valores del histograma
		double brill = 0.0;
		for (int i = 0; i < getHistogramaAbs().length; i++) {
			brill += getHistogramaAbs()[i]*i;
		}
		setBrillo (brill / (getRefBufImg().getWidth() * getRefBufImg().getHeight()));
	}
	
	public void obtenerContraste () {
		// Desviaci�n t�pica de la distribuci�n de colores en el histograma
		double contrast = 0.0;
		for (int i = 0; i < getHistogramaAbs().length; i++) {
			contrast += (Math.pow (getHistogramaAbs()[i] - getBrillo(), 2) / (getRefBufImg().getWidth() * getRefBufImg().getHeight())); 
		}
		setContraste(Math.sqrt(contrast));
	}
}
