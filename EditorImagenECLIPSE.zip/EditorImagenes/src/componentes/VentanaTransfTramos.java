package componentes;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class VentanaTransfTramos extends JFrame {

	final int X = 100;
	final int Y = 30;
	final int ANCHO_PANELES = 300;
	final int ALTO_PANELES = 300;
	final int SEP_HOR_PANELES = 20;
	
	private PanelTramos panelTramos;
	private JPanel panelImResultado;
	
	public PanelTramos getPanelTramos() { return panelTramos; }
    public void setPanelTramos(PanelTramos panelTramos) { this.panelTramos = panelTramos;	}

	public JPanel getPanelImResultado() { return panelImResultado; }
	public void setPanelImResultado(JPanel panelImResultado) { this.panelImResultado = panelImResultado; }

	public VentanaTransfTramos() {
		iniciarVentana();
	}
	
	public void iniciarVentana () {
		setTitle("Especificaci�n de la imagen por tramos");
		setBounds(X, Y, (ANCHO_PANELES * 2) + (SEP_HOR_PANELES * 3), (ALTO_PANELES * 2) + (SEP_HOR_PANELES * 4));
		setLayout(null);
		

		iniciarPanelTramos();
		iniciarPanelImResultado();
		
		setVisible(true);
	}
	
	public void iniciarPanelTramos () {
		setPanelTramos(new PanelTramos());
		getPanelTramos().setBounds(SEP_HOR_PANELES, SEP_HOR_PANELES, ANCHO_PANELES, ALTO_PANELES);
		
		getContentPane().add(getPanelTramos());
	}
	
	public void iniciarPanelImResultado () {
		setPanelImResultado(new JPanel());
		getPanelImResultado().setBackground(Color.WHITE);
		getPanelImResultado().setBounds(this.getWidth() - SEP_HOR_PANELES - ANCHO_PANELES, SEP_HOR_PANELES, ANCHO_PANELES, ALTO_PANELES);
		getContentPane().add(getPanelImResultado());
	}

}
