package componentes;

import herramientas.HDirectas;
import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.JTextField;

import operaciones.OpMapaCambios;

@SuppressWarnings("serial")
public class VentanaMapaCambios extends JDialog {

	// Referencia a la ventana principal
	private VentanaPrincipal ventanaPrincipal;

	/*Componentes gr�ficas*/
	private JLabel clickImg1 = new JLabel("Im�gen 1. Seleccione: ");
	private JLabel clickImg2 = new JLabel("Im�gen 2. Seleccione: ");
	private JLabel uCambio = new JLabel("Umbral para cambios (Verde)");
	private JComboBox<String> leerImg1 = new JComboBox<String> ();
	private JComboBox<String> leerImg2 = new JComboBox<String> ();
	private JSlider sUmbralCambio = new JSlider();
	
	private BufferedImage bf1, bf2;
	private OpMapaCambios opMapa;

	public VentanaPrincipal getVentanaPrincipal() { return ventanaPrincipal; }
	public void setVentanaPrincipal(VentanaPrincipal ventanaPrincipal) { this.ventanaPrincipal = ventanaPrincipal; }

	public JLabel getClickImg1() { return clickImg1; }
	public void setClickImg1(JLabel clickImg1) { this.clickImg1 = clickImg1; }

	public JLabel getClickImg2() { return clickImg2; }
	public void setClickImg2(JLabel clickImg2) { this.clickImg2 = clickImg2; }

	public JLabel getuCambio() { return uCambio; }
	public void setuCambio(JLabel uCambio) { this.uCambio = uCambio; }

	public JSlider getsUmbralCambio() { return sUmbralCambio; }
	public void setsUmbralCambio(JSlider sUmbralCambio) { this.sUmbralCambio = sUmbralCambio; }

	public JComboBox<String> getLeerImg1() { return leerImg1; }
	public void setLeerImg1(JComboBox<String> leerImg1) { this.leerImg1 = leerImg1; }

	public JComboBox<String> getLeerImg2() { return leerImg2; }
	public void setLeerImg2(JComboBox<String> leerImg2) { this.leerImg2 = leerImg2; }

	public BufferedImage getBf1() { return bf1; }
	public void setBf1(BufferedImage bf1) { this.bf1 = bf1; }
	
	public BufferedImage getBf2() { return bf2;	}
	public void setBf2(BufferedImage bf2) { this.bf2 = bf2; }
	
	public OpMapaCambios getOpMapa() { return opMapa; }
	public void setOpMapa(OpMapaCambios opMapa) { this.opMapa = opMapa; }
	
	public VentanaMapaCambios (VentanaPrincipal vp) {
		setVentanaPrincipal(vp);
		inicializarComponentes();
	}

	public void inicializarComponentes() {
		/*Inicializar la ventana*/
		this.setLayout(null);
		this.getContentPane().setBackground(Color.WHITE);
		this.setSize(400, 400);
		this.setLocation(100, 100);
		this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		this.setAlwaysOnTop(true);

		/*Inicializar y a�adir componentes*/
		getClickImg1().setBounds(20, 20, 100, 50);
		getClickImg1().setBackground(Color.WHITE);
		this.add(getClickImg1());

		getClickImg2().setBounds(20, 90, 100, 50);
		getClickImg2().setBackground(Color.WHITE);
		this.add(getClickImg2());

		getLeerImg1().setBounds(150, 20, 220, 50);
		getLeerImg1().setEditable(false);
		getLeerImg1().setBackground(Color.WHITE);
		this.add(getLeerImg1());

		getLeerImg2().setBounds(150, 90, 220, 50);
		getLeerImg2().setEditable(false);
		getLeerImg2().setBackground(Color.WHITE);
		this.add(getLeerImg2());

		getuCambio().setBounds (20,160, 200, 50);
		getuCambio().setBackground(Color.WHITE);
		this.add(getuCambio());

		getsUmbralCambio().setBounds(20, 230, 350, 50);
		getsUmbralCambio().setBackground(Color.WHITE);
		getsUmbralCambio().setMinimum(10);
		getsUmbralCambio().setMaximum(100);
		getsUmbralCambio().setPaintTicks(true);
		getsUmbralCambio().setPaintTrack(true);
		getsUmbralCambio().setMajorTickSpacing(10);
		getsUmbralCambio().setMinorTickSpacing(5);
		getsUmbralCambio().setValue(255);
		getsUmbralCambio().setPaintLabels(true);
		this.add(getsUmbralCambio());

		JButton cambios = new JButton("Mapa");
		cambios.setBounds(100, 300, 100, 50);
		cambios.setBackground(Color.WHITE);
		cambios.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent it) {
				if (getLeerImg1().getSelectedItem() != null && getLeerImg2().getSelectedItem() != null
						&& getBf1() != null && getBf2() != null) {
					setOpMapa(((HDirectas)(getVentanaPrincipal().getGestorHerramientas().getHerramientas().get(4))).getOpMapaCambios ());
					
					getVentanaPrincipal().getGestorSubVentanas().crearSubVentana(getOpMapa().mapaDeCambios(getBf1(),getBf2(), getsUmbralCambio().getValue()),
							getVentanaPrincipal().getGestorSubVentanas().getNumVentActual(), "Mapa de cambios", false);

				} else {
					JDialog error = new JDialog();
					JLabel mensaje = new JLabel("Indica que dos imagenes quieres cambiar");
					error.setSize(400, 100);
					error.setLocation(200, 200);
					error.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
					error.setAlwaysOnTop(true);
					error.add(mensaje);
					error.setVisible(true);
				}
			}
		});
		this.add(cambios);

		JButton resta = new JButton("Diferencia");
		resta.setBounds(220, 300, 100, 50);
		resta.setBackground(Color.WHITE);
		resta.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (getLeerImg1().getSelectedItem() != null && getLeerImg2().getSelectedItem() != null
						&& getBf1() != null && getBf2() != null) {
					setOpMapa(((HDirectas)(getVentanaPrincipal().getGestorHerramientas().getHerramientas().get(4))).getOpMapaCambios ());
					
					getVentanaPrincipal().getGestorSubVentanas().crearSubVentana(getOpMapa().restaDeDosImagenes(getBf1(),getBf2()),
							getVentanaPrincipal().getGestorSubVentanas().getNumVentActual(), "Diferencia", false);

				} else {
					JDialog error = new JDialog();
					JLabel mensaje = new JLabel("Indica que dos imagenes quieres cambiar");
					error.setSize(400, 100);
					error.setLocation(200, 200);
					error.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
					error.setAlwaysOnTop(true);
					error.add(mensaje);
					error.setVisible(true);
				}
			}
		});
		this.add(resta);
		
		getLeerImg1().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				actualizarCombos();
				setBf1(getVentanaPrincipal().getGestorSubVentanas().getSubVentanas().get(encontrarImagenPorTitulo(getLeerImg1().getSelectedItem().toString())).getRefBufImg());
			}
		});
		
		add (getLeerImg1());
		
		getLeerImg2().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				actualizarCombos();
				setBf2(getVentanaPrincipal().getGestorSubVentanas().getSubVentanas().get(encontrarImagenPorTitulo(getLeerImg2().getSelectedItem().toString())).getRefBufImg());
			}
		});
		add(getLeerImg2());
	}
	
	public void actualizarCombos () {
		Boolean encontrado = false;
		for (int i = 0; i < getVentanaPrincipal().getGestorSubVentanas().getSubVentanas().size(); ++i) {
			encontrado = false;
			if (getLeerImg1().getItemAt(i) == getVentanaPrincipal().getGestorSubVentanas().getSubVentanas().get(i).getTitle())
				encontrado = true;
			
			if (!encontrado && getVentanaPrincipal().getGestorSubVentanas().getSubVentanas().get(i).getImgOriginal()) {
				getLeerImg1().addItem (getVentanaPrincipal().getGestorSubVentanas().getSubVentanas().get(i).getTitle());
				getLeerImg2().addItem (getVentanaPrincipal().getGestorSubVentanas().getSubVentanas().get(i).getTitle());
			}		
		}
	}
	
	public int encontrarImagenPorTitulo (String titulo) {
		for (int i = 0; i < getVentanaPrincipal().getGestorSubVentanas().getSubVentanas().size(); ++i) {
			if (getVentanaPrincipal().getGestorSubVentanas().getSubVentanas().get(i).getTitle().equals(titulo))
				return i;
		}
		return -1;
	}
}
