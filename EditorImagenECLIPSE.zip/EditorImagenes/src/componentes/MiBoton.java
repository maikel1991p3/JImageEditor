package componentes;

import javax.swing.JButton;

@SuppressWarnings("serial")
public class MiBoton extends JButton {

	private int frecuencia = 0;
	
	public int getFrecuencia() { return frecuencia; }
	public void setFrecuencia(int frecuencia) { this.frecuencia = frecuencia; }

	public MiBoton (String t) {
		super (t);
	}
	
	public void aumentaFrecuenciaUso () {
		setFrecuencia(getFrecuencia() + 1);
	}
}
