package componentes;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PanelSubVentana extends JPanel {

	private BufferedImage refBImg;
	
	public BufferedImage getRefBImg() { return refBImg;	}
	public void setRefBImg(BufferedImage refBImg) {	this.refBImg = refBImg; }

	public PanelSubVentana (BufferedImage refBImg) {
		setRefBImg(refBImg);
		if (getRefBImg() != null)
			setBounds(0, 0, getRefBImg().getWidth() - 20, getRefBImg().getHeight() - 20);
		else
			setBounds(0, 0, 200, 400);
	}
	
	protected void paintComponent (Graphics gr) {
		if (getRefBImg() == null) {
			gr.setColor (Color.BLACK);
			gr.drawRect(0, 0, getWidth(), getHeight());
			
		} else {
			gr.drawImage(getRefBImg(), 0, 0, this);
		}
	}
}
