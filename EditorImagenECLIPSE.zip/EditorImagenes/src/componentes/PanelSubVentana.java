package componentes;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PanelSubVentana extends JPanel {

	private SubVentana refSubv; // referencia a la subventana que lo aloja
	private BufferedImage refBImg;

	public BufferedImage getRefBImg() { return refBImg;	}
	public void setRefBImg(BufferedImage refBImg) {	this.refBImg = refBImg; }

	public SubVentana getRefSubv() { return refSubv; }
	public void setRefSubv(SubVentana refSubv) { this.refSubv = refSubv; }

	public PanelSubVentana (SubVentana s, BufferedImage refBImg) {
		setRefSubv(s);
		setRefBImg(refBImg);
		if (getRefBImg() != null)
			setBounds(0, 0, getRefBImg().getWidth() - 20, getRefBImg().getHeight() - 20);
		else
			setBounds(0, 0, 200, 400);

		addMouseMotionListener(new MouseMotionListener() {
			@Override
			public void mouseMoved(MouseEvent r) {
				
			}

			@Override
			public void mouseDragged(MouseEvent r) {
				if (getRefBImg() != null && r.isConsumed()) {
					getRefSubv().getRefVp().getPanelInfo().setR(new Color (getRefBImg().getRGB(r.getX(), r.getY())).getRed());
					getRefSubv().getRefVp().getPanelInfo().setG(new Color (getRefBImg().getRGB(r.getX(), r.getY())).getGreen());
					getRefSubv().getRefVp().getPanelInfo().setB(new Color (getRefBImg().getRGB(r.getX(), r.getY())).getBlue());

					getRefSubv().getRefVp().getPanelInfo().setPosX(r.getX());
					getRefSubv().getRefVp().getPanelInfo().setPosY(r.getY());
					getRefSubv().getRefVp().getPanelInfo().repaint();
				}
			}
		});
	}

	protected void paintComponent (Graphics gr) {
		Graphics2D g2 = (Graphics2D) gr;
		if (getRefBImg() == null) {
			g2.setColor (Color.BLACK);
			g2.drawRect(0, 0, getWidth(), getHeight());

		} else {
			g2.drawImage(getRefBImg(), 0, 0, this);
		}
	}
}
