package componentes;

import javax.swing.JDialog;

@SuppressWarnings("serial")
public class GraficaHistograma extends JDialog {

	private PanelHistograma panelHistograma;
	
	public PanelHistograma getPanelHistograma() { return panelHistograma; }
	public void setPanelHistograma(PanelHistograma panelHistograma) { this.panelHistograma = panelHistograma; }
	
	public GraficaHistograma (int [] histograma, int tipoH) {
		setBounds(700, 50, 600, 600);
		setResizable(false);
		setTitle("Histograma de la imagen");
		setVisible(true);
		setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
		setLayout(null);
		
		setPanelHistograma(new PanelHistograma(histograma, tipoH));
		getPanelHistograma().setSize(getSize());
		add (getPanelHistograma());

	}






}
