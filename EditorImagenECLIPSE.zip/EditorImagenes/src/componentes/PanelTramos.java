package componentes;

import java.awt.Color;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PanelTramos extends JPanel {

	
	
	public PanelTramos() {
		setBackground(Color.BLACK);
	}

}
