package componentes;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;

import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

@SuppressWarnings("serial")
public class VentanaPerfil extends JDialog {

	private final int X = 200;
	private final int Y = 50;
	private final int AN = 800;
	private final int AL = 600;

	private BufferedImage refBfImgAct;
	private JPanel panelImag;
	private PanelVentanaPerfil panelPerfil;
	
	private Boolean leerPuntoIni = true;

	private Point ini = new Point();
	private Point fin = new Point ();

	public BufferedImage getRefBfImgAct() { return refBfImgAct; }
	public void setRefBfImgAct(BufferedImage refBfImgAct) { this.refBfImgAct = refBfImgAct; }

	public JPanel getPanelImag() { return panelImag; }
	public void setPanelImag(JPanel panelImag) { this.panelImag = panelImag; }

	public Point getIni() { return ini; }
	public void setIni(Point ini) { this.ini = ini; }

	public Boolean getLeerPuntoIni() { return leerPuntoIni; }
	public void setLeerPuntoIni(Boolean leerPuntoIni) { this.leerPuntoIni = leerPuntoIni; }
	
	public Point getFin() { return fin; }
	public void setFin(Point fin) { this.fin = fin; }

	public PanelVentanaPerfil getPanelVentanaPerfil() { return panelPerfil; }
	public void setPanelVentanaPerfil (PanelVentanaPerfil panelPerfil) { this.panelPerfil = panelPerfil; }
	
	public VentanaPerfil (BufferedImage refBImgAct) { 
		setRefBfImgAct(refBImgAct); 
		iniciarVentana();
		iniciarPanelImagen ();
		iniciarPanelPerfil ();
	}

	public void iniciarVentana () {
		setTitle("Ventana Perfil");
		setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
		setVisible(true);
		setBounds(X, Y, AN, AL);
		setLayout(null);
	}

	public void iniciarPanelImagen () {
		final JPanel panel = new JPanel() {

			protected void paintComponent (Graphics gr) { 
				gr.setColor(Color.WHITE);
				gr.fillRect(0, 0, this.getWidth(), this.getHeight());
				gr.drawImage(getRefBfImgAct(), 0, 0, this.getWidth(), this.getHeight(), null);
				Graphics2D g2d = (Graphics2D) gr;
				g2d.setColor(Color.RED);
				g2d.setStroke(new BasicStroke(2.0f));
				g2d.drawLine((int) getIni().getX(), (int) getIni().getY(), (int) getFin().getX(), (int) getFin().getY());
			}
		};

		panel.setBounds(30, 10, 300, 300);
		panel.setBorder(new LineBorder(Color.BLACK, 2));

		panel.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseReleased(MouseEvent r) {
				try {
					setFin(new Point(r.getX(), r.getY()));
					actualizarPanelPerfil();		
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				panel.repaint ();
			}

			@Override
			public void mousePressed(MouseEvent r) {
				if (getLeerPuntoIni())
					setIni(new Point(r.getX(), r.getY()));
				setLeerPuntoIni(false);
			}		
		});
		
		panel.addMouseMotionListener(new MouseMotionAdapter() {

			@Override
			public void mouseDragged(MouseEvent r) {
				try {
					setFin(new Point(r.getX(), r.getY()));
						
					panel.repaint ();
					setLeerPuntoIni(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}		
		});

		setPanelImag(panel);
		getContentPane().add (getPanelImag());
	}
	
	public void iniciarPanelPerfil () {
		setPanelVentanaPerfil(new PanelVentanaPerfil());
		getPanelVentanaPerfil().setBounds(400, 10, 300, 300);
		getPanelVentanaPerfil().setBorder(new LineBorder(Color.BLACK, 2));
		getContentPane().add(getPanelVentanaPerfil());
	}

	public void actualizarPanelPerfil () {
		double m = (getFin().getY() - getIni().getY()) / (getFin().getX() - getIni().getX());
		
		if (m == 0)
			m = 0.001f; // Controlamos que no ocurran as�ntotas con la pendiente
		
		int primero = 0, ultimo = 0;
		if (getFin().getX() > getIni().getX()) {
			primero = (int) Math.round(getIni().getX());
			ultimo = (int) Math.round(getFin().getX());
		} else {
			primero = (int) Math.round(getFin().getX());
			ultimo = (int) Math.round(getIni().getX());
		}
		
		int n = (int) Math.floor(getIni().getY() - (m * getIni().getX()));
		
		int [] perfil = new int [256];
		int temp = 0;
		for (int i = primero; i < ultimo; ++i) {
			temp = (int) Math.round(m * i + n);
			perfil[i] = new Color (getRefBfImgAct().getRGB(i, temp)).getRed();
			//perfil[i] = ((new Color (getRefBfImgAct().getRGB(i, temp)).getRed()) >> 16) & 0xff;
		}
		
		getPanelVentanaPerfil().setPerfil(perfil);
		getPanelVentanaPerfil().repaint();
	}

}
