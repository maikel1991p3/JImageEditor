package componentes;

import interfaz_principal.VentanaPrincipal;
import interfaz_secundaria.PanelInformativo;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class VentanaInfoImagen extends JFrame {

	// Atributos -- referencias
	private VentanaPrincipal refVp;
	private BufferedImage refImg;
	
	// Atributos de informaci�n
	private PanelVentanaInfo texto;
	
	// Manejadores de atributos
	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }
	
	public BufferedImage getRefImg() { return refImg; }
	public void setRefImg(BufferedImage refImg) { this.refImg = refImg; }
	
	public PanelVentanaInfo getTexto() { return texto; }
	public void setTexto(PanelVentanaInfo texto) { this.texto = texto; }


	public VentanaInfoImagen (VentanaPrincipal vp) {
		super ();
		setRefVp(vp);
		setLayout(null);
		setBounds(1000, 50, 350, 500);
		setAlwaysOnTop(true);
		setTexto(new PanelVentanaInfo(this));
		
		add (getTexto());
	}
	
	public void actualizar () {
		getTexto().setNombre(getRefVp().getGestorSubVentanas().getSubVentanas().get(getRefVp().getGestorSubVentanas().getNumVentActual()).getTitle());
		getTexto().setFormatoImg(getTexto().obtenerFormato(getRefVp().getGestorSubVentanas().getSubVentanas().get(getRefVp().getGestorSubVentanas().getNumVentActual()).getTitle()));
		getTexto().setAnchoImg(getRefImg().getWidth());
		getTexto().setAltoImg(getRefImg().getHeight());

		getTexto().setMin(obtenerMinGris(getRefVp().getGestorSubVentanas().getSubVentanas().get(getRefVp().getGestorSubVentanas().getNumVentActual()).getRefBufImg()));
		getTexto().setMax(obtenerMaxGris(getRefVp().getGestorSubVentanas().getSubVentanas().get(getRefVp().getGestorSubVentanas().getNumVentActual()).getRefBufImg()));
		getTexto().setEntropia(getRefVp().getGestorSubVentanas().getSubVentanas().get(getRefVp().getGestorSubVentanas().getNumVentActual()).getEntropia());
	}

	public int obtenerMinGris (BufferedImage bf) {
		int temp = Integer.MAX_VALUE;
		for (int i = 0; i < bf.getWidth(); ++i)
			for (int j = 0; j < bf.getHeight(); ++j)
				if (new Color (bf.getRGB(i, j)).getRed() < temp)
					temp = new Color (bf.getRGB(i, j)).getRed();
		return temp;
	}
	
	public int obtenerMaxGris (BufferedImage bf) {
		int temp = Integer.MIN_VALUE;
		for (int i = 0; i < bf.getHeight(); ++i)
			for (int j = 0; j < bf.getWidth(); ++j)
				if (new Color (bf.getRGB(i, j)).getRed() > temp)
					temp = new Color (bf.getRGB(i, j)).getRed();
		return temp;
	}
	
}
