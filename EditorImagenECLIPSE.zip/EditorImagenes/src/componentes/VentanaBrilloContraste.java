package componentes;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

@SuppressWarnings("serial")
public class VentanaBrilloContraste extends JDialog {

	private ArrayList<ArrayList<Integer>> valoresSinBrillo = new ArrayList <ArrayList<Integer>>();
	private JSlider SBrillo = new JSlider();
	private JSlider SContraste = new JSlider();
	private double b = 0;
	private double c = 0;

	private VentanaPrincipal refVp;
	private BufferedImage refBImg;

	public JSlider getSBrillo() { return SBrillo; }
	public void setSBrillo(JSlider sBrillo) { SBrillo = sBrillo; }

	public JSlider getSContraste() { return SContraste; }
	public void setSContraste(JSlider sContraste) { SContraste = sContraste; }

	public double getB() { return b; }
	public void setB(double b) { this.b = b; }

	public double getC() { return c; }
	public void setC(double c) { this.c = c; }

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }

	public BufferedImage getRefBImg() { return refBImg; }
	public void setRefBImg(BufferedImage refBImg) { this.refBImg = refBImg; }

	public ArrayList<ArrayList<Integer>> getValoresSinBrillo() { return valoresSinBrillo; }
	public void setValoresSinBrillo(ArrayList<ArrayList<Integer>> valoresSinBrillo) { this.valoresSinBrillo = valoresSinBrillo; }

	public VentanaBrilloContraste (VentanaPrincipal refVp) {
		setRefVp(refVp);
		getContentPane().setBackground(Color.WHITE);
		setBounds(350, 50, 500, 300);
		setLayout(null);
		setAlwaysOnTop(true);
		setResizable(false);
		actualizarValores ();
		iniciarPanel();
	}

	public void actualizarValores () {
		if (getRefVp().getGestorSubVentanas().getSubVentanas().size() > 0) {
			setRefBImg(getRefVp().getGestorSubVentanas().getSubVentanas().get(
					getRefVp().getGestorSubVentanas().getNumVentActual()).getRefBufImg());
			
			setB(getRefVp().getGestorSubVentanas().getSubVentanas().get(
					getRefVp().getGestorSubVentanas().getNumVentActual()).getBrillo());
			
			setC(getRefVp().getGestorSubVentanas().getSubVentanas().get(
					getRefVp().getGestorSubVentanas().getNumVentActual()).getContraste ());
			
			getSBrillo().setValue((int) getB());
			getSContraste().setValue((int) getC());

		}
	}

	public void inicializarValoresSinBrillo (SubVentana temp) {
		getValoresSinBrillo ().clear();
		for (int i = 0; i < temp.getRefBufImg().getWidth(); ++i) {
			ArrayList<Integer> dummy = new ArrayList<Integer>();
			for (int j = 0; j < temp.getRefBufImg().getHeight(); ++j) {
				int rojo = new Color(temp.getRefBufImg().getRGB(i, j)).getRed();
				dummy.add(rojo - (int) Math.round(temp.getBrillo()));
			}
			getValoresSinBrillo().add(dummy);
		}	
	}

	public HashMap <Integer, Integer> tablaTransformacionBrillo (int valor) {
		HashMap <Integer, Integer> tabla = new HashMap <Integer, Integer>();
		int temp;
		for (int i = 0; i < 256; ++i) {
			temp = i + valor;
			if (temp < 0)
				temp = 0;
			if (temp > 255)
				temp = 255;
			tabla.put (i, temp);
		}

		return tabla;
	}

	public void iniciarPanel () {		

		JLabel titulo = new JLabel("Ajustes Lineales (Brillo y Contraste)");
		titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		titulo.setBounds(50, 10, 400, 30);
		add (titulo);

		JLabel etBrillo = new JLabel("Brillo");
		etBrillo.setBounds(20, 100, 100, 30);
		etBrillo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		add (etBrillo);
		getSBrillo().setBounds(100, 105, 256, 20);
		getSBrillo().setMinimum(-255);
		getSBrillo().setMaximum(255);
		getSBrillo().addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				try {
				if (((JSlider) e.getSource()).getValueIsAdjusting()) {
					int vAct = getRefVp().getGestorSubVentanas().getNumVentActual();
					if (!getRefVp().getGestorSubVentanas().getSubVentanas().get(vAct).getImgOriginal()) {
						setB(((JSlider) e.getSource()).getValue());
						actualizarBrillo(getB());
						getRefVp().getGestorSubVentanas().getSubVentanas().get(vAct).repaint();
					}
				}
				} catch (Exception ex) {}
			}
		});
		add (getSBrillo());

		JLabel etContr = new JLabel("Contraste");
		etContr.setBounds(20, 150, 150, 30);
		etContr.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		add (etContr);
		getSContraste().setBounds(110, 160, 256, 20);
		getSContraste().addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				if (((JSlider) e.getSource()).getValueIsAdjusting()) {
					//actualizarBrillo (((JSlider) e.getSource()).getValue());
				}
			}
		});
		add (getSContraste());
	}

	public void actualizarBrillo (double valor) {
		HashMap <Integer, Integer> tabla = tablaTransformacionBrillo ((int)valor);
		int valorNuevo = 0;
		for (int i = 0; i < getValoresSinBrillo().size(); ++i) {
			for (int j = 0; j < getValoresSinBrillo().get(i).size(); ++j) {
				if (getValoresSinBrillo().get(i).get(j) < 0){
					valorNuevo = tabla.get(0);
				}
				else if (getValoresSinBrillo().get(i).get(j) > 255) {
					valorNuevo = tabla.get(255);
				}
				else {
					valorNuevo = tabla.get(getValoresSinBrillo().get(i).get(j));
				}

				getRefVp().getGestorSubVentanas().getSubVentanas().get(
						getRefVp().getGestorSubVentanas().getNumVentActual()).getRefBufImg().setRGB(i, j, new Color (
								valorNuevo, valorNuevo, valorNuevo).getRGB());
			}
		}

	}
}
