package componentes;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JPanel;

public class PanelVentanaInfo extends JPanel {

	// Atributos internos
	private Font letra = new Font(Font.SANS_SERIF, Font.BOLD, 20);
	private String nombre = new String("Sin nombre");
	private String formatoImg = new String("Desconocido");
	private int anchoImg = 0;
	private int altoImg = 0;
	private int min = -1;
	private int max = -1;
	
	// Manejadores de atributos
	public Font getLetra() { return letra; }
	public void setLetra(Font letra) { this.letra = letra; }
	
	public String getNombre() { return nombre; }
	public void setNombre(String nombre) { this.nombre = nombre; }
	
	public String getFormatoImg() {	return formatoImg; }
	public void setFormatoImg(String formatoImg) { this.formatoImg = formatoImg; }
	
	public int getAnchoImg() { return anchoImg; }
	public void setAnchoImg(int anchoImg) { this.anchoImg = anchoImg; }
	
	public int getAltoImg() { return altoImg; }
	public void setAltoImg(int altoImg) { this.altoImg = altoImg; }
	
	public int getMin() { return min; }
	public void setMin(int min) { this.min = min; }
	
	public int getMax() { return max; }
	public void setMax(int max) { this.max = max; }
	
	
	public PanelVentanaInfo (VentanaInfoImagen vInfo) {
		setBounds(0, 0, vInfo.getWidth(), vInfo.getHeight());
	}
	
	protected void paintComponent (Graphics gr) {
		gr.setColor(Color.WHITE);
		gr.fillRect(0, 0, getWidth(), getHeight());
		gr.setColor(Color.BLACK);
		gr.setFont(getLetra());
		gr.drawString("�Propiedades de la imagen:", 50, 22);
		gr.drawString("Nombre: " + getNombre(), 20, 90);
		gr.drawString("Formato: " + getFormatoImg(), 20, 120);
		gr.drawString("Dimensiones: [" + getAnchoImg() + " X " + getAltoImg() + "]", 20, 150);
		gr.drawString(" Ancho: " + getAnchoImg(), 25, 180);
		gr.drawString(" Alto: " + getAltoImg(), 25, 210);
		//gr.drawString("Valor MIN = " + getMin(), 20, 240);
		//gr.drawString("Valor MAX = " + getMax(), 20, 270);
		
	}
	
	public String obtenerFormato(String nombreImagen) {
		String [] nombre_Punto_Formato = {"a.png"};
		if (nombreImagen.length() > 5){
			nombre_Punto_Formato = nombreImagen.split("\\.");
			return nombre_Punto_Formato[1];
		}
		return "UNKNOWN FORMAT";
	}
	
}
