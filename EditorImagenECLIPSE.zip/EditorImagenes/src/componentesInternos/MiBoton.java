package componentesInternos;

import javax.swing.JButton;

@SuppressWarnings("serial")
public class MiBoton extends JButton {

	private int frecuencia = 1;
	private int id;
	private String nombre = new String();
	
	public int getFrecuencia() { return frecuencia; }
	public void setFrecuencia(int frecuencia) { this.frecuencia = frecuencia; }

	public int getId() { return id; }
	public void setId(int id) { this.id = id; }
	
	public String getNombre() { return nombre; }
	public void setNombre(String nombre) { this.nombre = nombre; }
	
	public MiBoton (String t, int id) {
		super (t);
		setId(id);
	}
	
	public MiBoton (MiBoton temp) {
		this.setText(temp.getText());
		this.setIcon(temp.getIcon());
		this.setBackground(temp.getBackground());
		this.setForeground(temp.getForeground());
		this.setBounds(temp.getBounds());
		this.setBorder(temp.getBorder());
		this.setFrecuencia(temp.getFrecuencia());
		this.setId(temp.getId());
		
		int list = temp.getActionListeners().length;
		if (list > 0) {
			for (int i = 0; i < list; ++i) {
				this.addActionListener(temp.getActionListeners()[i]);
			}
		}
	}
	
	
	public void aumentaFrecuenciaUso () {
		setFrecuencia(getFrecuencia() + 1);
	}
}
