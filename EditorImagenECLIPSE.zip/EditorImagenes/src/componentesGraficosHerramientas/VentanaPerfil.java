package componentesGraficosHerramientas;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;


@SuppressWarnings("serial")
public class VentanaPerfil extends JDialog {

	private final int X = 200;
	private final int Y = 50;
	private final int AN = 800;
	private final int AL = 400;

	private BufferedImage refBfImgAct;
	private JPanel panelImag;
	private PanelVentanaPerfil panelPerfil;
	
	private Boolean leerPuntoIni = true;

	private Point ini = new Point();
	private Point fin = new Point ();

	public BufferedImage getRefBfImgAct() { return refBfImgAct; }
	public void setRefBfImgAct(BufferedImage refBfImgAct) { this.refBfImgAct = refBfImgAct; }

	public JPanel getPanelImag() { return panelImag; }
	public void setPanelImag(JPanel panelImag) { this.panelImag = panelImag; }

	public Point getIni() { return ini; }
	public void setIni(Point ini) { this.ini = ini; }

	public Boolean getLeerPuntoIni() { return leerPuntoIni; }
	public void setLeerPuntoIni(Boolean leerPuntoIni) { this.leerPuntoIni = leerPuntoIni; }
	
	public Point getFin() { return fin; }
	public void setFin(Point fin) { this.fin = fin; }

	public PanelVentanaPerfil getPanelVentanaPerfil() { return panelPerfil; }
	public void setPanelVentanaPerfil (PanelVentanaPerfil panelPerfil) { this.panelPerfil = panelPerfil; }
	
	public VentanaPerfil (BufferedImage refBImgAct) { 
		setRefBfImgAct(refBImgAct); 
		iniciarVentana();
		iniciarPanelImagen ();
		iniciarPanelPerfil ();
	}

	public void iniciarVentana () {
		setTitle("Ventana Perfil");
		setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
		getContentPane().setBackground(Color.WHITE);
		setVisible(true);
		setBounds(X, Y, AN, AL);
		setLayout(null);
		
		JButton aceptar = new JButton("Aceptar");
		aceptar.setBounds((this.getWidth() / 2) - 80, getHeight() - 80, 80, 30);
		aceptar.setBackground(Color.WHITE);
		aceptar.setBorder(new LineBorder(Color.BLACK, 2));
		aceptar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				dispose ();
			}
		});
		
		getContentPane().add (aceptar);
	}

	public void iniciarPanelImagen () {
		final JPanel panel = new JPanel() {

			protected void paintComponent (Graphics gr) { 
				gr.setColor(Color.WHITE);
				gr.fillRect(0, 0, this.getWidth(), this.getHeight());
				gr.drawImage(getRefBfImgAct(), 0, 0, this.getWidth(), this.getHeight(), null);
				Graphics2D g2d = (Graphics2D) gr;
				g2d.setColor(Color.RED);
				g2d.setStroke(new BasicStroke(2.0f));
				g2d.drawLine((int) getIni().getX(), (int) getIni().getY(), (int) getFin().getX(), (int) getFin().getY());
			}
		};

		panel.setBounds(30, 10, 300, 300);
		panel.setBorder(new LineBorder(Color.BLACK, 2));

		panel.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseReleased(MouseEvent r) {
				try {
					setFin(new Point(r.getX(), r.getY()));
					actualizarPanelPerfil();		
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				panel.repaint ();
			}

			@Override
			public void mousePressed(MouseEvent r) {
				if (getLeerPuntoIni())
					setIni(new Point(r.getX(), r.getY()));
				setLeerPuntoIni(false);
			}		
		});
		
		panel.addMouseMotionListener(new MouseMotionAdapter() {

			@Override
			public void mouseDragged(MouseEvent r) {
				try {
					setFin(new Point(r.getX(), r.getY()));
						
					panel.repaint ();
					setLeerPuntoIni(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}		
		});

		setPanelImag(panel);
		getContentPane().add (getPanelImag());
	}
	
	public void iniciarPanelPerfil () {
		setPanelVentanaPerfil(new PanelVentanaPerfil());
		getPanelVentanaPerfil().setBounds(400, 10, 300, 300);
		getPanelVentanaPerfil().setBorder(new LineBorder(Color.BLACK, 2));
		getContentPane().add(getPanelVentanaPerfil());
	}

	public void actualizarPanelPerfil () {
		
		int anchoPanel = this.getWidth();
		int anchoImagen = getRefBfImgAct().getWidth();
		int altoPanel = this.getHeight();
		int altoImagen = getRefBfImgAct().getHeight();
		
		double escalaH = 1.0f;
		double escalaV = 1.0f;
		
		if (anchoPanel >= anchoImagen) {
			escalaH = 300.0 / anchoImagen;
		} else {
			escalaH = anchoImagen / 300.0;
		}

		
		
		if (altoPanel >= altoImagen) {
			escalaV = 300.0 / altoImagen;
		} else {
			escalaV = altoImagen / 300.0;
		}
		
		double m = 0.0;
		if (getIni().getX() != getFin().getX())
			m = ((getFin().getY() / escalaV) - (getIni().getY() / escalaH)) / ((getFin().getX() / escalaH) - (getIni().getX() / escalaH));
		else 
			m = 1.0;
		
		int primero = 0, ultimo = 0;
		if (getFin().getX()* escalaH > getIni().getX() / escalaH) {
			primero = (int) Math.round(getIni().getX() / escalaH);
			ultimo = (int) Math.round(getFin().getX() / escalaH);
		} else {
			primero = (int) Math.round(getFin().getX() / escalaH);
			ultimo = (int) Math.round(getIni().getX() / escalaH);
		}
		
		double n = (getIni().getY() / escalaV) - (m * (getIni().getX() / escalaH));
		
		int [] perfil = new int [(int)distEuclidea(new Point ((int) Math.round (getIni().getX() / escalaH) , (int) Math.round(getIni().getY() / escalaV)),
				new Point ((int) Math.round (getFin().getX() / escalaH) , (int) Math.round(getFin().getY() / escalaV)))];
		int temp = 0, c = 0;
		for (int i = primero; i < ultimo; ++i) {
			temp = (int) Math.round(m * i + n);
			perfil[c] = new Color (getRefBfImgAct().getRGB(i, temp)).getRed();
			++c;
		}
		
		getPanelVentanaPerfil().setPerfil(perfil);
		getPanelVentanaPerfil().repaint();
	}
	
	public double distEuclidea (Point p, Point q) {
		return Math.sqrt((Math.pow(Math.abs(q.getX() - p.getX()), 2)) + (Math.pow(Math.abs(q.getY() - p.getY()), 2)));
	}

}
