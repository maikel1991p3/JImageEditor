package componentesGraficosHerramientas;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;


@SuppressWarnings("serial")
public class VentanaInfoImagen extends JFrame {

	// Atributos -- referencias
	private VentanaPrincipal refVp;
	private BufferedImage refImg;
	
	// Atributos de informaci�n
	private PanelVentanaInfo texto;
	
	// Manejadores de atributos
	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }
	
	public BufferedImage getRefImg() { return refImg; }
	public void setRefImg(BufferedImage refImg) { this.refImg = refImg; }
	
	public PanelVentanaInfo getTexto() { return texto; }
	public void setTexto(PanelVentanaInfo texto) { this.texto = texto; }


	public VentanaInfoImagen (VentanaPrincipal vp) {
		super ();
		setRefVp(vp);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(400, 50, 600, 500);
		setLayout(null);
		setAlwaysOnTop(true);
		setResizable(false);
		setTexto(new PanelVentanaInfo(this));
		
		add (getTexto());
		
	}
	
	public void actualizar () {
		getTexto().setNombre(getRefVp().getGestorSubVentanas().getRefSubVentActual().getTitle());
		getTexto().setFormatoImg(getTexto().obtenerFormato(getRefVp().getGestorSubVentanas().getRefSubVentActual().getTitle()));
		getTexto().setAnchoImg(getRefImg().getWidth());
		getTexto().setAltoImg(getRefImg().getHeight());

		getTexto().setMin(obtenerMinGris(getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg()));
		getTexto().setMax(obtenerMaxGris(getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg()));
		
		getRefVp().getGestorSubVentanas().getRefSubVentActual().obtenerEntropia();
		getTexto().setEntropia(getRefVp().getGestorSubVentanas().getRefSubVentActual().getEntropia());
		
		getTexto().setBrillo(getRefVp().getGestorSubVentanas().getRefSubVentActual().getBrillo());
		getTexto().setContraste(getRefVp().getGestorSubVentanas().getRefSubVentActual().getContraste());
		getTexto().setRefBufImg(getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg());
	}

	public int obtenerMinGris (BufferedImage bf) {
		int temp = Integer.MAX_VALUE;
		for (int i = 0; i < bf.getWidth(); ++i)
			for (int j = 0; j < bf.getHeight(); ++j)
				if (new Color (bf.getRGB(i, j)).getRed() < temp)
					temp = new Color (bf.getRGB(i, j)).getRed();
		return temp;
	}
	
	public int obtenerMaxGris (BufferedImage bf) {
		int temp = Integer.MIN_VALUE;
		for (int i = 0; i < bf.getWidth(); ++i)
			for (int j = 0; j < bf.getHeight(); ++j)
				if (new Color (bf.getRGB(i, j)).getRed() > temp)
					temp = new Color (bf.getRGB(i, j)).getRed();
		return temp;
	}
	
}
