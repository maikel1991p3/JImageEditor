package componentesGraficosHerramientas;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


@SuppressWarnings("serial")
public class VentanaBrilloContraste extends JDialog {

	private ArrayList<ArrayList<Integer>> valoresSinBrillo = new ArrayList <ArrayList<Integer>>();
	private JSlider SBrillo = new JSlider();
	private JSlider SContraste = new JSlider();

	private VentanaPrincipal refVp;
	private SubVentana vOriginal;
	
	public JSlider getSBrillo() { return SBrillo; }
	public void setSBrillo(JSlider sBrillo) { SBrillo = sBrillo; }

	public JSlider getSContraste() { return SContraste; }
	public void setSContraste(JSlider sContraste) { SContraste = sContraste; }

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }

	public SubVentana getvOriginal() { return vOriginal; }
	public void setvOriginal(SubVentana vOriginal) { this.vOriginal = vOriginal; }

	public ArrayList<ArrayList<Integer>> getValoresSinBrillo() { return valoresSinBrillo; }
	public void setValoresSinBrillo(ArrayList<ArrayList<Integer>> valoresSinBrillo) { this.valoresSinBrillo = valoresSinBrillo; }

	public VentanaBrilloContraste (VentanaPrincipal refVp) {
		setRefVp(refVp);
		
		// NUEVO !! --> TENEMOS LA IMAGEN, SU BRILLO Y CONTRASTE -> ORIGINALES!! (no actualizar !!)
		setvOriginal(getRefVp().getGestorSubVentanas().getRefSubVentActual());
		
		getContentPane().setBackground(Color.WHITE);
		setBounds(350, 50, 500, 300);
		setLayout(null);
		setAlwaysOnTop(true);
		setResizable(false);
		iniciarPanel();
	}

	

	public HashMap <Integer, Integer> tablaTransformacionBrillo (double brillo, double contraste) {
		HashMap <Integer, Integer> tabla = new HashMap <Integer, Integer>();
		double A = contraste / getvOriginal().getContraste();
		double B = brillo - A * getvOriginal().getBrillo();
		int temp = 0;
		/*vout = A*vin + B*/
		for (int i = 0; i < 256; ++i) {
			temp = (int)(Math.round (((A * i) + B)));
			if (temp < 0)
				temp = 0;
			if (temp > 255)
				temp = 255;
			tabla.put (i, temp);
		}

		return tabla;
	}

	public void iniciarPanel () {		

		JLabel titulo = new JLabel("Ajustes Lineales (Brillo y Contraste)");
		titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		titulo.setBounds(50, 10, 400, 30);
		add (titulo);

		JLabel etBrillo = new JLabel("Brillo");
		etBrillo.setBounds(20, 100, 100, 30);
		etBrillo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		add (etBrillo);
		getSBrillo().setBounds(80, 105, 400, 50);
		getSBrillo().setBackground(Color.WHITE);
		getSBrillo().setMinimum(0);
		getSBrillo().setMaximum(255);
		getSBrillo().setPaintTicks(true);
		getSBrillo().setPaintTrack(true);
		getSBrillo().setMajorTickSpacing(30);
		getSBrillo().setMinorTickSpacing(10);
		getSBrillo().setPaintLabels(true);
		getSBrillo().addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				try {
					if (((JSlider) e.getSource()).getValueIsAdjusting()) {
						if (!getRefVp().getGestorSubVentanas().getRefSubVentActual().getImgOriginal()) {
							actualizarBrillo(getSBrillo().getValue(), getSContraste().getValue());
							getRefVp().getGestorSubVentanas().getRefSubVentActual().repaint();
						}
					}
				} catch (Exception ex) {}
			}
		});
		add (getSBrillo());

		JLabel etContr = new JLabel("Contraste");
		etContr.setBounds(20, 180, 400, 50);
		etContr.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		add (etContr);
		getSContraste().setBounds(100, 180, 380, 50);
		getSContraste().setBackground(Color.WHITE);
		getSContraste().setMinimum(0);
		getSContraste().setMaximum(127);
		getSContraste().setPaintTicks(true);
		getSContraste().setPaintTrack(true);
		getSContraste().setMajorTickSpacing(20);
		getSContraste().setMinorTickSpacing(10);
		getSContraste().setPaintLabels(true);
		getSContraste().addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				try {
					if (((JSlider) e.getSource()).getValueIsAdjusting()) {
						if (!getRefVp().getGestorSubVentanas().getRefSubVentActual().getImgOriginal()) {
							actualizarBrillo(getSBrillo().getValue(), getSContraste().getValue());
							getRefVp().getGestorSubVentanas().getRefSubVentActual().repaint();
						}
					}
				} catch (Exception ex) {}
			}
		});
		add (getSContraste());
		
		JButton aceptar = new JButton("Aceptar");
		aceptar.setBounds(200, 240, 100, 20);
		aceptar.setBackground(Color.WHITE);
		aceptar.setBorder(new LineBorder(Color.BLACK, 2));
		aceptar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		add (aceptar);
	}

	public void actualizarBrillo (double brillo, double contraste) {
		HashMap <Integer, Integer> tabla = tablaTransformacionBrillo (brillo, contraste);
		int valorNuevo = 0;
		for (int i = 0; i < getvOriginal().getRefBufImg().getWidth(); ++i) {
			for (int j = 0; j < getvOriginal().getRefBufImg().getHeight(); ++j) {
				
				valorNuevo = tabla.get(new Color (getvOriginal().getRefBufImg().getRGB(i, j)).getRed());
			
				getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().setRGB(i, j, new Color (
								valorNuevo, valorNuevo, valorNuevo).getRGB());
			}
		}
		getRefVp().getGestorSubVentanas().getRefSubVentActual().obtenerHistograma(getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg());

	}
}
