package componentesGraficosHerramientas;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Path2D;
import java.awt.image.BufferedImage;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;


@SuppressWarnings("serial")
public class PanelVentanaInfo extends JPanel {

	// Atributos internos
	private Font letra = new Font(Font.SANS_SERIF, Font.BOLD, 20);
	private String nombre = new String("Sin nombre");
	private String formatoImg = new String("Desconocido");
	private int anchoImg = 0;
	private int altoImg = 0;
	private int min = -1;
	private int max = -1;
	private double entropia = 0.0;
	private double brillo = 0.0;
	private double contraste = 0.0;
	
	private BufferedImage refBufImg;
	
	// Manejadores de atributos
	
	public Font getLetra() { return letra; }
	public double getBrillo() { return brillo; }
	public void setBrillo(double brillo) { this.brillo = brillo; }
	public double getContraste() { return contraste; }
	public void setContraste(double contraste) { this.contraste = contraste; }
	
	public void setLetra(Font letra) { this.letra = letra; }
	
	public String getNombre() { return nombre; }
	public void setNombre(String nombre) { this.nombre = nombre; }
	
	public String getFormatoImg() {	return formatoImg; }
	public void setFormatoImg(String formatoImg) { this.formatoImg = formatoImg; }
	
	public int getAnchoImg() { return anchoImg; }
	public void setAnchoImg(int anchoImg) { this.anchoImg = anchoImg; }
	
	public int getAltoImg() { return altoImg; }
	public void setAltoImg(int altoImg) { this.altoImg = altoImg; }
	
	public int getMin() { return min; }
	public void setMin(int min) { this.min = min; }
	
	public int getMax() { return max; }
	public void setMax(int max) { this.max = max; }
	
	public double getEntropia() { return entropia; }
	public void setEntropia(double entropia) { this.entropia = entropia; }
	
	public BufferedImage getRefBufImg() { return refBufImg; }
	public void setRefBufImg(BufferedImage refBufImg) { this.refBufImg = refBufImg; }
	
	public PanelVentanaInfo (final VentanaInfoImagen vInfo) {
		setBounds(0, 0, vInfo.getWidth(), vInfo.getHeight());
		setRefBufImg(vInfo.getRefImg());
		
		setLayout(null);
		JButton aceptar = new JButton("Aceptar");
		aceptar.setBounds(300, 410, 100, 30);
		aceptar.setBackground(Color.WHITE);
		aceptar.setBorder(new LineBorder(Color.BLACK, 2));
		aceptar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				vInfo.dispose();
			}
		});
		add (aceptar);
	}
	
	protected void paintComponent (Graphics g) {
		Graphics2D gr = (Graphics2D) g;
		gr.setColor(Color.WHITE);
		gr.fillRect(0, 0, getWidth(), getHeight());
		gr.setColor(Color.BLACK);
		gr.setFont(getLetra());
		gr.drawString("�Propiedades de la imagen:", 55, 35);
		
		gr.setColor(Color.DARK_GRAY);
		gr.drawString("Nombre: " + getNombre(), 20, 90);
		gr.drawString("Formato: " + getFormatoImg(), 20, 120);
		gr.drawString("Dimensiones: [" + getAnchoImg() + " X " + getAltoImg() + "]", 20, 150);
		gr.drawString(" Ancho: " + getAnchoImg(), 25, 180);
		gr.drawString(" Alto: " + getAltoImg(), 25, 210);
		
		gr.setColor(Color.GRAY);
		gr.drawString("Valor MIN = " + getMin(), 20, 240);
		gr.drawString("Valor MAX = " + getMax(), 20, 270);
		
		gr.setColor(Color.DARK_GRAY);
		gr.drawString("Entrop�a = " + (float) getEntropia(), 20, 300);
		gr.drawString("Brillo = " + (float) getBrillo(), 20, 330);
		gr.drawString("Contraste = " + (float) getContraste(), 20, 360);
		
		pintarImagen(gr);
		pintarBordePanel(gr);
	}
	
	public String obtenerFormato(String nombreImagen) {
		String [] nombre_Punto_Formato = {"a.png"};
		if (nombreImagen.length() > 5){
			nombre_Punto_Formato = nombreImagen.split("\\.");
			return nombre_Punto_Formato[1];
		}
		return "UNKNOWN FORMAT";
	}
	
	public void pintarImagen (Graphics2D g) {
		g.drawString(" � Vista previa de la imagen:", this.getWidth() - 300, 110); 
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g.drawImage(getRefBufImg(), this.getWidth() - 250, 150, 200, 200, this);
	}
	
	public void pintarBordePanel (Graphics2D g) {
		Path2D bordeSup = new Path2D.Double();
		bordeSup.moveTo(3, 3);
		bordeSup.lineTo(this.getWidth() - 10, 3);
		bordeSup.lineTo(this.getWidth() - 10, this.getHeight() - 35);
		bordeSup.lineTo(this.getWidth() - 20, this.getHeight() - 45);
		bordeSup.lineTo(this.getWidth() - 20, 10);
		bordeSup.lineTo(10, 10);
		bordeSup.closePath();

		g.setColor(Color.DARK_GRAY);
		g.fill(bordeSup);
		
		g.setColor(Color.YELLOW);
		g.draw(bordeSup);

		Path2D bordeInf = new Path2D.Double();
		bordeInf.moveTo(3, 8);
		bordeInf.lineTo(3, this.getHeight() - 35);
		bordeInf.lineTo(this.getWidth() - 15, this.getHeight() - 35);
		bordeInf.lineTo(this.getWidth() - 26, this.getHeight() - 43);
		bordeInf.lineTo(8, this.getHeight() - 43);
		bordeInf.lineTo(8, 13);
		bordeInf.closePath();

		g.setColor(Color.LIGHT_GRAY);
		g.fill(bordeInf);
		
		g.setColor(Color.BLACK);
		g.draw(bordeInf);


	}
	
}
