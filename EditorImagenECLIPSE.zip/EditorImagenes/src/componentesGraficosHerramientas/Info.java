package componentesGraficosHerramientas;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.border.LineBorder;

@SuppressWarnings("serial")
public class Info extends JDialog {

	public Info () {
		setTitle("Informaci�n del Producto");
		setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
		setBounds(600, 100, 300, 400);
		getContentPane().setBackground(Color.WHITE);
		setAlwaysOnTop(true);
		setLayout(null);
		
		JButton ok = new JButton("CERRAR");
		ok.setBounds(100, 315, 100, 20);
		ok.setBackground(Color.WHITE);
		ok.setForeground(Color.BLACK);
		ok.setBorder(new LineBorder(Color.BLACK, 2));
		
		ok.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose ();
			}
		});
		
		add (ok);
		
	}
	
	public void cargarTexto () {
		
		
	}
}
