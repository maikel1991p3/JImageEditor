package componentesGraficosHerramientas;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PanelVentanaPerfil extends JPanel {

	private int [] perfil;
	private int [] perfilSuav;
	private int [] derivadaPerfil;

	private Boolean p = true; // pintar perfil 
	private Boolean ps = false; // pintar perfil suavizado
	private Boolean mostrarGraficaDerivada = false; // pintar perfil suavizado

	public int[] getPerfil() { return perfil; }
	public void setPerfil(int[] perfil) { this.perfil = perfil; }

	public int[] getPerfilSuav() { return perfilSuav; }
	public void setPerfilSuav(int[] perfilSuav) { this.perfilSuav = perfilSuav; }

	public int[] getDerivadaPerfil() { return derivadaPerfil; }
	public void setDerivadaPerfil(int[] derivadaPerfil) { this.derivadaPerfil = derivadaPerfil; }

	public Boolean getP() { return p; }
	public void setP(Boolean p) { this.p = p; }

	public Boolean getPs() { return ps; }
	public void setPs(Boolean ps) { this.ps = ps; }

	public Boolean getMostrarGraficaDerivada() { return mostrarGraficaDerivada; } 
	public void setMostrarGraficaDerivada(Boolean mostrarGraficaDerivada) { this.mostrarGraficaDerivada = mostrarGraficaDerivada; }

	public PanelVentanaPerfil() {
		
	}

	protected void paintComponent (Graphics gr) { 
		final int SEP = 10;
		gr.setColor(Color.BLACK);
		gr.fillRect(0, 0, this.getWidth(), this.getHeight());

		double altura = 0;
		double posicion = 0;
		int alturaCero = this.getHeight() - SEP;
		double intervaloLat = 0;

		if (getPerfil() != null) {
			pintarGraficaDerivada(gr);
		} 


		if (getPerfil() != null && getPerfil().length > 0 && getPerfilSuav() != null && getPerfilSuav().length > 0) {

			if (getP ()) {

				if (getPerfil().length >= 255) {
					intervaloLat = this.getWidth() / getPerfil().length;
				} else  {
					intervaloLat = this.getWidth() / 255.0;
				}
				int grisMayor = buscarColorMasGrande();
				if (grisMayor <= 0)
					grisMayor = 1;
				double intervaloAlt = this.getHeight() / grisMayor;

				gr.setColor(Color.YELLOW);
				if (getPerfil().length != 0) {
					for (int i = 0; i < getPerfil().length; ++i) {
						altura = alturaCero - getPerfil()[i] * intervaloAlt; 
						posicion = (i * intervaloLat) + 5;
						gr.drawLine ((int)posicion, alturaCero, (int)posicion, (int)Math.round(altura));
					}
				}
			}

			if (getPs ()) {

				if (getPerfilSuav().length >= 255) {
					intervaloLat = this.getWidth() / getPerfilSuav().length;
				} else  {
					intervaloLat = this.getWidth() / 255.0;
				}
				int grisMayor = buscarColorMasGrande();
				if (grisMayor <= 0)
					grisMayor = 1;
				double intervaloAlt = this.getHeight() / grisMayor;

				gr.setColor(Color.YELLOW);
				if (getPerfilSuav().length != 0) {
					for (int i = 0; i < getPerfilSuav().length; ++i) {
						altura = alturaCero - getPerfilSuav()[i] * intervaloAlt; 
						posicion = (i * intervaloLat) + 5;
						gr.drawLine ((int)posicion, alturaCero, (int)posicion, (int)Math.round(altura));
					}
				}
			}
		}

		/*pintar grafica*/
		gr.setColor (Color.WHITE);
		gr.drawLine (SEP - 5, SEP, SEP - 5, alturaCero);
		gr.drawLine (SEP - 5, alturaCero, this.getWidth() - SEP, alturaCero);
	}

	public void pintarGraficaDerivada (Graphics gr) {
		// �HACER PANEL PROPIO? �MUCHAS CLASES? XD
		/*pintar grafica !!*/
	}

	private int buscarColorMasGrande () {
		int c = 0;
		if (getMostrarGraficaDerivada()) {
			for (int i = 0; i < getDerivadaPerfil().length; ++i)
				if (c < Math.abs(getDerivadaPerfil()[i]))
					c = Math.abs (getDerivadaPerfil()[i]);

		} else {
			for (int i = 0; i < getPerfil().length; ++i)
				if (c < getPerfil()[i])
					c = getPerfil()[i];
		}
		return c;
	}

}
