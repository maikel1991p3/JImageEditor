package componentesGraficosHerramientas;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PanelVentanaPerfil extends JPanel {
	
	private int [] perfil;
	
	public int[] getPerfil() { return perfil; }
	public void setPerfil(int[] perfil) { this.perfil = perfil; }
	
	public PanelVentanaPerfil() {
	}
	
	protected void paintComponent (Graphics gr) { 
		final int SEP = 10;
		gr.setColor(Color.BLACK);
		gr.fillRect(0, 0, this.getWidth(), this.getHeight());
		if (getPerfil() != null) {
			int grisMayor = buscarColorMasGrande();
			if (grisMayor <= 0)
				grisMayor = 1;
			double intervaloAlt = this.getHeight() / grisMayor;
			double intervaloLat = this.getWidth() / getPerfil().length;
			double altura = 0;
			double posicion = 0;
			int alturaCero = this.getHeight() - SEP;

			gr.setColor(Color.YELLOW);
			if (getPerfil().length != 0) {
				for (int i = 0; i < getPerfil().length; ++i) {
					altura = alturaCero - getPerfil()[i] * intervaloAlt; 
					posicion = i * intervaloLat;
					gr.drawLine ((int)posicion, alturaCero, (int)posicion, (int)Math.round(altura));
				}
			}

			/*pintar grafica*/
			gr.setColor (Color.WHITE);
			gr.drawLine (SEP - 5, SEP, SEP - 5, alturaCero);
			gr.drawLine (SEP - 5, alturaCero, this.getWidth() - SEP, alturaCero);

		}
	}
	
	private int buscarColorMasGrande () {
		int c = 0;
		
		for (int i = 0; i < getPerfil().length; ++i)
			if (c < getPerfil()[i])
				c = getPerfil()[i];
		
		return c;
	}

}
