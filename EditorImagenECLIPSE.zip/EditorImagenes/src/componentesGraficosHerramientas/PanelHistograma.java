package componentesGraficosHerramientas;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PanelHistograma extends JPanel {
	final int SEPLATERAL = 50;
	final int SEPVERTICAL = 100;
	private int [] Histograma;
	private int tipoH = 0;

	public int[] getHistograma() { return Histograma; }
	public void setHistograma(int[] histograma) { Histograma = histograma; }

	public int getTipoH() { return tipoH; }
	public void setTipoH(int tipoH) { this.tipoH = tipoH;	}


	private Font letra = new Font(Font.SANS_SERIF, Font.BOLD, 20);

	public PanelHistograma (int [] histograma, int tipoH) {
		setHistograma(histograma);
		setTipoH(tipoH);
	}

	protected void paintComponent (Graphics g) {
		Graphics2D gr = (Graphics2D) g;
		gr.setColor (Color.LIGHT_GRAY);
		gr.fillRect(0, 0, this.getWidth(), this.getHeight());
		if (getTipoH() == 1) {
			gr.setColor (Color.BLACK);
			gr.setFont(letra);
			gr.drawString("Histograma Absoluto", 200, SEPLATERAL);
			gr.setColor (Color.RED);

		} else if (getTipoH() == 2) {
			gr.setColor (Color.BLACK);
			gr.setFont(letra);
			gr.drawString("Histograma Acumulativo", 200, SEPLATERAL);
			gr.setColor (Color.BLUE);

		} else {
			gr.setColor (Color.BLACK);
			gr.setFont(letra);
			gr.drawString("Perfil", 140, 30);
			gr.setColor (Color.CYAN);

		}
		
		if (getHistograma() != null) {
		
			double intervaloAlt = 400.0 / maximoPixel();
			double intervaloLat = 500.0 / getHistograma().length;
			double altura = 0;
			double posicion = 0;
			int alturaCero = this.getHeight() - SEPVERTICAL;

			if (getHistograma().length != 0) {
				/*altura = heigth  400/nPixelesTotales
				 * posicion = 500/255*/
				for (int i = 0; i < getHistograma().length; ++i) {
					altura = alturaCero - getHistograma()[i]*intervaloAlt; 
					posicion = SEPLATERAL + i * intervaloLat;
					gr.drawLine ((int)posicion, alturaCero, (int)posicion, (int)Math.round(altura));
				}
			}

			/*pintar grafica*/
			gr.setColor (Color.BLACK);
			gr.drawLine (SEPLATERAL - 5, SEPVERTICAL, SEPLATERAL - 5, alturaCero);
			gr.drawLine (SEPLATERAL - 5, alturaCero, this.getWidth() - SEPLATERAL, alturaCero);

			gr.drawString ("Distribucci�n de colores", SEPLATERAL + 20, alturaCero + 30);
			gr.rotate (Math.toRadians(90));
			gr.drawString ("Frecuencia de colores", this.getHeight() - alturaCero, 20);

		}
	}

	public int maximoPixel () {
		int maximo = 0;
		for (int i = 0; i < getHistograma().length; ++i) {
			if (maximo < getHistograma()[i])
				maximo = getHistograma()[i];
		}
		return maximo;
	}
}
