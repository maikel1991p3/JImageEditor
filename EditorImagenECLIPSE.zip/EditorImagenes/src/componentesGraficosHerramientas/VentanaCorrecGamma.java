package componentesGraficosHerramientas;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

@SuppressWarnings("serial")
public class VentanaCorrecGamma extends JDialog {

	private JSlider SGamma = new JSlider();
	private VentanaPrincipal refVp;
	private BufferedImage refBImg;

	private ArrayList<ArrayList<Integer>> valoresAcotados = new ArrayList<ArrayList<Integer>>();

	public JSlider getSGamma() { return SGamma; }
	public void setSGamma(JSlider sGamma) { SGamma = sGamma; }

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }

	public BufferedImage getRefBImg() { return refBImg; }
	public void setRefBImg(BufferedImage refBImg) { this.refBImg = refBImg; }

	public ArrayList<ArrayList<Integer>> getValoresAcotados() { return valoresAcotados; }
	public void setValoresAcotados(ArrayList<ArrayList<Integer>> valores) { this.valoresAcotados = valores; }

	public VentanaCorrecGamma (VentanaPrincipal refVp) {
		setRefVp(refVp);
		getContentPane().setBackground(Color.WHITE);
		setBounds(350, 50, 500, 220);
		setLayout(null);
		setAlwaysOnTop(true);
		setResizable(false);
		iniciarPanel();
	}

	public void iniciarPanel () {		

		JLabel titulo = new JLabel("Ajustes No Lineales");
		titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		titulo.setBounds(50, 10, 400, 30);
		add (titulo);
		
		JLabel cero = new JLabel("0");
		cero.setBounds(205, 85, 20, 20);
		add (cero);
		
		JLabel uno = new JLabel("1");
		uno.setBounds(265, 85, 20, 20);
		add (uno);
		
		JLabel dos = new JLabel("2");
		dos.setBounds(320, 85, 20, 20);
		add (dos);
		
		JLabel tres = new JLabel("3");
		tres.setBounds(380, 85, 20, 20);
		add (tres);
		
		JLabel cuatro = new JLabel("4");
		cuatro.setBounds(440, 85, 20, 20);
		add (cuatro);

		JLabel etGamma = new JLabel("Correcci�n Gamma");
		etGamma.setBounds(20, 100, 200, 30);
		etGamma.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		add (etGamma);
		getSGamma().setBounds(200, 100, 250, 50);
		getSGamma().setBackground(Color.WHITE);
		getSGamma().setMinimum(0);
		getSGamma().setMaximum(40);
		getSGamma().setValue(1);
		getSGamma().setPaintTicks(true);
		getSGamma().setPaintTrack(true);
		getSGamma().setMajorTickSpacing(5);
		getSGamma().setMinorTickSpacing(1);
		
		getSGamma().addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				try {
					if (((JSlider) e.getSource()).getValueIsAdjusting()) {
						if (!getRefVp().getGestorSubVentanas().getRefSubVentActual().getImgOriginal()) {
							actualizarGamma(((JSlider) e.getSource()).getValue() / 10.0);
							getRefVp().getGestorSubVentanas().getRefSubVentActual().repaint();
						}
					}
				} catch (Exception ex) {}
			}
		});
		add (getSGamma());

		JButton aceptar = new JButton("Aceptar");
		aceptar.setBounds(200, 160, 100, 20);
		aceptar.setBackground(Color.WHITE);
		aceptar.setBorder(new LineBorder(Color.BLACK, 2));
		aceptar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		add (aceptar);
	}

	public void inicializarValores (BufferedImage temp) {
		if (getRefVp().getGestorSubVentanas().getSubVentanas().size() > 0) {
			setRefBImg(getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg());

			getValoresAcotados().clear();
			for (int i = 0; i < temp.getWidth(); ++i) {
				ArrayList<Integer> dummy = new ArrayList<Integer>();
				for (int j = 0; j < temp.getHeight(); ++j) {
					int rojo = new Color(temp.getRGB(i, j)).getRed();
					dummy.add(rojo);
				}
				getValoresAcotados().add(dummy);
			}
		}
	}
	
	public HashMap <Integer, Double> tablaDeTransformacion(double gamma) {
		HashMap<Integer, Double> tabla = new HashMap <>();
		for (int i = 0; i < 256; ++i) {
			tabla.put(i, Math.pow(i/255.0, gamma) * 255.0);
		}
		return tabla;
	}
	
	public void actualizarGamma (double gamma) {
		double color = 0.0;
		HashMap<Integer, Double> tabla = tablaDeTransformacion(gamma);
		for (int i = 0; i < getValoresAcotados().size(); ++i) {
			for (int j = 0; j < getValoresAcotados().get(i).size(); ++j) {
				color = tabla.get(getValoresAcotados().get(i).get(j));
				getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().setRGB(i, j,
						new Color ((int) Math.round(color), (int) Math.round(color), (int) Math.round(color)).getRGB());
			}
		}
		getRefVp().getGestorSubVentanas().getRefSubVentActual().obtenerHistograma(getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg());
	}
	
}
