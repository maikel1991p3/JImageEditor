package componentesGraficosHerramientas;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PanelSubVentana extends JPanel {

	private BufferedImage refBImg;

	public BufferedImage getRefBImg() { return refBImg;	}
	public void setRefBImg(BufferedImage refBImg) {	this.refBImg = refBImg; }

	public PanelSubVentana (BufferedImage refBImg) {
		setRefBImg(refBImg);
		if (getRefBImg() != null)
			setBounds(0, 0, getRefBImg().getWidth() - 20, getRefBImg().getHeight() - 20);
		else
			setBounds(0, 0, 200, 400);

	}

	protected void paintComponent (Graphics gr) {
		Graphics2D g2 = (Graphics2D) gr;
		g2.setColor (Color.WHITE);
		if (getRefBImg() == null) {
			g2.drawRect(0, 0, getWidth(), getHeight());

		} else {
			g2.drawImage(getRefBImg(), 0, 0, this);
		}
		
	}
}
