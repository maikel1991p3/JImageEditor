package componentesGraficosHerramientas;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.LineBorder;

import componentesInternos.EcuacionRecta;

@SuppressWarnings("serial")
public class VentanaTransfTramos extends JFrame {

	final int X = 100;
	final int Y = 30;
	final int Y_PANELES = 100;
	final int Y_TITULO = 10;
	final int ANCHO_PANELES = 300;
	final int ALTO_PANELES = 300;
	final int SEP_HOR_PANELES = 20;
	final int DESFACE_PUNTOS_PANEL = 44;
	final LineBorder BORDE = new LineBorder(Color.BLACK, 2);

	private PanelTramos panelTramos;
	private PanelImagenTramos panelImResultado;
	private ArrayList<Point> puntosEsp;
	private BufferedImage refImagenOriginal;
	private BufferedImage imagenNueva;
	private ArrayList<EcuacionRecta> ecuacionesRectas;
	private HashMap<Integer, Integer> tablaTransf;
	
	private VentanaPrincipal refVp; // Para eliminarla al presionar aceptar

	public PanelTramos getPanelTramos() { return panelTramos; }
	public void setPanelTramos(PanelTramos panelTramos) { this.panelTramos = panelTramos;	}

	public PanelImagenTramos getPanelImResultado() { return panelImResultado; }
	public void setPanelImResultado(PanelImagenTramos panelImResultado) { this.panelImResultado = panelImResultado; }

	public ArrayList<Point> getPuntosEsp() { return puntosEsp; }
	public void setPuntosEsp(ArrayList<Point> puntosEsp) { this.puntosEsp = puntosEsp; }

	public BufferedImage getRefImagenOriginal() { return refImagenOriginal; }
	public void setRefImagenOriginal(BufferedImage refImagenOriginal) { this.refImagenOriginal = refImagenOriginal; }

	public BufferedImage getImagenNueva() { return imagenNueva; }
	public void setImagenNueva(BufferedImage imagenNueva) { this.imagenNueva = imagenNueva; }
	
	public ArrayList<EcuacionRecta> getEcuacionesRectas() { return ecuacionesRectas; }
	public void setEcuacionesRectas(ArrayList<EcuacionRecta> ecuaciones) { this.ecuacionesRectas = ecuaciones; }

	public HashMap<Integer, Integer> getTablaTransf() { return tablaTransf; }
	public void setTablaTransf(HashMap<Integer, Integer> tablaTransf) { this.tablaTransf = tablaTransf; }

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }
	
	public VentanaTransfTramos(BufferedImage refBfAct, VentanaPrincipal refVp) {
		setRefImagenOriginal(copiarBufferOriginal(refBfAct)); // tomamos la imagen a transformar
		setImagenNueva(copiarBufferOriginal(getRefImagenOriginal()));
		setRefVp(refVp);
		
		setTablaTransf(new HashMap<Integer, Integer>());
		iniciarVentana();
		iniciarPuntos();
		getPanelTramos().repaint();
		
		crearImagenTransformada();
		getPanelImResultado().setImagenTranf(getImagenNueva());
		getPanelImResultado().repaint();
		
	}
	
	public BufferedImage copiarBufferOriginal (BufferedImage original) {
		BufferedImage copia = new BufferedImage(original.getWidth(), original.getHeight(), original.getType());
		for (int i = 0; i < original.getWidth(); ++i) {
			for (int j = 0; j < original.getHeight(); ++j) {
				copia.setRGB(i, j, original.getRGB(i, j));
			}
		}
		return copia;
	}

	public void iniciarVentana () {
		setTitle("Transformaciones Lineales por tramos");
		setBounds(X, Y, (ANCHO_PANELES * 2) + (SEP_HOR_PANELES * 4), (ALTO_PANELES * 2));
		setLayout(null);

		// A�adimos una etiqueta con el t�tulo de la herramienta
		JLabel etiqTitulo = new JLabel(this.getTitle());
		etiqTitulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 30));
		etiqTitulo.setBounds(SEP_HOR_PANELES, Y_TITULO, ANCHO_PANELES * 3, Y);
		getContentPane().add (etiqTitulo);

		JLabel etiqSubTitulo = new JLabel(" - Especifique los puntos para realizar las transformaciones lineales.");
		etiqSubTitulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
		etiqSubTitulo.setBounds(SEP_HOR_PANELES, Y * 2, ANCHO_PANELES * 3, Y);
		getContentPane().add (etiqSubTitulo);

		iniciarPanelTramos();
		iniciarPanelImResultado();

		JButton bAceptar = new JButton("Aceptar");
		bAceptar.setBounds((this.getWidth() / 2) - 100, this.getHeight() - 80, 80, 20);
		bAceptar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getRefVp().getGestorSubVentanas().crearSubVentana(getImagenNueva(), "Especif. a trozos", false);
				dispose ();
			}
		});
		getContentPane().add (bAceptar);
		
		setVisible(true);
	}

	public void iniciarPanelTramos () {
		setPanelTramos(new PanelTramos(this));
		getPanelTramos().setBorder(BORDE);
		getPanelTramos().setBounds(SEP_HOR_PANELES, Y_PANELES, ANCHO_PANELES, ALTO_PANELES);

		getPanelTramos().addMouseMotionListener(new MouseMotionAdapter() {

			@Override
			public void mouseMoved(MouseEvent r) {
				if (r.isAltDown()) {
					getPanelTramos().pintarPunto (new Point (r.getX() - 5, r.getY() - 5));
					getPanelTramos().repaint();
				}
			}
		});	

		getPanelTramos().addMouseListener(new MouseListener() {

			@Override
			public void mousePressed(MouseEvent raton) {
				if (raton.isAltDown()) {
					insertarPunto(new Point (raton.getX(), raton.getY()));

					modificarEcuacionesRectas ();
					getPanelTramos().repaint();
					rellenarTablaDeTransformacion();
					crearImagenTransformada();
					getPanelImResultado().repaint();
				
				} else  {
					int ind = buscarCoincidenteEnX(new Point (raton.getX() - DESFACE_PUNTOS_PANEL, raton.getY()));
					
					if (ind > 0 && ind != getPuntosEsp().size() - 1) {
						eliminarPunto (ind);
						
						modificarEcuacionesRectas ();
						getPanelTramos().repaint();
						rellenarTablaDeTransformacion();
						crearImagenTransformada();
						getPanelImResultado().repaint();
					}
					
				}
			}

			@Override
			public void mouseReleased(MouseEvent arg0) { }

			@Override
			public void mouseExited(MouseEvent arg0) { }

			@Override
			public void mouseEntered(MouseEvent arg0) { }

			@Override
			public void mouseClicked(MouseEvent arg0) { }
		});
		getContentPane().add(getPanelTramos());
	}

	public void iniciarPanelImResultado () {
		setPanelImResultado(new PanelImagenTramos(getImagenNueva())); // inicialmente pinta la original
		
		getPanelImResultado().setBorder(BORDE);
		getPanelImResultado().setBounds(this.getWidth() - SEP_HOR_PANELES * 2 - ANCHO_PANELES, Y_PANELES, ANCHO_PANELES, ALTO_PANELES);
		getContentPane().add(getPanelImResultado());
	}

	private void iniciarPuntos () {
		setPuntosEsp(new ArrayList<Point>());
		getPuntosEsp().add(new Point(0, 0));
		getPuntosEsp().add(new Point(255, 255));

		setEcuacionesRectas(new ArrayList<EcuacionRecta>());

		EcuacionRecta primera = new EcuacionRecta(getPuntosEsp().get(0), getPuntosEsp().get(1));
		primera.rellenarEcuacion();
		getEcuacionesRectas().add(primera);
	}

	public void insertarPunto (Point q) {
		Point p = new Point ((int) Math.round(q.getX() - DESFACE_PUNTOS_PANEL), (int) Math.round(ALTO_PANELES - DESFACE_PUNTOS_PANEL - q.getY() - 1));
		if (getPanelTramos().comprobarLimite(p)) {
			// Comprobar si coincide en x con alg�n punto (menos 1� y �ltimo)
			int coincideX = buscarCoincidenteEnX(p);
			// si -> intercambiar y del punto (menos 1� y �ltimo)
			if (coincideX != 0 && coincideX != getPuntosEsp().size() - 1) {
				if (coincideX != -1) {
					getPuntosEsp().get(coincideX).setLocation(getPuntosEsp().get(coincideX).getX(), p.getY());

				} else { 
					int puntoAnterior = buscarAnteriorPunto(p); // Comprobar entre que par de puntos est� la x
					ArrayList<Point> puntosOrdenados = insertarPuntoOrdenado(p, puntoAnterior);
					// Hacer que �ste sea el nuevo vector de puntos de la clase
					getPuntosEsp().clear();
					setPuntosEsp(puntosOrdenados);
				}

			} else if (coincideX == 0) { // Si coincide X del primer punto -> cambiamos su Y
				getPuntosEsp().get(0).setLocation(getPuntosEsp().get(0).getX(), p.getY());
				modificarEcuacionesRectas();
				rellenarTablaDeTransformacion();
				crearImagenTransformada();

			} else if (coincideX == getPuntosEsp().size() - 1) { // Si coincide X del �ltimo punto -> cambiamos su Y
				getPuntosEsp().get(getPuntosEsp().size() - 1).setLocation(getPuntosEsp().get(getPuntosEsp().size() - 1).getX(), p.getY());
				modificarEcuacionesRectas();
				rellenarTablaDeTransformacion();
				crearImagenTransformada();
			}
		}
		getPanelImResultado().repaint();
	}

	public int buscarCoincidenteEnX (Point p) {
		int DIST_X = 5;
		for (int i = 0; i < getPuntosEsp().size(); ++i)
			if (Math.abs (p.getX() - getPuntosEsp().get(i).getX()) <= DIST_X)
				return i;
		return -1;
	}

	public ArrayList<Point> insertarPuntoOrdenado (Point p, int puntoAnterior) {
		ArrayList<Point> puntosTemp = new ArrayList<Point>();
		
		for (int i = 0; i <= puntoAnterior; ++i) // Metemos los puntos anteriores al nuevo que vamos a insertar (inclu�do el anterior)
			puntosTemp.add(getPuntosEsp().get(i));

		puntosTemp.add(new Point ((int) p.getX(), (int) p.getY())); // Meter punto nuevo en el vector

		// Meter resto de puntos
		for (int i = puntoAnterior + 1; i < getPuntosEsp().size(); ++i) { 
			puntosTemp.add(getPuntosEsp().get(i));
		}

		return puntosTemp;
	}

	public int buscarAnteriorPunto (Point p) {
		int anterior = 0;
		for (int i = 1; i < getPuntosEsp().size() - 1; ++i) {
			if (p.getX() > getPuntosEsp().get(i).getX())
				anterior = i;
		}
		return anterior;
	}

	public void modificarEcuacionesRectas () {
		if (!getEcuacionesRectas().isEmpty())
			getEcuacionesRectas().clear();

		for (int i = 0; i < getPuntosEsp().size() - 1; ++i) {
			Point a = getPuntosEsp().get(i);

			Point b = getPuntosEsp().get(i + 1);
			EcuacionRecta ec = new EcuacionRecta(a, b);
			ec.rellenarEcuacion();
			getEcuacionesRectas().add(ec);
		}

	}

	public void rellenarTablaDeTransformacion () {
		int inicioRect = 0, finRect = 0;
		for (int i = 0; i < getEcuacionesRectas().size(); ++i) {
			inicioRect = (int) getEcuacionesRectas().get(i).getIni().getX();
			finRect = (int) getEcuacionesRectas().get(i).getFin().getX();
			for (int j = inicioRect; j < finRect + 1; ++j)
				getTablaTransf().put(j, getEcuacionesRectas().get(i).getRecta().get(j));
		}
			
	}

	public void crearImagenTransformada () {
		if (getRefImagenOriginal() != null) {
			int argb = 0;
			for (int i = 0; i < getImagenNueva().getWidth(); ++i) {
				for (int j = 0; j < getImagenNueva().getHeight(); ++j) {
					argb = getTablaTransf().get(new Color(getRefImagenOriginal().getRGB(i, j)).getRed());
					getImagenNueva().setRGB(i, j, new Color(argb, argb, argb).getRGB());
				}
			}
		}
		getPanelImResultado().setImagenTranf(getImagenNueva());
	}
	
	public void eliminarPunto (int pos) {
		ArrayList<Point> temp = new ArrayList<>();
		for (int i = 0; i < getPuntosEsp().size(); ++i) {
			if (i != pos)
				temp.add (new Point (getPuntosEsp().get(i)));
		}
		setPuntosEsp(temp); // Sobreescribimos el vector de puntos oficial
	}
}
