package interfaz_principal;

import gestores.GestorDimensionarVent;
import gestores.GestorHerramientas;
import gestores.GestorSubVentanas;
import interfaz_secundaria.Menu;
import interfaz_secundaria.PanelInformativo;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.LineBorder;

import componentesGraficosHerramientas.Info;

@SuppressWarnings("serial")
public class VentanaPrincipal extends JFrame {

	// Atributos constantes para las dimensiones de la ventana
	private final int X = 300;
	private final int Y = 20;
	private final int ANCHO = 1000;
	private final int ALTO = 700;
	
	// Atributos internos
	private String titulo = new String("Editor de Im�genes");
	private JDesktopPane escritorio;
	private Menu menu;
	private PanelInformativo panelInfo;
	private Info infoPrograma = new Info();
	private JLabel logoULL = null;

	// gestores internos
	private GestorSubVentanas gestorSubVentanas;
	private GestorHerramientas gestorHerramientas;

	// Manejadores de atributos
	public String getTitulo() { return titulo; }
	public void setTitulo(String titulo) { this.titulo = titulo; }
	
	public JDesktopPane getEscritorio() { return escritorio; }
	public void setEscritorio(JDesktopPane escritorio) { this.escritorio = escritorio;	}
	
	public Menu getMenu() { return menu; }
	public void setMenu(Menu menu) { this.menu = menu; }
	
	public PanelInformativo getPanelInfo() { return panelInfo; }
	public void setPanelInfo(PanelInformativo panelInfo) { this.panelInfo = panelInfo; }
	
	public Info getInfoPrograma() { return infoPrograma; }
	public void setInfoPrograma(Info infoPrograma) { this.infoPrograma = infoPrograma; }
		
	public GestorSubVentanas getGestorSubVentanas() { return gestorSubVentanas; }
	public void setGestorSubVentanas(GestorSubVentanas gestorSubVentanas) {	this.gestorSubVentanas = gestorSubVentanas;	}
	
	public GestorHerramientas getGestorHerramientas() {	return gestorHerramientas; }
	public void setGestorHerramientas(GestorHerramientas gestorHerramientas) { this.gestorHerramientas = gestorHerramientas; }
	
	public JLabel getLogoULL() { return logoULL; }
	public void setLogoULL(JLabel logoULL) { this.logoULL = logoULL; }
	
	public VentanaPrincipal () {
		setTitle(getTitulo());
		getContentPane().setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(X, Y, ANCHO, ALTO);
		setLayout(null);
		
		setMenu(new Menu(this));
		setJMenuBar(getMenu());
		
		JDesktopPane esc = new JDesktopPane();
		esc.setBounds(20, 20, ANCHO - 60, ALTO - 150);
		setEscritorio(esc);
		getEscritorio().setBorder(new LineBorder(Color.BLACK, 2));
		getContentPane().add(getEscritorio());
				
		setPanelInfo(new PanelInformativo());
		getContentPane().add(getPanelInfo());
		cargarLogoULL();
		setVisible(true);
		iniciarGestores();
		
	}
	
	private void iniciarGestores () {
		addComponentListener(new GestorDimensionarVent(this));
		setGestorSubVentanas(new GestorSubVentanas(this));
		setGestorHerramientas(new GestorHerramientas(this));
		
		//setGuiInteligente(new InterfazInteligente(this));
	}
	
	private void cargarLogoULL () {
		BufferedImage logo;
		try {
			logo = ImageIO.read(new File("ull.png"));
			JLabel et = new JLabel (new ImageIcon(logo));
			setLogoULL(et);
			getContentPane().add(getLogoULL());
		} catch (IOException e) { System.out.println("Info: problemas en la carga del logo de la ULL");}
	}
}
