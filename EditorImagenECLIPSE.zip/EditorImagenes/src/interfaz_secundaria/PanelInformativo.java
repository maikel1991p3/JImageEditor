package interfaz_secundaria;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;

@SuppressWarnings("serial")
public class PanelInformativo extends JPanel {

	// Atributos constantes para las dimensiones de la ventana
	private int x = 20;
	private int y = 0;
	private int ancho = 0;
	private int alto = 30;
	private Font letra = new Font(Font.SANS_SERIF, Font.BOLD, 20);
	
	private int r = 0;
	private int g = 0;
	private int b = 0;
	
	// Referencia a la ventana principal
	private VentanaPrincipal refVp;
	
	public int getX() { return x; }
	public void setX(int x) { this.x = x; }
	
	public int getY() { return y; }
	public void setY(int y) { this.y = y; }
	
	public int getAncho() { return ancho; }
	public void setAncho(int ancho) { this.ancho = ancho; }
	
	public int getAlto() { return alto; }
	public void setAlto(int alto) { this.alto = alto; }
	
	public Font getLetra() { return letra; }
	public void setLetra(Font letra) { this.letra = letra; }
	
	public int getR() { return r; }
	public void setR(int r) { this.r = r; }
	
	public int getG() { return g; }
	public void setG(int g) { this.g = g; }
	
	public int getB() { return b; }
	public void setB(int b) { this.b = b; }
	
	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }
	
	public PanelInformativo (VentanaPrincipal vp) {
		setY(vp.getEscritorio().getHeight() + 40);
		setAncho(vp.getEscritorio().getWidth());
		setAlto(alto);
		setBounds(getX(), getY(), getAncho(), getAlto());
		setBorder(new LineBorder(Color.BLACK, 2));
	}
	
	public void setDim (int ancVen, int altVen) {
		setY(altVen - 115);
		setBounds(getX(), getY(), ancVen - 60, 30);
		setFont(getLetra());
	}
	
	protected void paintComponent (Graphics gr) {
		gr.setColor(Color.RED);
		gr.drawString("R ["+ getR() +"]", 10, 20);
		gr.setColor(Color.GREEN);
		gr.drawString("G ["+ getG() +"]", 120, 20);
		gr.setColor(Color.BLUE);
		gr.drawString("B ["+ getB() +"]", 240, 20);
	}
}
