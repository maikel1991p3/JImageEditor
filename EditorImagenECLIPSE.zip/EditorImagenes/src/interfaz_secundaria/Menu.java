package interfaz_secundaria;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.filechooser.FileNameExtensionFilter;

import componentes.SubVentana;

@SuppressWarnings("serial")
public class Menu extends JMenuBar {

	// Atributos del men�
	private JMenu menuArchivo;
	private JMenuItem itemCargarImagen;
	private JFileChooser cargaImagen;
	private JMenuItem itemGuardarImagen;
	private JMenuItem itemSalir;

	private JMenu menuHerramientas;
	private JMenuItem itemHerrRealce;
	private JMenuItem itemHerrEditar;
	private JMenuItem itemHerrHist;


	private JMenu menuInfo;
	private JMenuItem itemInfoProd;
	
	// Referencias a la ventena principal
	private VentanaPrincipal refVp;

	public JMenu getMenuArchivo() {	return menuArchivo;	}
	public void setMenuArchivo(JMenu archivo) {	this.menuArchivo = archivo;	}

	public JMenuItem getItemCargarImagen() { return itemCargarImagen; }
	public void setItemCargarImagen(JMenuItem itemCargarImagen) { this.itemCargarImagen = itemCargarImagen; }

	public JFileChooser getCargaImagen() { return cargaImagen; }
	public void setCargaImagen(JFileChooser cargaImagen) { this.cargaImagen = cargaImagen; }

	public JMenuItem getItemGuardarImagen() { return itemGuardarImagen; }
	public void setItemGuardarImagen(JMenuItem itemGuardarImagen) { this.itemGuardarImagen = itemGuardarImagen; }

	public JMenuItem getItemSalir() { return itemSalir; }
	public void setItemSalir(JMenuItem itemSalir) { this.itemSalir = itemSalir; }
	
	public JMenu getMenuHerramientas() { return menuHerramientas; }
	public void setMenuHerramientas(JMenu menuHerramientas) { this.menuHerramientas = menuHerramientas; }

	public JMenuItem getItemHerrRealce() { return itemHerrRealce; }
	public void setItemHerrRealce(JMenuItem itemHerrRealce) { this.itemHerrRealce = itemHerrRealce; }

	public JMenuItem getItemHerrEditar() { return itemHerrEditar; }
	public void setItemHerrEditar(JMenuItem itemHerrEditar) { this.itemHerrEditar = itemHerrEditar; }

	public JMenuItem getItemHerrHist() { return itemHerrHist; }
	public void setItemHerrHist(JMenuItem itemHerrHist) { this.itemHerrHist = itemHerrHist; }

	public JMenu getMenuInfo() { return menuInfo; }
	public void setMenuInfo(JMenu menuInfo) { this.menuInfo = menuInfo; }
	
	public JMenuItem getItemInfoProd() { return itemInfoProd; }
	public void setItemInfoProd(JMenuItem itemInfoProd) { this.itemInfoProd = itemInfoProd; }
	
	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }

	public Menu (VentanaPrincipal referenciaVp) {
		setRefVp(referenciaVp);
		iniciarMenus();
		setBackground(Color.WHITE);
	}

	private void iniciarMenus () {
		setMenuArchivo(new JMenu("Archivo"));
		setItemCargarImagen(new JMenuItem("Cargar Imagen"));
		setItemGuardarImagen(new JMenuItem("Guardar Imagen"));
		setItemSalir(new JMenuItem("Salir"));
		getMenuArchivo().add(getItemCargarImagen());
		getMenuArchivo().add(getItemGuardarImagen());
		getMenuArchivo().add(getItemSalir());
		add(getMenuArchivo());

		setMenuHerramientas(new JMenu("Herramientas"));
		setItemHerrRealce(new JMenuItem("Herramientas de Realce"));
		setItemHerrEditar(new JMenuItem("Herramientas Editar"));
		setItemHerrHist(new JMenuItem("Herramientas Histogramas"));
		getMenuHerramientas().add(getItemHerrRealce());
		getMenuHerramientas().add(getItemHerrEditar());
		getMenuHerramientas().add(getItemHerrHist());
		add(getMenuHerramientas());

		setMenuInfo(new JMenu("Info."));
		setItemInfoProd(new JMenuItem("Info. del producto"));
		getMenuInfo().add(getItemInfoProd());
		add(getMenuInfo());
		
		iniciarCargayGuardaImagen();
		iniciarOyentesHerramientas ();
		iniciarOyentesInfo ();
	}

	private void iniciarCargayGuardaImagen () {
		setCargaImagen(new JFileChooser());
		getCargaImagen().setCurrentDirectory(null);
		getCargaImagen().setFileSelectionMode(JFileChooser.FILES_ONLY);
		getCargaImagen().setFileFilter(new FileNameExtensionFilter(
				"Im�genes PNG", "png"));

		getItemCargarImagen().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent click) {
				int valor = getCargaImagen().showOpenDialog(new JDialog());
				if(valor == JFileChooser.APPROVE_OPTION) {
					File elegido = getCargaImagen().getSelectedFile();
					try {
						BufferedImage bfImg = ImageIO.read (elegido);
						getRefVp().getGestorSubVentanas().crearSubVentana(bfImg, elegido.getName());

					} catch (Exception e) {
						e.printStackTrace();
					}

				} else if (valor == JFileChooser.CANCEL_OPTION || valor == JFileChooser.ERROR_OPTION) {
					System.out.println("No fichero seleccionado!!");
				}
			}
		});

		getItemGuardarImagen().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				int seleccion = getCargaImagen().showSaveDialog(getCargaImagen());
				//si la opci�n es la correcta
				if (seleccion == JFileChooser.APPROVE_OPTION) {
					try {
						ImageIO.write(((SubVentana) getRefVp().getEscritorio().getSelectedFrame()).getRefBufImg (), 
								"png", getCargaImagen().getSelectedFile());
					} catch (IOException e) { System.out.println("Ocurrio algun error guardano el archivo!!");	}

				} else if (seleccion == JFileChooser.CANCEL_OPTION || seleccion == JFileChooser.ERROR_OPTION) {
					System.out.println("No fichero seleccionado!!");
				}
			}
		});
		
		getItemSalir().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getRefVp().getGestorSubVentanas().getVentanInfo().dispose();
				getRefVp().getGestorHerramientas().dispose();
				getRefVp().getInfoPrograma().dispose();
				getRefVp().dispose();
			}
		});
	}

	private void iniciarOyentesHerramientas () {
		getItemHerrRealce().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!getRefVp().getGestorHerramientas().isVisible())
					getRefVp().getGestorHerramientas().setVisible(true);
				getRefVp().getGestorHerramientas().getHerramientas().get(0).setVisible(true);
				getRefVp().getGestorHerramientas().getHerramientas().get(1).setVisible(false);
				getRefVp().getGestorHerramientas().getHerramientas().get(2).setVisible(false);
				getRefVp().getGestorHerramientas().repaint();
			}
		});

		getItemHerrEditar().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!getRefVp().getGestorHerramientas().isVisible())
					getRefVp().getGestorHerramientas().setVisible(true);
				getRefVp().getGestorHerramientas().getHerramientas().get(0).setVisible(false);
				getRefVp().getGestorHerramientas().getHerramientas().get(1).setVisible(true);
				getRefVp().getGestorHerramientas().getHerramientas().get(2).setVisible(false);
				getRefVp().getGestorHerramientas().repaint();
			}
		});

		getItemHerrHist().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!getRefVp().getGestorHerramientas().isVisible())
					getRefVp().getGestorHerramientas().setVisible(true);
				getRefVp().getGestorHerramientas().getHerramientas().get(0).setVisible(false);
				getRefVp().getGestorHerramientas().getHerramientas().get(1).setVisible(false);
				getRefVp().getGestorHerramientas().getHerramientas().get(2).setVisible(true);
				getRefVp().getGestorHerramientas().repaint();
			}
		});
	}
	
	public void iniciarOyentesInfo () {
		getItemInfoProd().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getRefVp().getInfoPrograma().setVisible(!getRefVp().getInfoPrograma().isVisible());
			}
		});
	}
}
