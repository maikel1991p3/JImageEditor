package interfaz_secundaria;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import componentesGraficosHerramientas.SubVentana;

@SuppressWarnings("serial")
public class Menu extends JMenuBar {

	// Atributos del men�
	private JMenu menuArchivo;
	private JMenuItem itemCargarImagen;
	private JFileChooser cargaImagen;
	private JMenuItem itemGuardarImagen;
	private JMenuItem itemSalir;

	private JMenu menuHerramientas;
	private JMenuItem itemHerrRealce;
	private JMenuItem itemHerrEditar;
	private JMenuItem itemHerrHist;

	private JMenu menuTransformaciones;
	private JMenuItem itemHNoLineales;
	private JMenuItem itemDirectas;
	private JMenuItem itemLineales;
	private JMenuItem itemGeometricas;
	
	private JMenu menuInfo;
	private JMenuItem itemInfoProd;


	// Referencias a la ventena principal
	private VentanaPrincipal refVp;

	public JMenu getMenuArchivo() {	return menuArchivo;	}
	public void setMenuArchivo(JMenu archivo) {	this.menuArchivo = archivo;	}

	public JMenuItem getItemCargarImagen() { return itemCargarImagen; }
	public void setItemCargarImagen(JMenuItem itemCargarImagen) { this.itemCargarImagen = itemCargarImagen; }

	public JFileChooser getCargaImagen() { return cargaImagen; }
	public void setCargaImagen(JFileChooser cargaImagen) { this.cargaImagen = cargaImagen; }

	public JMenuItem getItemGuardarImagen() { return itemGuardarImagen; }
	public void setItemGuardarImagen(JMenuItem itemGuardarImagen) { this.itemGuardarImagen = itemGuardarImagen; }

	public JMenuItem getItemSalir() { return itemSalir; }
	public void setItemSalir(JMenuItem itemSalir) { this.itemSalir = itemSalir; }

	public JMenu getMenuHerramientas() { return menuHerramientas; }
	public void setMenuHerramientas(JMenu menuHerramientas) { this.menuHerramientas = menuHerramientas; }

	public JMenuItem getItemHerrRealce() { return itemHerrRealce; }
	public void setItemHerrRealce(JMenuItem itemHerrRealce) { this.itemHerrRealce = itemHerrRealce; }

	public JMenuItem getItemHerrEditar() { return itemHerrEditar; }
	public void setItemHerrEditar(JMenuItem itemHerrEditar) { this.itemHerrEditar = itemHerrEditar; }

	public JMenuItem getItemHerrHist() { return itemHerrHist; }
	public void setItemHerrHist(JMenuItem itemHerrHist) { this.itemHerrHist = itemHerrHist; }

	public JMenu getMenuTransformaciones() { return menuTransformaciones; }
	public void setMenuTransformaciones(JMenu menuTransformaciones) { this.menuTransformaciones = menuTransformaciones; }

	public JMenuItem getItemHNoLineales() { return itemHNoLineales; }
	public void setItemHNoLineales(JMenuItem itemHNoLineales) { this.itemHNoLineales = itemHNoLineales; }

	public JMenuItem getItemGeometricas() { return itemGeometricas; }
	public void setItemGeometricas(JMenuItem itemGeometricas) { this.itemGeometricas = itemGeometricas; }
	
	public JMenuItem getItemDirectas() { return itemDirectas; }
	public void setItemDirectas(JMenuItem itemDirectas) { this.itemDirectas = itemDirectas; }

	public JMenuItem getItemLineales() { return itemLineales; }
	public void setItemLineales(JMenuItem itemLineales) { this.itemLineales = itemLineales; }
	
	public JMenu getMenuInfo() { return menuInfo; }
	public void setMenuInfo(JMenu menuInfo) { this.menuInfo = menuInfo; }

	public JMenuItem getItemInfoProd() { return itemInfoProd; }
	public void setItemInfoProd(JMenuItem itemInfoProd) { this.itemInfoProd = itemInfoProd; }

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }

	public Menu (VentanaPrincipal referenciaVp) {
		setRefVp(referenciaVp);
		iniciarMenus();
		setBackground(Color.WHITE);
	}

	private void iniciarMenus () {
		setMenuArchivo(new JMenu("Archivo"));
		getMenuArchivo().setToolTipText("Contiene las operaciones de entrada / salida de datos del programa (im�genes)");
		setItemCargarImagen(new JMenuItem("Cargar Imagen"));
		setItemGuardarImagen(new JMenuItem("Guardar Imagen"));
		setItemSalir(new JMenuItem("Salir"));
		getItemSalir().setBorder(new LineBorder(Color.LIGHT_GRAY, 1));
		getMenuArchivo().add(getItemCargarImagen());
		getMenuArchivo().add(getItemGuardarImagen());
		getMenuArchivo().add(getItemSalir());
		add(getMenuArchivo());

		setMenuHerramientas(new JMenu("Herramientas"));
		getMenuHerramientas().setToolTipText("Agrupa un conjunto de herramientas que permiten realizar diversas operaciones sobre im�genes.");
		setItemHerrRealce(new JMenuItem("Herramientas de Realce"));
		getItemHerrRealce().setToolTipText("Herramientas para regular el brillo, mejorar el contraste, ...");
		setItemHerrEditar(new JMenuItem("Herramientas Editar"));
		getItemHerrEditar().setToolTipText("Herramientas para duplicar, ampliar, etc.");
		setItemHerrHist(new JMenuItem("Herramientas Histogramas"));
		getItemHerrHist().setToolTipText("Permite la visualizaci�n de varios tipos de histogramas de la imagen.");

		getMenuHerramientas().add(getItemHerrRealce());
		getMenuHerramientas().add(getItemHerrEditar());
		getMenuHerramientas().add(getItemHerrHist());
		add(getMenuHerramientas());

		setMenuTransformaciones(new JMenu("Transformaciones"));
		getMenuTransformaciones().setToolTipText("Agrupa un conjunto de herramientas para realizar transformaciones sobre la imagen.");
		setItemHNoLineales(new JMenuItem("Transformaciones no lineales"));
		getItemHNoLineales().setToolTipText("T�cnicas de tratamiento de im�genes NO LINEALES.");
		getMenuTransformaciones().add(getItemHNoLineales());
		setItemDirectas(new JMenuItem("Transformaciones directas"));
		getItemDirectas().setToolTipText("T�cnicas de tratamiento de im�genes que se realizan de forma inmediata.");
		getMenuTransformaciones().add(getItemDirectas());
		setItemLineales(new JMenuItem ("Transformaciones lineales"));
		getItemLineales().setToolTipText("Especificaciones y transformaciones lineales sobre la imagen");
		getMenuTransformaciones().add(getItemLineales());
		add(getMenuTransformaciones());
		setItemGeometricas(new JMenuItem ("Operaciones Geom�tricas"));
		getItemGeometricas().setToolTipText("Operaciones de ESCALADO, ROTACIONES, ect.");
		getMenuTransformaciones().add(getItemGeometricas());
		add(getMenuTransformaciones());

		setMenuInfo(new JMenu("Info."));
		setItemInfoProd(new JMenuItem("Info. del producto"));
		getMenuInfo().add(getItemInfoProd());
		add(getMenuInfo());

		iniciarCargayGuardaImagen();
		iniciarOyentesHerramientas ();
		iniciarOyentesInfo ();
	}

	private void iniciarCargayGuardaImagen () {
		setCargaImagen(new JFileChooser());
		getCargaImagen().setCurrentDirectory(null);
		getCargaImagen().setFileSelectionMode(JFileChooser.FILES_ONLY);
		getCargaImagen().setFileFilter(new FileNameExtensionFilter("Im�genes JPEG", "jpeg"));
		getCargaImagen().setFileFilter(new FileNameExtensionFilter("Im�genes PNG", "png"));
		getCargaImagen().setFileFilter(new FileNameExtensionFilter("Im�genes GIF", "gif"));
		getCargaImagen().setFileFilter(new FileNameExtensionFilter("Im�genes TIF", "tif"));
		getCargaImagen().setFileFilter(new FileNameExtensionFilter("Im�genes JPG", "jpg"));

		getItemCargarImagen().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent click) {
				int valor = getCargaImagen().showOpenDialog(new JDialog());
				if(valor == JFileChooser.APPROVE_OPTION) {
					File elegido = getCargaImagen().getSelectedFile();
					try {
						BufferedImage bfImg = getRefVp().getGestorSubVentanas().getGestor().pasarAEscalaGrises(ImageIO.read (elegido));
						
						getRefVp().getGestorSubVentanas().crearSubVentana(bfImg, 
								elegido.getName(), true);

					} catch (Exception e) {
						System.out.println("Menu.java: Problemas al cargar la imagen !!");
						e.printStackTrace();
					}

				} else if (valor == JFileChooser.CANCEL_OPTION || valor == JFileChooser.ERROR_OPTION) {
					System.out.println("No fichero de imagen seleccionado!!");
				}
			}
		});

		getItemGuardarImagen().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					if (getRefVp().getEscritorio().getSelectedFrame() != null) {
						int seleccion = getCargaImagen().showSaveDialog(getCargaImagen());
						//si la opci�n es la correcta
						if (seleccion == JFileChooser.APPROVE_OPTION) {

							ImageIO.write(((SubVentana) getRefVp().getEscritorio().getSelectedFrame()).getRefBufImg (), 
									"png", getCargaImagen().getSelectedFile());

						} else if (seleccion == JFileChooser.CANCEL_OPTION || seleccion == JFileChooser.ERROR_OPTION) {
							System.out.println("No fichero seleccionado!!");
						}
					}
				} catch (Exception e) { System.out.println("Ocurrio algun error guardano el archivo!!");	}
			}
		});

		getItemSalir().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
	}

	private void iniciarOyentesHerramientas () {
		getItemHerrRealce().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				visualizarHerramienta(0);
			}
		});

		getItemHerrEditar().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				visualizarHerramienta(1);
			}
		});

		getItemHerrHist().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				visualizarHerramienta(2);
			}
		});

		getItemHNoLineales().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				visualizarHerramienta(3);	
			}
		});

		getItemDirectas().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				visualizarHerramienta(4);
			}
		});
		
		getItemLineales().addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				visualizarHerramienta(5);
			}
		});
		
		getItemGeometricas().addActionListener(new ActionListener() {
	
			@Override
			public void actionPerformed(ActionEvent arg0) {
				visualizarHerramienta(6);
			}
		});
	}

	public void iniciarOyentesInfo () {
		getItemInfoProd().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getRefVp().getInfoPrograma().setVisible(!getRefVp().getInfoPrograma().isVisible());
			}
		});
	}

	public void visualizarHerramienta(int h) {
		if (!getRefVp().getGestorHerramientas().isVisible())
			getRefVp().getGestorHerramientas().setVisible(true);
		for (int i = 0; i < getRefVp().getGestorHerramientas().getHerramientas().size(); ++i) {
			getRefVp().getGestorHerramientas().getHerramientas().get(i).setVisible(false);
		}
		getRefVp().getGestorHerramientas().getHerramientas().get(h).setVisible(true);
		getRefVp().getGestorHerramientas().repaint();
	}
}
