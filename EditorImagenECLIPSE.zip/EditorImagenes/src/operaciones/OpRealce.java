package operaciones;

import java.awt.image.BufferedImage;

import interfaz_principal.VentanaPrincipal;

import javax.swing.JDesktopPane;

public class OpRealce {
	private VentanaPrincipal refVp; 
	
	public VentanaPrincipal getRefVp() { return refVp;	}
	public void setRefVp(VentanaPrincipal vp) {	this.refVp = vp;	}

	public OpRealce (VentanaPrincipal vp) {
		setRefVp(vp);
	}
	
	/**
	 * Devuelve un bufferedIm nuevo para ser tratado sin modificar
	 * el original.
	 * @return bf
	 */
	public BufferedImage copiarBufferImage () {
		int ventAct = getRefVp().getGestorSubVentanas().getNumVentActual();
		BufferedImage bf = new BufferedImage(getRefVp().getGestorSubVentanas().getSubVentanas().get(ventAct).getRefBufImg().getWidth(), 
				getRefVp().getGestorSubVentanas().getSubVentanas().get(ventAct).getRefBufImg().getHeight(), 
				getRefVp().getGestorSubVentanas().getSubVentanas().get(ventAct).getRefBufImg().getType());
		return bf;
	}

	public boolean calcularBrillo () {
		int ventAct = getRefVp().getGestorSubVentanas().getNumVentActual();
		if (getRefVp().getGestorSubVentanas().getSubVentanas().get(ventAct).getRefBufImg() != null) {
			BufferedImage bf = copiarBufferImage();
			
			
		}
		// HACERRRRRR!! -> Importante seguir el esquema abajo descrito xk se usa en funciones externas
		// si -> no hay imagen actual -> return false
		// else -> calcular valores del brillo
		System.out.println("cal brillo");
		return false;
	}

	public void representarBillo () {
		// HACERRR
		// Se muestra la imagen con brillo cambiado
		System.out.println("img con brillo cambiado");
	}

	public boolean calcularContraste () {
		// HACERRRRRR!! -> Importante seguir el esquema abajo descrito xk se usa en funciones externas
		// si -> no hay imagen actual -> return false
		// else -> calcular valores del contraste
		System.out.println("cal contraste");
		return false;
	}

	public void representarContraste () {
		// HACERRR
		// Se muestra la imagen con contraste cambiado
		System.out.println("img con contraste cambiado");
	}

	public void indicarError () {
		// HACERRR
		// Se muestra un mensaje de error que indica que no se ha cargado
		// una imagen previa a la que calcularle el histograma
		System.out.println("no imagen para cal realce!!");
	}
}
