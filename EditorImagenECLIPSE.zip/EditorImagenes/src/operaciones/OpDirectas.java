package operaciones;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.HashMap;

import interfaz_principal.VentanaPrincipal;

/**
 * Los m�todo aqu� descritos devuelven un NUEVO buffer que contiene el 
 * resultado de la operaci�n con la que se trat�.
 * @author Maikel
 *
 */

public class OpDirectas {
	private VentanaPrincipal refVp; 

	public VentanaPrincipal getRefVp() { return refVp;	}
	public void setRefVp(VentanaPrincipal vp) {	this.refVp = vp;	}

	public OpDirectas (VentanaPrincipal refvp) {
		setRefVp(refvp);
	}

	/*operaciones*/
	public BufferedImage negativizar (BufferedImage bf) {
		BufferedImage negativo = new BufferedImage (bf.getWidth(), bf.getHeight(), bf.getType());
		HashMap<Integer, Integer> tabla = transformacionNegativizar();
		int temp = 0;
		for (int i = 0; i < negativo.getWidth(); ++i) {
			for (int j = 0; j < negativo.getHeight(); ++j) {
				temp = tabla.get(new Color(bf.getRGB(i, j)).getRed());
				negativo.setRGB(i, j, new Color(temp, temp, temp).getRGB());
			}
		}

		return negativo;
	}

	public BufferedImage umbralizar (BufferedImage bf, int umbral) {
		BufferedImage umbralizada = new BufferedImage (bf.getWidth(), bf.getHeight(), bf.getType());
		HashMap<Integer, Integer> tabla = transformacionUmbralizar(umbral);
		int temp = 0;
		for (int i = 0; i < umbralizada.getWidth(); ++i) {
			for (int j = 0; j < umbralizada.getHeight(); ++j) {
				temp = tabla.get(new Color(bf.getRGB(i, j)).getRed());
				umbralizada.setRGB(i, j, new Color(temp, temp, temp).getRGB());
			}
		}

		return umbralizada;
	}

	/*Tablas de transformaciones*/
	public HashMap<Integer, Integer> transformacionNegativizar(){
		HashMap<Integer, Integer> tabla = new HashMap<Integer, Integer> ();
		for (int i = 0; i < 256; ++i)
			tabla.put(i, 255 - i);
		return tabla;
	}

	public HashMap<Integer, Integer> transformacionUmbralizar(int umbral){
		HashMap<Integer, Integer> tabla = new HashMap<Integer, Integer> ();
		int temp = 0;
		for (int i = 0; i < 256; ++i) {
			if (i < umbral)
				temp = 0;
			else
				temp = 255;
			tabla.put(i, temp);
		}
		return tabla;
	}
}	
