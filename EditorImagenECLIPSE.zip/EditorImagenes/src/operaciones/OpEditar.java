package operaciones;

import interfaz_principal.VentanaPrincipal;

import java.awt.Point;
import java.awt.image.BufferedImage;

import componentes.SubVentana;

public class OpEditar {
		private VentanaPrincipal refVp; 
		
		public VentanaPrincipal getRefVp() { return refVp;	}
		public void setRefVp(VentanaPrincipal vp) {	this.refVp = vp;	}

		public OpEditar (VentanaPrincipal refvp) {
			setRefVp(refvp);
		}
		
		public double distEuclidea (Point p, Point q) {
			return Math.sqrt(Math.pow((q.getX() - p.getX()), 2) + Math.pow((q.getY() - p.getY()), 2));
		}
		
		// Hay que pasarle los puntos de la regi�n correctamente!!
		public void crearSubImagen (Point ini, Point fin) {
			int vAct = getRefVp().getGestorSubVentanas().getNumVentActual();
			BufferedImage imgAct = getRefVp().getGestorSubVentanas().getSubVentanas().get(vAct).getRefBufImg();
			
			// h^2 = ancho^2 + alto^2; -> Pit�goras!!
			int alto = (int) Math.round(fin.getY() - ini.getY());
			int h = (int) Math.round(distEuclidea(ini, fin));
			int ancho = (int) Math.round(Math.sqrt(Math.pow(h, 2) - Math.pow(alto, 2)));
			try {
				BufferedImage subImg = imgAct.getSubimage((int) Math.round(ini.getX()), (int) Math.round(ini.getY()), ancho, alto);
			
				SubVentana subVent = new SubVentana(subImg, "SubImagen");
				subVent.setTitle(String.valueOf(getRefVp().getGestorSubVentanas().getSubVentanas().size()));
				subVent.setSize(subImg.getWidth(), subImg.getHeight());
				getRefVp().getEscritorio().add(subVent);
			} catch (Exception e) { System.out.println("Se pas� de los l�mites de la imagen de partida!!"); }
		}
}
