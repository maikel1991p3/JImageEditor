package operaciones;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.Point;
import java.awt.image.BufferedImage;

import componentes.SubVentana;

public class OpEditar {
		private VentanaPrincipal refVp; 
		
		public VentanaPrincipal getRefVp() { return refVp;	}
		public void setRefVp(VentanaPrincipal vp) {	this.refVp = vp;	}

		public OpEditar (VentanaPrincipal refvp) {
			setRefVp(refvp);
		}
		
		public double distEuclidea (Point p, Point q) {
			return Math.sqrt(Math.pow((q.getX() - p.getX()), 2) + Math.pow((q.getY() - p.getY()), 2));
		}
		
		// Hay que pasarle los puntos de la regi�n correctamente!!
		public void crearSubImagen (Point ini, Point fin) {
			int ancho = (int) Math.round(fin.getX() - ini.getX());
			int alto = (int) Math.round(fin.getY() - ini.getY());
			System.out.println("an: " + ancho + "   al: " + alto);
			try {
				BufferedImage subImg = new BufferedImage (ancho, alto, getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getType());
				
				for (int i = 0; i < ancho; ++i) {
					for (int j = 0; j < alto; ++j) {
						subImg.setRGB(i, j,getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getRGB((int) ini.getX() + i,
								(int) ini.getY() + j));
					}
				}
				
				getRefVp().getGestorSubVentanas().crearSubVentana(subImg, 
						"SubImagen de " + getRefVp().getGestorSubVentanas().getRefSubVentActual().getTitle(), false);
				
			} catch (Exception e) {  }
		}
		
}
