package operaciones;

import interfaz_principal.VentanaPrincipal;

import java.awt.Point;
import java.awt.image.BufferedImage;

import componentes.SubVentana;

public class OpEditar {
		private VentanaPrincipal refVp; 
		
		public VentanaPrincipal getRefVp() { return refVp;	}
		public void setRefVp(VentanaPrincipal vp) {	this.refVp = vp;	}

		public OpEditar (VentanaPrincipal refvp) {
			setRefVp(refvp);
		}
		
		public double distEuclidea (Point p, Point q) {
			return Math.sqrt(Math.pow((q.getX() - p.getX()), 2) + Math.pow((q.getY() - p.getY()), 2));
		}
		
		// Hay que pasarle los puntos de la regi�n correctamente!!
		public void crearSubImagen (Point ini, Point fin) {
			int vAct = getRefVp().getGestorSubVentanas().getNumVentActual();
			BufferedImage imgAct = getRefVp().getGestorSubVentanas().getSubVentanas().get(vAct).getRefBufImg();
			
			int ancho = (int) Math.round(fin.getX() - ini.getX());
			int alto = (int) Math.round(fin.getY() - ini.getY());
			
			try {
				BufferedImage subImg = imgAct.getSubimage((int) Math.round(ini.getX()), (int) Math.round(ini.getY()), ancho, alto);
				int nVact = getRefVp().getGestorSubVentanas().getNumVentActual();
				SubVentana subVent = new SubVentana(subImg, nVact + 1, getRefVp().getGestorSubVentanas().getSubVentanas().get(nVact).getTitle());
				subVent.setTitle(String.valueOf(getRefVp().getGestorSubVentanas().getSubVentanas().size()));
				subVent.setSize(subImg.getWidth(), subImg.getHeight());
				getRefVp().getEscritorio().add(subVent);
			} catch (Exception e) {  }
		}
		
		public void ampliarSubImagen (Point ini, Point fin) {
			
			int vAct = getRefVp().getGestorSubVentanas().getNumVentActual();
			BufferedImage imgAct = getRefVp().getGestorSubVentanas().getSubVentanas().get(vAct).getRefBufImg();
			
			int ancho = (int) Math.round(fin.getX() - ini.getX());
			int alto = (int) Math.round(fin.getY() - ini.getY());
			
			try {
				BufferedImage subImg = imgAct.getSubimage((int) Math.round(ini.getX()), (int) Math.round(ini.getY()), ancho, alto);
				BufferedImage subImgAmpliada = (BufferedImage) subImg.getScaledInstance(imgAct.getWidth(), imgAct.getHeight(), BufferedImage.SCALE_SMOOTH);
				
				SubVentana subVent = new SubVentana(imgAct, subImgAmpliada, "SubImagen");
				subVent.setTitle(String.valueOf(getRefVp().getGestorSubVentanas().getSubVentanas().size()));
				getRefVp().getEscritorio().add(subVent);
				
			} catch (Exception e) {  }
		}
		
}
