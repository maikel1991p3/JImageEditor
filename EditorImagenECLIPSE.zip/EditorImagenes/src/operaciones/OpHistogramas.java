package operaciones;

import interfaz_principal.VentanaPrincipal;

import componentes.GraficaHistograma;

public class OpHistogramas {
	
	private VentanaPrincipal refVp; 
	
	public VentanaPrincipal getRefVp() { return refVp;	}
	public void setRefVp(VentanaPrincipal vp) {	this.refVp = vp;	}

	public OpHistogramas (VentanaPrincipal refvp) {
		setRefVp(refvp);
	}
	
	public void representarHistogramaAbs () {
		if (getRefVp().getGestorSubVentanas().getSubVentanas().size() > 0) {
			int nVentana = getRefVp().getGestorSubVentanas().getNumVentActual();
			getRefVp().getGestorSubVentanas().getSubVentanas().get(nVentana).obtenerHistograma(getRefVp().getGestorSubVentanas().getSubVentanas().get(nVentana).getRefBufImg());
			GraficaHistograma grafica = new GraficaHistograma(getRefVp().getGestorSubVentanas().getSubVentanas().get(nVentana).getHistogramaAbs(), 1);
		}
	}
	
	
	public void representarHistogramaAc () {
		if (getRefVp().getGestorSubVentanas().getSubVentanas().size() > 0) {
			int nVentana = getRefVp().getGestorSubVentanas().getNumVentActual();
			getRefVp().getGestorSubVentanas().getSubVentanas().get(nVentana).obtenerHistograma(getRefVp().getGestorSubVentanas().getSubVentanas().get(nVentana).getRefBufImg());
			GraficaHistograma grafica = new GraficaHistograma(getRefVp().getGestorSubVentanas().getSubVentanas().get(nVentana).getHistogramaAc(), 2);
		}
	}

}
