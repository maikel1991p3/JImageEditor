package operaciones;

import javax.swing.JDesktopPane;

public class OpHistogramas {
	
	private JDesktopPane refEscritorio; 
	
	public JDesktopPane getRefEscritorio() { return refEscritorio; }
	public void setRefEscritorio(JDesktopPane refEscritorio) { this.refEscritorio = refEscritorio; }

	public OpHistogramas (JDesktopPane refEscritorio) {
		setRefEscritorio(refEscritorio);
	}
	
	public boolean calcularHistogramaAbs () {
		// HACERRRRRR!! -> Importante seguir el esquema abajo descrito xk se usa en funciones externas
		// si -> no hay imagen actual -> return false
		// else -> calcular valores del histograma y return true
		System.out.println("calc. hist. abs");
		return false;
	}
	
	public void representarHistogramaAbs () {
		// HACERRR
		// Se muestra el histograma dibujado en un panel gr�fico!!
		System.out.println("most. hist. abs.");
	}
	
	public boolean calcularHistogramaRel () {
		// HACERRRRRR!! -> Importante seguir el esquema abajo descrito xk se usa en funciones externas
		// si -> no hay imagen actual -> return false
		// else -> calcular valores del histograma y return true
		System.out.println("cal hist acuml");
		return false;
	}
	
	public void representarHistogramaRel () {
		// HACERRR
		// Se muestra el histograma dibujado en un panel gr�fico!!
		System.out.println("most hist acuml");
	}
	
	public void indicarError () {
		// HACERRR
		// Se muestra un mensaje de error que indica que no se ha cargado
		// una imagen previa a la que calcularle el histograma
		System.out.println("no imagen para cal hist!!");
	}
}
