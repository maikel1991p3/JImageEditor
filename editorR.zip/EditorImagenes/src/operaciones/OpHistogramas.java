package operaciones;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.HashMap;

import componentesGraficosHerramientas.GraficaHistograma;
import componentesGraficosHerramientas.SubVentana;

public class OpHistogramas {

	private VentanaPrincipal refVp; 
	private HashMap<Integer, Integer> tabla = new HashMap<Integer, Integer> ();

	public VentanaPrincipal getRefVp() { return refVp;	}
	public void setRefVp(VentanaPrincipal vp) {	this.refVp = vp;	}

	public HashMap<Integer, Integer> getTabla() { return tabla; }
	public void setTabla(HashMap<Integer, Integer> tabla) {	this.tabla = tabla;	}
	
	public OpHistogramas (VentanaPrincipal refvp) {
		setRefVp(refvp);
	}

	public void representarHistogramaAbs () {
		if (getRefVp().getGestorSubVentanas().getSubVentanas().size() > 0) {
			GraficaHistograma grafica = new GraficaHistograma(getRefVp().getGestorSubVentanas().getRefSubVentActual().getHistogramaAbs(), 1);
		}
	}


	public void representarHistogramaAc () {
		if (getRefVp().getGestorSubVentanas().getSubVentanas().size() > 0) {
			GraficaHistograma grafica = new GraficaHistograma(getRefVp().getGestorSubVentanas().getRefSubVentActual().getHistogramaAc(), 2);
		}
	}

	public BufferedImage ecualizar (SubVentana temp) {
		rellenarTabla (temp);
		BufferedImage im = new BufferedImage (temp.getRefBufImg ().getWidth (), temp.getRefBufImg ().getHeight (), temp.getRefBufImg ().getType ());
		
		for (int i = 0; i < im.getWidth (); ++i) {
			for (int j = 0; j < im.getHeight (); ++j) {
				int aux = getTabla().get(new Color (temp.getRefBufImg ().getRGB (i, j)).getRed ());
				im.setRGB (i, j, new Color (aux, aux, aux).getRGB ());
			}
		}
		return im;
	}

	public void rellenarTabla (SubVentana temp) {
		
		double valor = 0.0;
		int [] hist = temp.getHistogramaAc ();
		
		double factor = (255.0 / (double) (temp.getRefBufImg().getWidth() * temp.getRefBufImg().getHeight ()));
		
		try {
			for (int i = 0; i < hist.length; ++i) {
				valor = hist[i] * factor; 
				if (valor > 255)
					getTabla().put (i, 255);
				else
					getTabla().put (i, (int) Math.round (valor));
			}

		} catch (ArithmeticException ar) {
			System.out.println("OpHist: aviso! excep aritm!");
			
		} catch (Exception e) {
			System.out.println("OpHist: aviso! EXCP GENERAL!");
		}
	}

}
