package operaciones;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.HashMap;

import interfaz_principal.VentanaPrincipal;

/**
 * Los m�todo aqu� descritos devuelven un NUEVO buffer que contiene el 
 * resultado de la operaci�n con la que se trat�.
 * @author Maikel
 *
 */

public class OpGeom {
	private VentanaPrincipal refVp; 

	public VentanaPrincipal getRefVp() { return refVp;	}
	public void setRefVp(VentanaPrincipal vp) {	this.refVp = vp;	}

	public OpGeom (VentanaPrincipal refvp) {
		setRefVp(refvp);
	}

	/*operaciones*/
	public BufferedImage espejoHorizontal () {
		int ancho = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getWidth();
		int alto = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getHeight();
		int tipo = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getType();
		BufferedImage temp = new BufferedImage(ancho, alto, tipo);
		int colorNuevo;
		
		for (int i = 0; i < alto; ++i)
			for (int j = 0; j < ancho; ++j) {
				colorNuevo = new Color(getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getRGB((ancho - 1) - j, i)).getRed();
				temp.setRGB(j, i, new Color (colorNuevo, colorNuevo, colorNuevo).getRGB());
			}
		return temp;
	}
	
	public BufferedImage espejoVertical () {
		int ancho = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getWidth();
		int alto = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getHeight();
		int tipo = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getType();
		BufferedImage temp = new BufferedImage(ancho, alto, tipo);
		
		int colorNuevo;
		
		for (int i = 0; i < alto; ++i)
			for (int j = 0; j < ancho; ++j) {
				colorNuevo = new Color(getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getRGB(j, (alto - 1) - i)).getRed();
				temp.setRGB(j, i, new Color (colorNuevo, colorNuevo, colorNuevo).getRGB());
			}
		return temp;
	}
	
	public BufferedImage traspuesta () {
		int alto = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getWidth();
		int ancho = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getHeight();
		int tipo = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getType();
		BufferedImage temp = new BufferedImage(ancho, alto, tipo);
		
		int colorNuevo;
		
		for (int i = 0; i < alto; ++i)
			for (int j = 0; j < ancho; ++j) {
				colorNuevo = new Color(getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getRGB(i, j)).getRed();
				temp.setRGB(j, i, new Color (colorNuevo, colorNuevo, colorNuevo).getRGB());
			}
		return temp;
	}
	
	public BufferedImage rotarDerecha () {	//90
		int alto = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getWidth();
		int ancho = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getHeight();
		int tipo = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getType();
		BufferedImage temp = new BufferedImage(ancho, alto, tipo);
		int colorNuevo;
		
		for (int i = 0; i < alto; ++i)
			for (int j = 0; j < ancho; ++j) {
				colorNuevo = new Color(getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getRGB(i, (ancho - 1) - j)).getRed();
				temp.setRGB(j, i, new Color (colorNuevo, colorNuevo, colorNuevo).getRGB());
			}
		return temp;
	}
	
	public BufferedImage rotarAbajo () {		//180
		int ancho = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getWidth();
		int alto = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getHeight();
		int tipo = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getType();
		BufferedImage temp = new BufferedImage(ancho, alto, tipo);
		
		int colorNuevo;
		
		for (int i = 0; i < alto; ++i)
			for (int j = 0; j < ancho; ++j) {
				colorNuevo = new Color(getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getRGB((ancho - 1) - j,(alto - 1) - i)).getRed();
				temp.setRGB(j, i, new Color (colorNuevo, colorNuevo, colorNuevo).getRGB());
			}
		return temp;
	}

	public BufferedImage rotarIzquierda () {		//270
		int alto = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getWidth();
		int ancho = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getHeight();
		int tipo = getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getType();
		BufferedImage temp = new BufferedImage(ancho, alto, tipo);
		
		int colorNuevo;
		
		for (int i = 0; i < alto; ++i)
			for (int j = 0; j < ancho; ++j) {
				colorNuevo = new Color(getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg().getRGB((alto - 1) - i, j)).getRed();
				temp.setRGB(j, i, new Color (colorNuevo, colorNuevo, colorNuevo).getRGB());
			}
		return temp;
	}
	
	/*Tablas de transformaciones*/
	public HashMap<Integer, Integer> transformacionNegativizar(){
		HashMap<Integer, Integer> tabla = new HashMap<Integer, Integer> ();
		for (int i = 0; i < 256; ++i)
			tabla.put(i, 255 - i);
		return tabla;
	}

	public HashMap<Integer, Integer> transformacionUmbralizar(int umbral){
		HashMap<Integer, Integer> tabla = new HashMap<Integer, Integer> ();
		int temp = 0;
		for (int i = 0; i < 256; ++i) {
			if (i < umbral)
				temp = 0;
			else
				temp = 255;
			tabla.put(i, temp);
		}
		return tabla;
	}
}	
