package operaciones;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.HashMap;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class OpMapaCambios {

	private VentanaPrincipal ventanaPrincipal;
	private JDialog ventanaError = new JDialog();
	private JLabel error = new JLabel("Error : Im�genes de diferentes tama�os");


	public VentanaPrincipal getVentanaPrincipal() { return ventanaPrincipal; }
	public void setVentanaPrincipal(VentanaPrincipal ventanaPrincipal) { this.ventanaPrincipal = ventanaPrincipal; }

	public JDialog getVentanaError() { return ventanaError; }
	public void setVentanaError(JDialog ventanaError) { this.ventanaError = ventanaError; }

	public JLabel getError() { return error; }
	public void setError(JLabel error) { this.error = error; }

	public OpMapaCambios(VentanaPrincipal vp) {
		setVentanaPrincipal(vp);
		inicializarVentanaError();
	}

	/*Operacion y tabla de transformaci�n*/
	public BufferedImage mapaDeCambios(BufferedImage img1, BufferedImage img2, int uCambio) {
		BufferedImage imgResult = null;
		if (img1.getWidth() == img2.getWidth() && img1.getHeight() == img2.getHeight()) {
			//Para poder hacer el mapa de cambios las dos imagenes tienen que tener la misma cantidad de pixels
			imgResult = new BufferedImage(img1.getWidth(), img1.getHeight(), img1.getType());
			HashMap<Integer, Integer> tabla = tablaTransformacion(uCambio);
			int temp = 0;
			for (int i = 0; i < imgResult.getWidth(); ++i) {
				for (int j = 0; j < imgResult.getHeight(); ++j) {
					temp = tabla.get(Math.abs(new Color(img1.getRGB(i, j)).getRed() - new Color(img2.getRGB(i, j)).getRed()));
					if (temp == -1) {
						imgResult.setRGB(i, j, Color.GREEN.getRGB()); // Cambia

					} else {
						imgResult.setRGB(i, j, img1.getRGB(i, j)); // No Cambia
					}
				}
			}

		} else
			getVentanaError().setVisible(true);

		return imgResult;
	}

	public HashMap<Integer, Integer> tablaTransformacion(int uCambio) {
		// Si el valor es mayor que cambio entonces -1
		HashMap<Integer, Integer> tabla = new HashMap<>();
		int temp = 0;
		for (int i = 0; i < 256; ++i) {
			if (i > uCambio)
				temp = -1;
			else
				temp = i;
			tabla.put(i, temp);
		}
		return tabla;
	}

	public BufferedImage restaDeDosImagenes(BufferedImage img1, BufferedImage img2) {
		BufferedImage imgResult = null;
		if (img1.getWidth() == img2.getWidth() && img1.getHeight() == img2.getHeight()) {
			// Para poder hacer el mapa de cambios las dos imagenes tienen que tener la misma cantidad de pixels
			imgResult = new BufferedImage(img1.getWidth(), img1.getHeight(), img1.getType());
			int temp = 0;

			for (int i = 0; i < imgResult.getWidth(); ++i) {
				for (int j = 0; j < imgResult.getHeight(); ++j) {
					temp = Math.abs(new Color(img1.getRGB(i, j)).getRed() - new Color(img2.getRGB(i, j)).getRed());
					imgResult.setRGB(i, j, new Color (temp, temp, temp).getRGB());//No cambia
				}
			}

		} else
			getVentanaError().setVisible(true);

		return imgResult;
	}

	public void inicializarVentanaError() {
		getVentanaError().setSize(300, 50);
		getVentanaError().setLocation(200, 300);
		getVentanaError().setAlwaysOnTop(true);
		getVentanaError().setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		getVentanaError().add(getError());
	}

}
