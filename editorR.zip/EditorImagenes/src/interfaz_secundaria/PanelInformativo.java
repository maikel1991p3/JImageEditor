package interfaz_secundaria;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;

@SuppressWarnings("serial")
public class PanelInformativo extends JPanel {

	// Atributos constantes para las dimensiones de la ventana
	private int x = 20;
	private int y;
	private int ancho = 0;
	private int alto = 30;
	private Font letra = new Font(Font.SANS_SERIF, Font.BOLD, 15);
	
	private int r = 0;
	private int g = 0;
	private int b = 0;
	
	private int posX = 0;
	private int posY = 0;
	
	public int getX() { return x; }
	public void setX(int x) { this.x = x; }
	
	public int getY() { return y; }
	public void setY(int y) { this.y = y; }
	
	public int getAncho() { return ancho; }
	public void setAncho(int ancho) { this.ancho = ancho; }
	
	public int getAlto() { return alto; }
	public void setAlto(int alto) { this.alto = alto; }
	
	public Font getLetra() { return letra; }
	public void setLetra(Font letra) { this.letra = letra; }
	
	public int getR() { return r; }
	public void setR(int r) { this.r = r; }
	
	public int getG() { return g; }
	public void setG(int g) { this.g = g; }
	
	public int getB() { return b; }
	public void setB(int b) { this.b = b; }
	
	public int getPosX() { return posX; }
	public void setPosX(int posX) { this.posX = posX; }
	
	public int getPosY() { return posY; }
	public void setPosY(int posY) { this.posY = posY; }
	
	public PanelInformativo () {
		setY(700 - 100);
		setAlto(alto);
		setBorder(new LineBorder(Color.BLACK, 3));
		setBounds(getX(), getY(), 1000 / 3, getAlto());
		setBackground(Color.RED);
	}
	
	public void setDim (int ancVen, int altVen) {
		setY(altVen - 115);
		setBounds(getX(), getY(), ancVen / 3, getAlto());
		setFont(getLetra());
	}
	
	protected void paintComponent (Graphics gr) {
		gr.setColor(Color.WHITE);
		gr.fillRect(0, 0, this.getWidth(), this.getHeight());
		
		gr.setFont(getLetra());
		gr.setColor(Color.RED);
		gr.drawString("R ["+ getR() +"]", 10, 20);
		gr.setColor(Color.GREEN);
		gr.drawString("G ["+ getG() +"]", 80, 20);
		gr.setColor(Color.BLUE);
		gr.drawString("B ["+ getB() +"]", 150, 20);
		
		gr.setColor(Color.BLACK);
		gr.drawString("P�xel [" + getPosX() + ", " + getPosY() + "]", 220, 20);
	}
}
