package componentesInternos;

import java.awt.Point;
import java.util.ArrayList;

public class VectorPuntos {

	private ArrayList<Point> vector = new ArrayList<Point>();

	public ArrayList<Point> getVector() { return vector; }
	public void setVector(ArrayList<Point> vector) { this.vector = vector; }

	public VectorPuntos() {

	}

	public Boolean eresPuntoExtremo(Point p) {
		return (p.getX() == 0 || p.getX() >= 255);
	}

	public void insertar (Point p) {

		if (!eresPuntoExtremo(p)) {
			for (int i = 0; i < getVector().size(); ++i) {
				if (p.getX() == getVector().get(i).getX()) {
					getVector().remove(i);
					getVector().add(i, p);
				}

				int cercano = buscarMasCercano();
				if (cercano != -1) {

				}
			}
		}
	}

	public int buscarMasCercano () {
		double [] distancias = new double [getVector().size() - 1];
		for (int i = 0; i < getVector().size() - 1; ++i) {
			distancias[i] = distanciaEuclidea(getVector().get(i), getVector().get(i + 1));
		}

		double min = Double.MAX_VALUE;
		int indice = -1;
		for (int i = 0; i < distancias.length; ++i) {
			if (distancias[i] < min) {
				min = distancias[i];
				indice = i;
			}
		}

		return indice;
	}

	public double distanciaEuclidea (Point p, Point q) {
		return Math.sqrt(Math.pow((q.getX() - p.getX()), 2) + Math.pow((q.getY() - p.getY()), 2));
	}
}
