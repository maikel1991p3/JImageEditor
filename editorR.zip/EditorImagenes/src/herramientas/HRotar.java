package herramientas;

import gestores.GestorHerramientas;
import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.border.LineBorder;

import operaciones.OpGeom;

import componentesGraficosHerramientas.VentanaRotacion;
import componentesInternos.MiBoton;

@SuppressWarnings("serial")
public class HRotar extends Herramienta {

	private ArrayList<MiBoton> botones;
	private OpGeom opGeom;
	private VentanaPrincipal refVp;
	private VentanaRotacion vRotacion;
	
	public ArrayList<MiBoton> getBotones() { return botones; }
	public void setBotones(ArrayList<MiBoton> botones) { this.botones = botones; }

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }

	public OpGeom getOpGeom() { return opGeom; }
	public void setOpGeom(OpGeom opGeom) { this.opGeom = opGeom; }
	
	public VentanaRotacion getvRotacion() { return vRotacion; }
	public void setvRotacion(VentanaRotacion vRotacion) { this.vRotacion = vRotacion; }
	
	public HRotar(GestorHerramientas refGestorH) {
		super(refGestorH);
		setRefVp(refGestorH.getRefVp());
		
		setOpGeom(new OpGeom(getRefVp())); 
		setvRotacion(new VentanaRotacion (getRefVp()));
		
		iniciarBotones();
		crearOyentesBotones();
		setBackground(Color.GRAY);
		setVisible(false);
	}

	private void iniciarBotones () {
		setBotones(new ArrayList<MiBoton>());

		MiBoton rP = new MiBoton("Rotar y pintar", 0);
		rP.setToolTipText("Rotar y pintar: Rotacion utilizando la transformación directa para pintar");
		rP.setBounds(20, 20, 200, 40);
		rP.setBackground(Color.WHITE);
		
		getBotones().add (rP);
		
		MiBoton vMP = new MiBoton("Vecino más próximo", 1);
		vMP.setToolTipText("Vecino más próximo: Rotación utilizando la interpolación Vecino más próximo");
		vMP.setBounds(20, 70, 200, 40);
		vMP.setBackground(Color.WHITE);
		
		getBotones().add (vMP);
		
		MiBoton bilineal = new MiBoton("Bilineal", 2);
		bilineal.setToolTipText("Bilineal: Rotación utilizando la interpolación bilineal");
		bilineal.setBounds(20, 120, 200, 40);
		bilineal.setBackground(Color.WHITE);
		
		getBotones().add(bilineal);

		
		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setBorder(new LineBorder(Color.BLACK, 2));
			add (getBotones().get(i));
		}
	}

	private void crearOyentesBotones () {
		
		getBotones().get(0).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getvRotacion().setrP(0);
				getvRotacion().setVisible(true);
			}
		});
		
		getBotones().get(1).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getvRotacion().setrP(1);
				getvRotacion().setVisible(true);
			}
		});
		
		getBotones().get(2).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				getvRotacion().setrP(2);
				getvRotacion().setVisible(true);
			}
		});
	}
}
