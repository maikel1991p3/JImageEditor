package herramientas;

import gestores.GestorHerramientas;
import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.border.LineBorder;

import operaciones.OpGeom;

import componentesGraficosHerramientas.VentanaRota90;
import componentesInternos.MiBoton;

@SuppressWarnings("serial")
public class HGeometricas extends Herramienta {

	private ArrayList<MiBoton> botones;
	private OpGeom opGeom;
	private VentanaPrincipal refVp;
	private VentanaRota90 vRota90;
	
	public ArrayList<MiBoton> getBotones() { return botones; }
	public void setBotones(ArrayList<MiBoton> botones) { this.botones = botones; }

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }

	public OpGeom getOpGeom() { return opGeom; }
	public void setOpGeom(OpGeom opGeom) { this.opGeom = opGeom; }

	public VentanaRota90 getvRota90() { return vRota90; }
	public void setvRota90(VentanaRota90 vRota90) { this.vRota90 = vRota90; }
	
	public HGeometricas(GestorHerramientas refGestorH) {
		super(refGestorH);
		setRefVp(refGestorH.getRefVp());
		
		setOpGeom(new OpGeom(getRefVp())); 
		setvRota90(new VentanaRota90 (getRefVp()));
		
		iniciarBotones();
		crearOyentesBotones();
		setBackground(Color.GRAY);
		setVisible(false);
	}

	private void iniciarBotones () {
		setBotones(new ArrayList<MiBoton>());

		// Reservar memoria para el objeto que realiza las operaciones indicadas
		MiBoton espVert = new MiBoton("Espejo Vertical", 0);
		espVert.setToolTipText("Espejo Vertical: Intercambiar orden de filas");
		espVert.setBounds(20, 20, 200, 40);
		espVert.setBackground(Color.WHITE);

		getBotones().add (espVert);

		MiBoton espHorz = new MiBoton("Espejo Horizontal", 1);
		espHorz.setToolTipText("Espejo Horizontal: Intercambiar orden de columnas");
		espHorz.setBounds(20, 70, 200, 40);
		espHorz.setBackground(Color.WHITE);

		getBotones().add (espHorz);

		MiBoton trasp = new MiBoton("Traspuesta de la imagen", 2);
		trasp.setToolTipText("Traspuesta de la imagen: Cambiar filas por columnas");
		trasp.setBounds(20, 120, 200, 40);
		trasp.setBackground(Color.WHITE);

		getBotones().add (trasp);

		MiBoton rot90 = new MiBoton("Rotaciones de 90º", 3);
		rot90.setToolTipText("Rotaciones de 90º: Rotaciones múltiplos de 90º");
		rot90.setBounds(20, 170, 200, 40);
		rot90.setBackground(Color.WHITE);

		getBotones().add (rot90);

		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setBorder(new LineBorder(Color.BLACK, 2));
			add (getBotones().get(i));
		}
	}

	private void crearOyentesBotones () {
		
		getBotones().get(0).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getRefVp().getGestorSubVentanas().crearSubVentana (getOpGeom().espejoVertical(), 
						"Espejo Vertical de " + getRefVp().getGestorSubVentanas().getRefSubVentActual(), 
						false);
			}

		});

		getBotones().get(1).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getRefVp().getGestorSubVentanas().crearSubVentana (getOpGeom().espejoHorizontal(), 
						"Espejo Horizontal de " + getRefVp().getGestorSubVentanas().getRefSubVentActual(), 
						false);
			}

		});

		getBotones().get(2).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getRefVp().getGestorSubVentanas().crearSubVentana (getOpGeom().traspuesta(), 
						"Traspuesta de " + getRefVp().getGestorSubVentanas().getRefSubVentActual(), 
						false);
			}

		});

		getBotones().get(3).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getvRota90().setVisible(true);
			}

		});

	}

}
