package herramientas;

import gestores.GestorHerramientas;
import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import operaciones.OpDirectas;
import operaciones.OpMapaCambios;

import componentesGraficosHerramientas.VentanaCorrecGamma;
import componentesGraficosHerramientas.VentanaMapaCambios;
import componentesInternos.MiBoton;

@SuppressWarnings("serial")
public class HGeometricas2 extends Herramienta {

	private ArrayList<MiBoton> botones;
	//private OpDirectas opDirectas;
	private VentanaPrincipal refVp;
	
	public ArrayList<MiBoton> getBotones() { return botones; }
	public void setBotones(ArrayList<MiBoton> botones) { this.botones = botones; }

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }

	//public OpDirectas getOpDirectas() { return opDirectas; }
	//public void setOpDirectas(OpDirectas opDirectas) { this.opDirectas = opDirectas; }

	public HGeometricas2(GestorHerramientas refGestorH) {
		super(refGestorH);
		setRefVp(refGestorH.getRefVp());
		
		// Crear clase OpGeometicas que instanciar� los c�lculos -> cmbiar por estas opDirectas
		//setOpDirectas(new OpDirectas(getRefVp())); 
		
		iniciarBotones();
		crearOyentesBotones();
		setBackground(Color.GRAY);
		setVisible(false);
	}

	private void iniciarBotones () {
		setBotones(new ArrayList<MiBoton>());

		// Reservar memoria para el objeto que realiza las operaciones indicadas
		MiBoton PEPE = new MiBoton("PONERLE NOMBREEE", 8);
		PEPE.setToolTipText("NOMBRE-OPERACION: FALTAAA poner descripci�n cortaaaa!!!");
		PEPE.setBounds(20, 20, 200, 40);
		PEPE.setBackground(Color.WHITE);

		getBotones().add (PEPE);

		
		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setBorder(new LineBorder(Color.BLACK, 2));
			add (getBotones().get(i));
		}
	}

	private void crearOyentesBotones () {
		
		// Oyente para cuando pulsamos el bot�n "PEPE" -> CAMBIARRR !!!
		getBotones().get(0).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
		
			}

		});

	}

}
