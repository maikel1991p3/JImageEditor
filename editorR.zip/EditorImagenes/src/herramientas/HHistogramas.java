package herramientas;

import gestores.GestorHerramientas;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.border.LineBorder;

import operaciones.OpHistogramas;

import componentesGraficosHerramientas.VentanaPerfil;
import componentesInternos.MiBoton;

@SuppressWarnings("serial")
public class HHistogramas extends Herramienta {

	private ArrayList<MiBoton> botones;
	private OpHistogramas opHist;

	public ArrayList<MiBoton> getBotones() { return botones; }
	public void setBotones(ArrayList<MiBoton> botones) { this.botones = botones; }

	public OpHistogramas getOpHist() { return opHist; }
	public void setOpHist(OpHistogramas opHist) { this.opHist = opHist; }

	public HHistogramas(GestorHerramientas refGestorH) {
		super(refGestorH);
		iniciarBotones();
		definirEstiloPanel();
		crearOyentesBotones();
		setVisible(false);
	}

	private void iniciarBotones () {
		setBotones(new ArrayList<MiBoton>());

		// Reservar memoria para el objeto que realia las operaciones indicadas
		setOpHist(new OpHistogramas(getRefGestorH().getRefVp()));

		MiBoton bHistAbs = new MiBoton("Histograma Absoluto", 5);
		bHistAbs.setToolTipText("Permite viualizar el HISTOGRAMA ABSOLUTO de la imagen actual");
		bHistAbs.setBounds(20, 20, 200, 40);
		bHistAbs.setBackground(Color.WHITE);
		ImageIcon icHistoAbs = new ImageIcon("/host/Users/rodrigo/Documents/Informatica/eclipse/EditorImagenes/src/Images/Histo.png");
		icHistoAbs.setImage(icHistoAbs.getImage().getScaledInstance(35, 35, Image.SCALE_DEFAULT));
		bHistAbs.setIcon(icHistoAbs);

		MiBoton bHistAcum = new MiBoton("Histograma Acumulativo", 6);
		bHistAcum.setToolTipText("Permite viualizar el HISTOGRAMA ACUMULATIVO de la imagen actual");
		bHistAcum.setBounds(20, 90, 200, 40);
		bHistAcum.setBackground(Color.WHITE);
		ImageIcon icHistoAcum = new ImageIcon("/host/Users/rodrigo/Documents/Informatica/eclipse/EditorImagenes/src/Images/HistoAcP.png");
		icHistoAcum.setImage(icHistoAcum.getImage().getScaledInstance(35, 35, Image.SCALE_DEFAULT));
		bHistAcum.setIcon(icHistoAcum);
		
		MiBoton bEcualiz = new MiBoton("Ecualizar histograma", 6);
		bEcualiz.setToolTipText("Permite ECUALIZAR el HISTOGRAMA de la imagen actual");
		bEcualiz.setBounds(20, 160, 200, 40);
		bEcualiz.setBackground(Color.WHITE);
		ImageIcon icEcual = new ImageIcon("/host/Users/rodrigo/Documents/Informatica/eclipse/EditorImagenes/src/Images/Ecualizar.png");
		icEcual.setImage(icEcual.getImage().getScaledInstance(35, 35, Image.SCALE_DEFAULT));
		bEcualiz.setIcon(icEcual);
		
		MiBoton bPerfil = new MiBoton("Perfil", 6);
		bPerfil.setToolTipText("Permite obtener un subhistograma de la imagen actual a partir de una l�nea dada por el usuario");
		bPerfil.setBounds(20, 230, 200, 40);
		bPerfil.setBackground(Color.WHITE);

		getBotones().add (bHistAbs);
		getBotones().add (bHistAcum);
		getBotones().add(bEcualiz);
		getBotones().add(bPerfil);

		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setBorder(new LineBorder(Color.BLACK, 2));
			add (getBotones().get(i));
		}
	}

	private void definirEstiloPanel () {
		// Poner todo lo relacionado con dar estilo al panel
		setBackground(Color.GRAY);
	}

	private void crearOyentesBotones () {
		// Oyente para el bot�n del histograma Absoluto
		getBotones().get(0).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					getOpHist().representarHistogramaAbs ();
				} catch (Exception e) { }
			}
		});

		// Oyente para el bot�n del histograma Acumulativo
		getBotones().get(1).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					getOpHist().representarHistogramaAc();
				} catch (Exception e) { }
			}
		});
		
		// Oyente para el bot�n de ecualizaci�n
		getBotones().get(2).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					getRefGestorH().getRefVp().getGestorSubVentanas().crearSubVentana(getOpHist().ecualizar (getRefGestorH().getRefVp().getGestorSubVentanas().getRefSubVentActual()), 
							"Ecualizada - " + getRefGestorH().getRefVp().getGestorSubVentanas().getRefSubVentActual().getTitle(), 
							false);
				} catch (Exception e) { }
			}
		});
		
		// Oyente para el bot�n del perfil
		getBotones().get(3).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					VentanaPerfil ventPerfTemp = null;
					if (getRefGestorH().getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg() != null)
						ventPerfTemp = new VentanaPerfil(getRefGestorH().getRefVp().getGestorSubVentanas().getRefSubVentActual().getRefBufImg());
				
				} catch (Exception e) { }
			}
		});
	}

}
