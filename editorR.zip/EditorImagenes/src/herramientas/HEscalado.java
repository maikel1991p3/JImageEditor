package herramientas;

import gestores.GestorHerramientas;
import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import operaciones.OpDirectas;
import operaciones.OpGeom;
import operaciones.OpMapaCambios;

import componentesGraficosHerramientas.VentanaCorrecGamma;
import componentesGraficosHerramientas.VentanaEscalado;
import componentesGraficosHerramientas.VentanaMapaCambios;
import componentesGraficosHerramientas.VentanaRota90;
import componentesInternos.MiBoton;

@SuppressWarnings("serial")
public class HEscalado extends Herramienta {

	private ArrayList<MiBoton> botones;
	private OpGeom opGeom;
	private VentanaPrincipal refVp;		
	private VentanaEscalado vEscalado;
	
	public ArrayList<MiBoton> getBotones() { return botones; }
	public void setBotones(ArrayList<MiBoton> botones) { this.botones = botones; }

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }
    
	public OpGeom getOpGeom() { return opGeom; }
	public void setOpGeom(OpGeom opGeom) { this.opGeom = opGeom; }
	
	public VentanaEscalado getvEscalado() { return vEscalado; }
	public void setvEscalado(VentanaEscalado vEscalado) { this.vEscalado = vEscalado; }
	
	public HEscalado(GestorHerramientas refGestorH) {
		super(refGestorH);
		setRefVp(refGestorH.getRefVp());
		
		setOpGeom(new OpGeom(getRefVp())); 
		setvEscalado(new VentanaEscalado (getRefVp()));
		
		iniciarBotones();
		crearOyentesBotones();
		setBackground(Color.GRAY);
		setVisible(false);
	}

	private void iniciarBotones () {
		setBotones(new ArrayList<MiBoton>());

		// Reservar memoria para el objeto que realiza las operaciones indicadas
		MiBoton vMP = new MiBoton("Vecino más próximo-E", 0);
		vMP.setToolTipText("Vecino más próximo: Escalado utilizando la interpolación Vecino más próximo");
		vMP.setBounds(20, 20, 200, 40);
		vMP.setBackground(Color.WHITE);
		
		getBotones().add (vMP);
		
		MiBoton bilineal = new MiBoton("Bilineal-E", 1);
		bilineal.setToolTipText("Bilineal: Escalado utilizando la interpolación bilineal");
		bilineal.setBounds(20, 70, 200, 40);
		bilineal.setBackground(Color.WHITE);
		
		getBotones().add(bilineal);
		
		for (int i = 0; i < getBotones().size(); ++i) {
			getBotones().get(i).setBorder(new LineBorder(Color.BLACK, 2));
			add (getBotones().get(i));
		}
	}

	private void crearOyentesBotones () {
		
		getBotones().get(0).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getvEscalado().setvMP(true);
				getvEscalado().setVisible(true);
			}

		});
		
		getBotones().get(1).addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getvEscalado().setvMP(false);
				getvEscalado().setVisible(true);
			}
		});
	}

}
