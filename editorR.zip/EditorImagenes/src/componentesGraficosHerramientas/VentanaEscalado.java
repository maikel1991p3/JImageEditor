package componentesGraficosHerramientas;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.Font;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import operaciones.OpGeom;

@SuppressWarnings("serial")
public class VentanaEscalado extends JDialog {

	private VentanaPrincipal refVp;
	private BufferedImage refBImg;
	private OpGeom opGeom;

	private boolean vMP;	//si es true interpolacion vecino mas proximo si no bilineal

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }

	public BufferedImage getRefBImg() { return refBImg; }
	public void setRefBImg(BufferedImage refBImg) { this.refBImg = refBImg; }

	public OpGeom getOpGeom() { return opGeom; }
	public void setOpGeom(OpGeom opGeom) { this.opGeom = opGeom; }

	public boolean isvMP() { return vMP; }
	public void setvMP(boolean vMP) { this.vMP = vMP; }

	public VentanaEscalado (VentanaPrincipal refVp) {
		setRefVp(refVp);
		setOpGeom(new OpGeom(getRefVp())); 
		getContentPane().setBackground(Color.WHITE);
		setBounds(350, 50, 300, 220);
		setLayout(null);
		setAlwaysOnTop(true);
		setResizable(false);
		iniciarPanel();
	}

	public void iniciarPanel () {		

		JLabel titulo = new JLabel("Escalado");
		titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		titulo.setBounds(95, 10, 200, 30);
		add (titulo);

		final TextField tAncho = new TextField("100");
		tAncho.setBounds(110, 65, 40, 30);
		add (tAncho);

		JLabel etiquetaAncho = new JLabel("% Ancho");
		etiquetaAncho.setBounds(160, 65, 200, 30);
		add (etiquetaAncho);

		final TextField tAlto = new TextField("100");
		tAlto.setBounds(110, 105, 40, 30);
		add (tAlto);

		JLabel etiquetaAlto = new JLabel("% Alto");
		etiquetaAlto.setBounds(160, 105, 200, 30);
		add (etiquetaAlto);

		JButton aceptar = new JButton("Aceptar");
		aceptar.setBounds(100, 190, 100, 20);
		aceptar.setBackground(Color.WHITE);
		aceptar.setBorder(new LineBorder(Color.BLACK, 2));
		aceptar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				double ancho = Double.parseDouble(tAncho.getText());
				double alto = Double.parseDouble(tAlto.getText());

				if (isvMP()) {
					getOpGeom().setvMP(true);
					if (getRefVp().getGestorSubVentanas().getRefSubVentActual() != null)
						getRefVp().getGestorSubVentanas().crearSubVentana (getOpGeom().escalar(ancho, alto), 
								"Escalada VMP " + getRefVp().getGestorSubVentanas().getRefSubVentActual(), 
								false);
				}
				else {
					getOpGeom().setvMP(false);
					if (getRefVp().getGestorSubVentanas().getRefSubVentActual() != null)
						getRefVp().getGestorSubVentanas().crearSubVentana (getOpGeom().escalar(ancho, alto), 
								"Escalada Bilineal " + getRefVp().getGestorSubVentanas().getRefSubVentActual(), 
								false);
				}

				dispose();
			}
		});
		add (aceptar);
	}	
}
