package componentesGraficosHerramientas;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;


import operaciones.OpEspecificacionH;

@SuppressWarnings("serial")
public class VentanaEspecificacionH extends JDialog {
	//ref a la ventanaPrincipal
	private VentanaPrincipal ventanaPrincipal;

	private JLabel clickImg1 = new JLabel("Im�gen 1. Seleccione: ");
	private JLabel clickImg2 = new JLabel("Im�gen 2. Seleccione: ");
	private JComboBox<SubVentana> leerImg1 = new JComboBox<SubVentana> ();
	private JComboBox<SubVentana> leerImg2 = new JComboBox<SubVentana> ();
	private JButton crear = new JButton("Crear");

	private SubVentana refImagen1;
	private SubVentana refImagen2;

	private PanelHistogramaNormalizado refPanel1 = new PanelHistogramaNormalizado(null);
	private PanelHistogramaNormalizado refPanel2 = new PanelHistogramaNormalizado(null);

	private OpEspecificacionH opEspecificacionH = new OpEspecificacionH();

	public OpEspecificacionH getOpEspecificacionH() { return this.opEspecificacionH;}
	public void setOpEspecificacionH(OpEspecificacionH op) { this.opEspecificacionH = op;}

	public PanelHistogramaNormalizado getRefPanel1() { return refPanel1; }
	public void setRefPanel1(PanelHistogramaNormalizado refPanel1) { this.refPanel1 = refPanel1; }

	public PanelHistogramaNormalizado getRefPanel2() { return refPanel2; }
	public void setRefPanel2(PanelHistogramaNormalizado refPanel2) { this.refPanel2 = refPanel2; }

	public SubVentana getRefImagen1() { return refImagen1; }
	public void setRefImagen1(SubVentana refImagen1) { this.refImagen1 = refImagen1; }

	public SubVentana getRefImagen2() { return refImagen2; }
	public void setRefImagen2(SubVentana refImagen2) { this.refImagen2 = refImagen2; }

	public VentanaPrincipal getVentanaPrincipal() { return ventanaPrincipal; }
	public void setVentanaPrincipal(VentanaPrincipal ventanaPrincipal) { this.ventanaPrincipal = ventanaPrincipal; }

	public JLabel getClickImg1() { return clickImg1; }
	public void setClickImg1(JLabel clickImg1) { this.clickImg1 = clickImg1; }

	public JLabel getClickImg2() { return clickImg2; }
	public void setClickImg2(JLabel clickImg2) { this.clickImg2 = clickImg2; }

	public JComboBox<SubVentana> getLeerImg1() { return leerImg1; }
	public void setLeerImg1(JComboBox<SubVentana> leerImg1) { this.leerImg1 = leerImg1; }

	public JComboBox<SubVentana> getLeerImg2() { return leerImg2; }
	public void setLeerImg2(JComboBox<SubVentana> leerImg2) { this.leerImg2 = leerImg2; }

	public JButton getCrear() { return this.crear; }
	public void setCrear(JButton c) { this.crear = c; }

	public VentanaEspecificacionH(VentanaPrincipal vp) {
		setVentanaPrincipal(vp);
		inicializarVentana();
	}

	public void inicializarVentana() {
		this.setSize(800, 600);
		this.setAlwaysOnTop(true);
		this.setLayout(null);
		//this.setResizable(false); Primero lo dejamos a true para ver si coloco bien las cosas
		this.setLocation(100, 50);
		this.getContentPane().setBackground(Color.WHITE);
		this.setVisible(true);
		inicializarComponentes();
	}

	public void inicializarComponentes() {

		getClickImg1().setBounds(20, 20, 100, 50);
		getClickImg1().setBackground(Color.WHITE);
		this.add(getClickImg1());

		getLeerImg1().setBounds(150, 20, 220, 50);
		getLeerImg1().setEditable(false);
		getLeerImg1().setBackground(Color.WHITE);
		this.add(getLeerImg1());

		getRefPanel1().setBounds(50, 100, 300, 350);
		this.add(getRefPanel1());

		getClickImg2().setBounds(400, 20, 100, 50);
		getClickImg2().setBackground(Color.WHITE);
		this.add(getClickImg2());

		getLeerImg2().setBounds(530, 20, 220, 50);
		getLeerImg2().setEditable(false);
		getLeerImg2().setBackground(Color.WHITE);
		this.add(getLeerImg2());

		getRefPanel2().setBounds(450, 100, 300, 350);
		this.add(getRefPanel2());

		getLeerImg1().addPopupMenuListener(new PopupMenuListener() {

			@Override
			public void popupMenuWillBecomeVisible(PopupMenuEvent arg0) {
				iniciarCombos();
			}

			@Override
			public void popupMenuWillBecomeInvisible(PopupMenuEvent arg0) {
				setRefImagen1(((SubVentana) getLeerImg1().getSelectedItem()));
				getRefPanel1().setFrecuencia(getRefImagen1().getHistogramaAc());
				getRefPanel1().repaint();
			}

			@Override
			public void popupMenuCanceled(PopupMenuEvent arg0) { }
		});

		add (getLeerImg1());
		
		getLeerImg2().addPopupMenuListener(new PopupMenuListener() {

			@Override
			public void popupMenuWillBecomeVisible(PopupMenuEvent arg0) {
				iniciarCombos();
				//if (getLeerImg2().getSelectedItem() != null) {
//					setRefImagen2((SubVentana) getLeerImg2().getSelectedItem());
//					getRefPanel2().setFrecuencia(getRefImagen2().getHistogramaAc());
//					getRefPanel2().repaint();
				//}
			}

			@Override
			public void popupMenuWillBecomeInvisible(PopupMenuEvent arg0) {
				//iniciarCombos();
				setRefImagen2((SubVentana) getLeerImg2().getSelectedItem());
				getRefPanel2().setFrecuencia(getRefImagen2().getHistogramaAc());
				getRefPanel2().repaint();
			}

			@Override
			public void popupMenuCanceled(PopupMenuEvent arg0) { }
		});
		add(getLeerImg2());

		//iniciarCombos();

		getCrear().setBackground(Color.WHITE);
		getCrear().setBounds(600, 500, 100, 50);
		getCrear().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				getVentanaPrincipal().getGestorSubVentanas().crearSubVentana(getOpEspecificacionH().especificacionH(getRefImagen1().getRefBufImg(), getRefImagen1().getHistogramaAc(), getRefImagen2().getHistogramaAc()),
						"Especificacion H - " + getRefImagen1().getTitle(), false);
				dispose();
			}
		});
		this.add(getCrear());
	}

	public void iniciarCombos () {
		if (getLeerImg1().getItemCount() > 0 && getLeerImg2().getItemCount() > 0) {
			getLeerImg1().removeAllItems();
			getLeerImg2().removeAllItems();
		}
		for (int i = 0; i < getVentanaPrincipal().getGestorSubVentanas().getSubVentanas().size(); ++i) {
			System.out.println(getVentanaPrincipal().getGestorSubVentanas().getSubVentanas().get(i));
			getLeerImg1().addItem(getVentanaPrincipal().getGestorSubVentanas().getSubVentanas().get(i));
			getLeerImg2().addItem (getVentanaPrincipal().getGestorSubVentanas().getSubVentanas().get(i));
		}
		getLeerImg1().repaint();
		getLeerImg2().repaint();
	}



}


