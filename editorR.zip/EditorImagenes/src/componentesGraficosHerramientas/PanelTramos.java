package componentesGraficosHerramientas;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;

import javax.swing.JPanel;


@SuppressWarnings("serial")
public class PanelTramos extends JPanel {

	final int DESFACE_PUNTOS_PANEL = 44;
	final int ALTO_PANELES = 300;
	
	private VentanaTransfTramos refVTramos;
	
	public VentanaTransfTramos getRefVTramos() { return refVTramos; }
	public void setRefVTramos(VentanaTransfTramos refVTramos) { this.refVTramos = refVTramos; }

	public PanelTramos(VentanaTransfTramos refVt) {
		super();
		setRefVTramos(refVt);
	}

	public void pintarPunto (Point p) {
		if (comprobarLimite(p)) {
			Graphics gr = this.getGraphics();
			gr.setColor(Color.YELLOW);
			gr.fillOval((int) p.getX (), (int) p.getY (), 10, 10);
			gr.setColor(Color.WHITE);
			gr.drawOval((int) p.getX (), (int) p.getY (), 10, 10);
		}
	}

	public Boolean comprobarLimite (Point p) {
		return (p.getX() < 256 && p.getX() > -1 && p.getY() < 256 && p.getY() > -1);
	}

	protected void paintComponent (Graphics gr) {
		super.paintComponents(gr);
		gr.fillRect(0, 0, getWidth(), getHeight());

		// Pintamos los ejes cartesianos
		gr.setColor(Color.WHITE);

		int posXEjeX = 44;
		int posYEjeX = ALTO_PANELES - 44;

		gr.drawLine(posXEjeX, posYEjeX, this.getWidth() - 10, posYEjeX);
		gr.drawLine(posXEjeX, posYEjeX, posXEjeX, 5);

		// Numeramos los ejes
		gr.drawString(String.valueOf(0), posXEjeX, posYEjeX + 15); // (0, 0)
		gr.drawString(String.valueOf(255), this.getWidth() - 30, posYEjeX + 15); // (255, 0)
		gr.drawString(String.valueOf(255), posXEjeX - 30, 30); // (0, 255)
		

		// Pintamos las rectas entre dichos pintos
		gr.setColor(Color.RED);
		Graphics2D g2d = (Graphics2D) gr;
		g2d.setStroke(new BasicStroke(2));
		int numPuntos = getRefVTramos().getPuntosEsp().size();
		if (numPuntos >= 2) {
			for (int i = 0; i < getRefVTramos().getPuntosEsp().size() - 1; ++i) {
				g2d.drawLine((int) getRefVTramos().getPuntosEsp().get(i).getX() + DESFACE_PUNTOS_PANEL, posYEjeX - (int) getRefVTramos().getPuntosEsp().get(i).getY(), 
						(int) getRefVTramos().getPuntosEsp().get(i + 1).getX() + DESFACE_PUNTOS_PANEL, posYEjeX - (int) getRefVTramos().getPuntosEsp().get(i + 1).getY());
				
			}
		}			
					
		// Pintamos los puntos de las transformaciones
		gr.setColor(Color.YELLOW);
		for (int i = 0; i < getRefVTramos().getPuntosEsp().size(); ++i)
			gr.fillOval((int) getRefVTramos().getPuntosEsp().get(i).getX() + DESFACE_PUNTOS_PANEL - 5, posYEjeX - (int) getRefVTramos().getPuntosEsp().get(i).getY() - 5, 10, 10);
	}

}
