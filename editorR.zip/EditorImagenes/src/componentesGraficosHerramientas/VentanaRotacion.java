package componentesGraficosHerramientas;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.Font;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import operaciones.OpGeom;

@SuppressWarnings("serial")
public class VentanaRotacion extends JDialog {

	private VentanaPrincipal refVp;
	private BufferedImage refBImg;
	private OpGeom opGeom;

	private int rP;	//si es 0 rotar y pintar si es 1 interpolacion vecino mas proximo si no bilineal

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }

	public BufferedImage getRefBImg() { return refBImg; }
	public void setRefBImg(BufferedImage refBImg) { this.refBImg = refBImg; }

	public OpGeom getOpGeom() { return opGeom; }
	public void setOpGeom(OpGeom opGeom) { this.opGeom = opGeom; }

	public int getrP() { return rP; }
	public void setrP(int rP) { this.rP = rP; }

	public VentanaRotacion (VentanaPrincipal refVp) {
		setRefVp(refVp);
		setOpGeom(new OpGeom(getRefVp())); 
		getContentPane().setBackground(Color.WHITE);
		setBounds(350, 50, 300, 220);
		setLayout(null);
		setAlwaysOnTop(true);
		setResizable(false);
		iniciarPanel();
	}

	public void iniciarPanel () {		

		JLabel titulo = new JLabel("Rotación");
		titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		titulo.setBounds(95, 10, 200, 30);
		add (titulo);

		final TextField tGrados = new TextField("0");
		tGrados.setBounds(110, 95, 40, 30);
		add (tGrados);

		JLabel etiquetaGrados = new JLabel("º de rotación");
		etiquetaGrados.setBounds(155, 95, 200, 30);
		add (etiquetaGrados);

		JButton aceptar = new JButton("Aceptar");
		aceptar.setBounds(100, 190, 100, 20);
		aceptar.setBackground(Color.WHITE);
		aceptar.setBorder(new LineBorder(Color.BLACK, 2));
		aceptar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (getRefVp().getGestorSubVentanas().getRefSubVentActual() != null) {
					double grados = Double.parseDouble(tGrados.getText());
					int [] histograma = new int [256]; 
					if (getrP() == 0) {
						getRefVp().getGestorSubVentanas().crearSubVentana (getOpGeom().rotar(grados, 0), 
								"Rotada " + grados + " grados " + getRefVp().getGestorSubVentanas().getRefSubVentActual(), 
								false);

					}
					else if (getrP() == 1) {
						getRefVp().getGestorSubVentanas().crearSubVentana (getOpGeom().rotar(grados, 1), 
								"Rotada " + grados + " grados " + getRefVp().getGestorSubVentanas().getRefSubVentActual(), 
								false);
					}
					else if (getrP() == 2) {
						getRefVp().getGestorSubVentanas().crearSubVentana (getOpGeom().rotar(grados, 2), 
								"Rotada " + grados + " grados " + getRefVp().getGestorSubVentanas().getRefSubVentActual(), 
								false);
					}

					getRefVp().getGestorSubVentanas().getRefSubVentActual().getHistogramaAbs()[0] -= getOpGeom().getContadorDeFondo();
					getRefVp().getGestorSubVentanas().getRefSubVentActual().obtenerHistogramaAc();
					dispose();
				}
			}
		});
		add (aceptar);
	}	
}
