package componentesGraficosHerramientas;

import herramientas.HDirectas;
import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JSlider;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import operaciones.OpMapaCambios;

/* Debe contener la dos imagenes elegidas + el valor
 * del slider (umbral de cambio) + La referencia a la
 * subventana creada por esta clase.
 * 
 * Esta clase tambien se encarga de :
 * 	1- Crear tabla de transformacion que es igual a la de antes
 *  2- M�todo que modifique el buffer de la referencia de la subventana
 *  creada desde un comienzo utilizando la tabla de transformacion
 */
@SuppressWarnings("serial")
public class VentanaSMapaCambios extends JDialog {
	//referencias
	private VentanaPrincipal refVentana;
	private BufferedImage refImagen1;
	private BufferedImage refImagen2;
	private SubVentana refImagenCreada;
	private OpMapaCambios opMapa;

	private JSlider sUmbralCambio = new JSlider();
	private VentanaSMapaCambios refTHIS;

	// get y set
	public VentanaPrincipal getRefVentana() { return refVentana; }
	public void setRefVentana(VentanaPrincipal vp) { this.refVentana = vp; }

	public BufferedImage getRefImagen1() { return refImagen1; }
	public void setRefImagen1(BufferedImage refImagen1) { this.refImagen1 = refImagen1; }

	public BufferedImage getRefImagen2() { return refImagen2; }
	public void setRefImagen2(BufferedImage refImagen2) { this.refImagen2 = refImagen2; }

	public SubVentana getRefImagenCreada() { return refImagenCreada; }
	public void setRefImagenCreada(SubVentana refImagenCreada) { this.refImagenCreada = refImagenCreada; }

	public JSlider getsUmbralCambio() { return sUmbralCambio; }
	public void setsUmbralCambio(JSlider sUmbralCambio) { this.sUmbralCambio = sUmbralCambio; }

	public OpMapaCambios getOpMapa() { return opMapa; }
	public void setOpMapa(OpMapaCambios opMapa) { this.opMapa = opMapa; }

	public VentanaSMapaCambios getRefTHIS() { return refTHIS; }
	public void setRefTHIS(VentanaSMapaCambios refTHIS) { this.refTHIS = refTHIS; }
	/*-------------------------------------------------------*/

	public VentanaSMapaCambios (BufferedImage imagen1, BufferedImage imagen2, VentanaPrincipal vp) {
		setRefImagen1(imagen1);
		setRefImagen2(imagen2);
		setRefVentana(vp);
		setOpMapa(new OpMapaCambios(vp));
		cargarGraficos();
		crearSubVentanaInicial(imagen1, imagen2);

		setRefTHIS(this);
	}

	public void crearSubVentanaInicial (BufferedImage imagen1, BufferedImage imagen2) {
		BufferedImage imagen = new BufferedImage(imagen1.getWidth(), imagen1.getHeight(), imagen1.getType());
		for (int i = 0; i < imagen.getWidth(); ++i){
			for (int j = 0; j < imagen.getHeight(); ++j){
				imagen.setRGB(i, j, imagen1.getRGB(i, j));
			}
		}
		getRefVentana().getGestorSubVentanas().crearSubVentana(imagen, "Mapa de cambios", false);
		setRefImagenCreada(getRefVentana().getGestorSubVentanas().getRefSubVentActual());
	}

	public void modificarImagen (BufferedImage imagenResultado) {
		for (int i = 0; i < getRefImagenCreada().getRefBufImg().getWidth(); ++i){
			for (int j = 0; j < getRefImagenCreada().getRefBufImg().getHeight(); ++j){
				getRefImagenCreada().getRefBufImg().setRGB(i, j, imagenResultado.getRGB(i, j));
			}
		}
	}
	public void cargarGraficos () {
		this.setSize(400, 120);
		this.setTitle("Controlador de Cambios");
		this.setAlwaysOnTop(true);
		this.setResizable(false);
		this.setLocation(500, 500);
		this.getContentPane().setBackground(Color.WHITE);
		this.setVisible(true);
		//Slider
		getsUmbralCambio().setBounds(25, 0, 350, 50);
		getsUmbralCambio().setBackground(Color.WHITE);
		getsUmbralCambio().setMinimum(10);
		getsUmbralCambio().setMaximum(100);
		getsUmbralCambio().setPaintTicks(true);
		getsUmbralCambio().setPaintTrack(true);
		getsUmbralCambio().setMajorTickSpacing(10);
		getsUmbralCambio().setMinorTickSpacing(5);
		getsUmbralCambio().setValue(255);
		getsUmbralCambio().setPaintLabels(true);
		getsUmbralCambio().addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent arg0) {
				modificarImagen(getOpMapa().mapaDeCambios(getRefImagen1(), getRefImagen2(), getsUmbralCambio().getValue()));
				getRefImagenCreada().getPanel().repaint();
			}
		});
		this.add(getsUmbralCambio());

		JButton aceptar = new JButton("Aceptar");
		aceptar.setBackground(Color.WHITE);
		aceptar.setBorder (new LineBorder(Color.BLACK, 1));
		aceptar.setBounds((getWidth() / 2) - 80, 60, 80, 20);
		aceptar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getRefTHIS().dispose();
				((HDirectas) getRefVentana().getGestorHerramientas().getHerramientas().get(4)).getVentanaMapaCambios().dispose();

			}
		});
		this.add(aceptar);	
	}

}