package componentesGraficosHerramientas;

import interfaz_principal.VentanaPrincipal;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import operaciones.OpGeom;

@SuppressWarnings("serial")
public class VentanaRota90 extends JDialog {

	private VentanaPrincipal refVp;
	private BufferedImage refBImg;
	private OpGeom opGeom;

	public VentanaPrincipal getRefVp() { return refVp; }
	public void setRefVp(VentanaPrincipal refVp) { this.refVp = refVp; }

	public BufferedImage getRefBImg() { return refBImg; }
	public void setRefBImg(BufferedImage refBImg) { this.refBImg = refBImg; }

	public OpGeom getOpGeom() { return opGeom; }
	public void setOpGeom(OpGeom opGeom) { this.opGeom = opGeom; }
	
	public VentanaRota90 (VentanaPrincipal refVp) {
		setRefVp(refVp);
		setOpGeom(new OpGeom(getRefVp())); 
		getContentPane().setBackground(Color.WHITE);
		setBounds(350, 50, 300, 220);
		setLayout(null);
		setAlwaysOnTop(true);
		setResizable(false);
		iniciarPanel();
	}

	public void iniciarPanel () {		

		JLabel titulo = new JLabel("Rotar 90º");
		titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		titulo.setBounds(95, 10, 200, 30);
		add (titulo);

		JButton aceptar = new JButton("Aceptar");
		aceptar.setBounds(100, 190, 100, 20);
		aceptar.setBackground(Color.WHITE);
		aceptar.setBorder(new LineBorder(Color.BLACK, 2));
		aceptar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		JButton der = new JButton("90º");
		der.setBounds(180, 60, 40, 40);
		//der.setIcon(new ImageIcon(arg0));
		der.setBackground(Color.WHITE);
		der.setBorder(new LineBorder(Color.BLACK, 2));
		der.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getRefVp().getGestorSubVentanas().crearSubVentana (getOpGeom().rotarDerecha(), 
						"Rotada 90º " + getRefVp().getGestorSubVentanas().getRefSubVentActual(), 
						false);
			}
		});
		JButton abajo = new JButton("180º");
		abajo.setBounds(135, 115, 40, 40);
		//abajo.setIcon(new ImageIcon(arg0));
		abajo.setBackground(Color.WHITE);
		abajo.setBorder(new LineBorder(Color.BLACK, 2));
		abajo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getRefVp().getGestorSubVentanas().crearSubVentana (getOpGeom().rotarAbajo(), 
						"Rotada 180º " + getRefVp().getGestorSubVentanas().getRefSubVentActual(), 
						false);
			}
		});
		JButton iz = new JButton("270º");
		iz.setBounds(90, 60, 40, 40);
		//iz.setIcon(new ImageIcon(arg0));
		iz.setBackground(Color.WHITE);
		iz.setBorder(new LineBorder(Color.BLACK, 2));
		iz.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getRefVp().getGestorSubVentanas().crearSubVentana (getOpGeom().rotarIzquierda(), 
						"Rotada 270º " + getRefVp().getGestorSubVentanas().getRefSubVentActual(), 
						false);
			}
		});
		add (aceptar);
		add (der);
		add (abajo);
		add (iz);
	}	
}
