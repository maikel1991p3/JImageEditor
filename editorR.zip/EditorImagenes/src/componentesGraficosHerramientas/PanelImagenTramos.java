package componentesGraficosHerramientas;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PanelImagenTramos extends JPanel {

	private BufferedImage imagenTranf;
	
	public BufferedImage getImagenTranf() { return imagenTranf; }
	public void setImagenTranf(BufferedImage imagenTranf) { this.imagenTranf = imagenTranf; }

	public PanelImagenTramos(BufferedImage imagenFinal) {
		setImagenTranf(imagenFinal);
	}
	
	protected void paintComponent(Graphics gr) {
		gr.setColor (Color.WHITE);
		gr.drawRect(0, 0, this.getWidth(), this.getHeight());
		if (getImagenTranf() != null)
			gr.drawImage(getImagenTranf(), 0, 0, this.getWidth(), this.getHeight(), this);
	}

}
