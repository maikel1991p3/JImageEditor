package componentesGraficosHerramientas;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PanelHistogramaNormalizado extends JPanel {
	final int SEPARACION = 20;
	private int [] frecuencia;

	public int[] getFrecuencia() { return this.frecuencia;}
	public void setFrecuencia(int[] frec) {this.frecuencia = frec;}

	public PanelHistogramaNormalizado (int [] valores) {
		if (valores != null) {
			setFrecuencia(valores);
		}
	}

	public void paintComponent(Graphics h){
		h.setColor(Color.LIGHT_GRAY);
		h.fillRect(0, 0, this.getWidth(), this.getHeight());

		if (frecuencia != null) {
			h.setColor(Color.BLACK);
			int altura = this.getHeight() - SEPARACION*2;
			int ancho = this.getWidth() - SEPARACION*2;

			h.drawLine(SEPARACION - 5, SEPARACION, SEPARACION - 5, SEPARACION + altura);//eje Y
			h.drawLine(SEPARACION - 5, SEPARACION + altura, SEPARACION + ancho, SEPARACION + altura);//eje X
		
			h.setColor(new Color(0, 0, 205));
			double factorY = 1 / (double)altura;
			double factorX = 255.0 / (double)ancho;
			
			for (int i = 0; i < getFrecuencia().length; ++i) {
				h.drawLine((int)(SEPARACION + (double)i*factorX),(int)(SEPARACION + altura), (int)(SEPARACION + (double)i*factorX), (int)((SEPARACION + altura) - getFrecuencia()[i]*factorY));
			}
		}
	}

}
